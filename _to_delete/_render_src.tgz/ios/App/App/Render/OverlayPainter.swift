import UIKit
import CoreGraphics

/// Draws the caption stack and the template layer, matching
/// `remotion/CaptionOverlay.tsx` and `remotion/DecorativeGraphics.tsx`.
///
/// The counterpart of Android's `CaptionPainter` and `TemplatePainter`; every
/// number comes from `src/lib/mobile/deviceRenderCaptions.ts`, which is in turn
/// read off the overlay component. iOS differs in one respect: a cue is drawn
/// ONCE into a UIImage and handed to a CALayer, because the final export uses
/// `AVVideoCompositionCoreAnimationTool` and Core Animation does the timing.
/// That is cheaper than redrawing per frame and it is why the pop-in is
/// expressed as a keyframe animation rather than a per-frame alpha.
enum OverlayPainter {

    // ── Layout, from CAPTION_LAYOUT ─────────────────────────────────────────
    private static let referenceHeight: CGFloat = 1920
    static let stackBottom: CGFloat = 150
    private static let lineGap: CGFloat = 16
    private static let sidePadding: CGFloat = 40
    private static let maxLinesPerCue = 2
    private static let lineHeight: CGFloat = 1.25
    private static let strokeWidth: CGFloat = 6
    private static let shadowOffset = CGSize(width: 3, height: 3)
    private static let shadowBlur: CGFloat = 6
    private static let plateRadius: CGFloat = 18
    private static let platePaddingY: CGFloat = 10
    private static let platePaddingX: CGFloat = 26
    static let appearSeconds: Double = 0.15
    static let appearScaleFrom: CGFloat = 0.96

    static func scale(forHeight height: CGFloat) -> CGFloat { height / referenceHeight }

    private static func fontSize(for language: String) -> CGFloat {
        switch language {
        case "th": return 72
        case "en": return 64
        case "zh": return 58
        default: return 64
        }
    }

    private static func color(for language: String) -> UIColor {
        language == "zh" ? UIColor(red: 1, green: 1, blue: 0, alpha: 1) : .white
    }

    /// Weight 800 maps to the heaviest system weight iOS offers for the default
    /// family; Thai and Simplified Chinese come through font fallback, as they
    /// do in the overlay's font stacks.
    private static func font(for language: String, size: CGFloat) -> UIFont {
        UIFont.systemFont(ofSize: size, weight: .heavy)
    }

    /// The drawn cue plus its height, so the caller can place the layer.
    struct DrawnCaption {
        let image: UIImage
        let size: CGSize
    }

    /// Render one cue's whole stack — every requested language, plates and all —
    /// into a single image sized to the canvas width.
    ///
    /// Returns nil when the cue has no text in any requested language, so the
    /// caller adds no layer for it rather than an invisible one.
    static func drawCaption(
        _ caption: RenderManifest.Caption,
        languages: [String],
        canvas: CGSize
    ) -> DrawnCaption? {
        let s = scale(forHeight: canvas.height)
        let maxTextWidth = canvas.width - 2 * sidePadding * s - 2 * platePaddingX * s
        guard maxTextWidth > 0 else { return nil }

        struct Line {
            let attributed: NSAttributedString
            let textSize: CGSize
            let color: UIColor
        }

        var lines: [Line] = []
        for language in languages {
            let text = caption.text(for: language)
            guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }

            let size = fontSize(for: language) * s
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            paragraph.lineHeightMultiple = lineHeight
            paragraph.lineBreakMode = .byTruncatingTail

            let attributes: [NSAttributedString.Key: Any] = [
                .font: font(for: language, size: size),
                .foregroundColor: color(for: language),
                .paragraphStyle: paragraph,
            ]
            let attributed = NSAttributedString(string: text, attributes: attributes)

            let bounding = attributed.boundingRect(
                with: CGSize(width: maxTextWidth, height: size * lineHeight * CGFloat(maxLinesPerCue)),
                options: [.usesLineFragmentOrigin, .usesFontLeading],
                context: nil
            )
            lines.append(Line(
                attributed: attributed,
                textSize: CGSize(width: ceil(bounding.width), height: ceil(bounding.height)),
                color: color(for: language)
            ))
        }
        guard !lines.isEmpty else { return nil }

        let gap = lineGap * s
        var stackHeight: CGFloat = 0
        for (index, line) in lines.enumerated() {
            stackHeight += line.textSize.height + 2 * platePaddingY * s
            if index > 0 { stackHeight += gap }
        }

        let canvasSize = CGSize(width: canvas.width, height: stackHeight)
        let renderer = UIGraphicsImageRenderer(size: canvasSize, format: transparentFormat())
        let image = renderer.image { context in
            var y: CGFloat = 0
            for line in lines {
                let plateHeight = line.textSize.height + 2 * platePaddingY * s
                let plateWidth = line.textSize.width + 2 * platePaddingX * s
                let plateRect = CGRect(
                    x: (canvas.width - plateWidth) / 2, y: y,
                    width: plateWidth, height: plateHeight
                )

                UIColor.black.withAlphaComponent(0.42).setFill()
                UIBezierPath(roundedRect: plateRect, cornerRadius: plateRadius * s).fill()

                let textRect = CGRect(
                    x: (canvas.width - line.textSize.width) / 2,
                    y: y + platePaddingY * s,
                    width: line.textSize.width,
                    height: line.textSize.height
                )

                // `paint-order: stroke fill`: the outline is drawn under the
                // glyph fill so the stroke never eats into the letterforms. On
                // iOS a NEGATIVE stroke width means "stroke and fill", which is
                // exactly that ordering in one pass.
                context.cgContext.setShadow(
                    offset: CGSize(width: shadowOffset.width * s, height: shadowOffset.height * s),
                    blur: shadowBlur * s,
                    color: UIColor.black.withAlphaComponent(0.9).cgColor
                )
                let stroked = NSMutableAttributedString(attributedString: line.attributed)
                stroked.addAttributes([
                    .strokeColor: UIColor.black,
                    .strokeWidth: -(strokeWidth * s) / (fontSizeOf(line.attributed) / 100),
                ], range: NSRange(location: 0, length: stroked.length))
                stroked.draw(with: textRect, options: [.usesLineFragmentOrigin], context: nil)

                y += plateHeight + gap
            }
        }
        return DrawnCaption(image: image, size: canvasSize)
    }

    /// `NSAttributedString.strokeWidth` is a PERCENTAGE of the font size, not a
    /// point value, which is the single easiest thing to get wrong here — a
    /// 6-point outline written as `6` is a 6% outline that all but disappears.
    private static func fontSizeOf(_ attributed: NSAttributedString) -> CGFloat {
        guard attributed.length > 0,
              let font = attributed.attribute(.font, at: 0, effectiveRange: nil) as? UIFont
        else { return 64 }
        return font.pointSize
    }

    /// The template frame and decor, drawn once for the whole export.
    ///
    /// Reproduces the same frames and decor sets as Android's
    /// `TemplatePainter`. The Remotion decor animates; anything that depends on
    /// Remotion's spring physics is drawn in its settled state here, which is a
    /// visible difference on the decorated templates and is why the comparison
    /// fixtures include one render per template rather than only `none`.
    static func drawTemplate(_ template: RenderManifest.Template, canvas: CGSize) -> UIImage? {
        if template.id == "none" || (template.frame == "full_bleed" && template.decor.isEmpty) {
            return nil
        }
        let s = scale(forHeight: canvas.height)
        let palette = Palette(template.palette)

        let renderer = UIGraphicsImageRenderer(size: canvas, format: transparentFormat())
        return renderer.image { context in
            let cg = context.cgContext
            drawFrame(template, palette: palette, canvas: canvas, scale: s, in: cg)
            for decor in template.decor {
                drawDecor(decor, palette: palette, canvas: canvas, scale: s, in: cg)
            }
        }
    }

    // ── template internals ──────────────────────────────────────────────────

    private struct Palette {
        let primary: UIColor
        let secondary: UIColor
        let accent: UIColor
        let neutral: UIColor

        init(_ source: RenderManifest.Palette) {
            primary = Palette.color(source.primary)
            secondary = Palette.color(source.secondary)
            accent = Palette.color(source.accent)
            neutral = Palette.color(source.neutral)
        }

        static func color(_ hex: String) -> UIColor {
            var value: UInt64 = 0
            Scanner(string: String(hex.dropFirst())).scanHexInt64(&value)
            return UIColor(
                red: CGFloat((value >> 16) & 0xFF) / 255,
                green: CGFloat((value >> 8) & 0xFF) / 255,
                blue: CGFloat(value & 0xFF) / 255,
                alpha: 1
            )
        }
    }

    private static func drawFrame(
        _ template: RenderManifest.Template,
        palette: Palette,
        canvas: CGSize,
        scale s: CGFloat,
        in cg: CGContext
    ) {
        switch template.frame {
        case "corner_bracket":
            cg.setStrokeColor(UIColor.white.cgColor)
            cg.setLineWidth(6 * s)
            let inset = 48 * s
            let arm = 120 * s
            for (x, y, dx, dy) in [
                (inset, inset, CGFloat(1), CGFloat(1)),
                (canvas.width - inset, inset, CGFloat(-1), CGFloat(1)),
                (inset, canvas.height - inset, CGFloat(1), CGFloat(-1)),
                (canvas.width - inset, canvas.height - inset, CGFloat(-1), CGFloat(-1)),
            ] {
                cg.move(to: CGPoint(x: x + dx * arm, y: y))
                cg.addLine(to: CGPoint(x: x, y: y))
                cg.addLine(to: CGPoint(x: x, y: y + dy * arm))
                cg.strokePath()
            }

        case "hairline_border":
            cg.setStrokeColor(palette.neutral.withAlphaComponent(0.55).cgColor)
            cg.setLineWidth(2 * s)
            let inset = 36 * s
            cg.stroke(CGRect(x: inset, y: inset,
                             width: canvas.width - 2 * inset, height: canvas.height - 2 * inset))

        case "rounded_inset":
            // The video sits inside a rounded window; everything outside it is
            // the template canvas. Punching the window out of a filled rect is
            // what makes the inset read as a frame rather than a border drawn on
            // top of the picture.
            cg.setFillColor(canvasColor(template, palette: palette).cgColor)
            cg.fill(CGRect(origin: .zero, size: canvas))
            let inset = 64 * s
            let window = UIBezierPath(
                roundedRect: CGRect(x: inset, y: inset,
                                    width: canvas.width - 2 * inset,
                                    height: canvas.height - 2 * inset),
                cornerRadius: 48 * s
            )
            cg.setBlendMode(.clear)
            cg.addPath(window.cgPath)
            cg.fillPath()
            cg.setBlendMode(.normal)

        case "polaroid":
            cg.setFillColor(UIColor.white.cgColor)
            cg.fill(CGRect(origin: .zero, size: canvas))
            let side = 56 * s
            cg.setBlendMode(.clear)
            // A polaroid's bottom border is deeper than its sides.
            cg.fill(CGRect(x: side, y: side,
                           width: canvas.width - 2 * side,
                           height: canvas.height - side - side * 4))
            cg.setBlendMode(.normal)

        default:
            break // full_bleed: the picture fills the frame.
        }
    }

    private static func drawDecor(
        _ decor: String,
        palette: Palette,
        canvas: CGSize,
        scale s: CGFloat,
        in cg: CGContext
    ) {
        switch decor {
        case "corner_brackets":
            break // already drawn as the frame

        case "ripple":
            cg.setStrokeColor(palette.accent.withAlphaComponent(0.35).cgColor)
            cg.setLineWidth(3 * s)
            let centre = CGPoint(x: canvas.width * 0.82, y: canvas.height * 0.18)
            for i in 1...3 {
                let radius = 60 * s * CGFloat(i)
                cg.strokeEllipse(in: CGRect(
                    x: centre.x - radius, y: centre.y - radius,
                    width: radius * 2, height: radius * 2))
            }

        case "accent_bar":
            cg.setFillColor(palette.accent.cgColor)
            let barWidth = 160 * s
            let barHeight = 10 * s
            let rect = CGRect(x: (canvas.width - barWidth) / 2,
                              y: canvas.height - 96 * s,
                              width: barWidth, height: barHeight)
            cg.addPath(UIBezierPath(roundedRect: rect, cornerRadius: barHeight / 2).cgPath)
            cg.fillPath()

        case "wave_line":
            cg.setStrokeColor(palette.secondary.withAlphaComponent(0.7).cgColor)
            cg.setLineWidth(4 * s)
            let y = canvas.height * 0.12
            let amplitude = 18 * s
            let wavelength = canvas.width / 4
            cg.move(to: CGPoint(x: 0, y: y))
            var x: CGFloat = 0
            while x <= canvas.width {
                cg.addLine(to: CGPoint(x: x, y: y + amplitude * sin(2 * .pi * x / wavelength)))
                x += wavelength / 8
            }
            cg.strokePath()

        case "sprig":
            cg.setStrokeColor(palette.primary.withAlphaComponent(0.8).cgColor)
            cg.setLineWidth(4 * s)
            let baseX = canvas.width * 0.12
            let baseY = canvas.height * 0.9
            cg.move(to: CGPoint(x: baseX, y: baseY))
            cg.addLine(to: CGPoint(x: baseX, y: baseY - 90 * s))
            for i in 0..<3 {
                let leafY = baseY - (20 + CGFloat(i) * 26) * s
                cg.move(to: CGPoint(x: baseX, y: leafY))
                cg.addLine(to: CGPoint(x: baseX + 30 * s, y: leafY - 16 * s))
                cg.move(to: CGPoint(x: baseX, y: leafY))
                cg.addLine(to: CGPoint(x: baseX - 30 * s, y: leafY - 16 * s))
            }
            cg.strokePath()

        case "kicker":
            cg.setFillColor(palette.primary.cgColor)
            cg.fill(CGRect(x: 56 * s, y: canvas.height * 0.08,
                           width: 96 * s, height: 6 * s))

        case "scrims":
            // Top and bottom gradients: they darken the frame edges so white
            // text sits on something whatever the footage is doing underneath.
            drawVerticalGradient(
                in: cg,
                rect: CGRect(x: 0, y: 0, width: canvas.width, height: canvas.height * 0.22),
                from: UIColor.black.withAlphaComponent(0.55),
                to: .clear
            )
            drawVerticalGradient(
                in: cg,
                rect: CGRect(x: 0, y: canvas.height * 0.72,
                             width: canvas.width, height: canvas.height * 0.28),
                from: .clear,
                to: UIColor.black.withAlphaComponent(0.67)
            )

        default:
            break
        }
    }

    private static func drawVerticalGradient(
        in cg: CGContext, rect: CGRect, from: UIColor, to: UIColor
    ) {
        guard let gradient = CGGradient(
            colorsSpace: CGColorSpaceCreateDeviceRGB(),
            colors: [from.cgColor, to.cgColor] as CFArray,
            locations: [0, 1]
        ) else { return }
        cg.saveGState()
        cg.clip(to: rect)
        cg.drawLinearGradient(
            gradient,
            start: CGPoint(x: rect.minX, y: rect.minY),
            end: CGPoint(x: rect.minX, y: rect.maxY),
            options: []
        )
        cg.restoreGState()
    }

    private static func canvasColor(
        _ template: RenderManifest.Template, palette: Palette
    ) -> UIColor {
        switch template.canvas {
        case "black": return .black
        case "palette_light": return palette.neutral
        case "palette_dark": return palette.primary.withAlphaComponent(1).darkened(0.6)
        default: return .clear
        }
    }

    private static func transparentFormat() -> UIGraphicsImageRendererFormat {
        let format = UIGraphicsImageRendererFormat.default()
        format.opaque = false
        format.scale = 1
        return format
    }
}

private extension UIColor {
    func darkened(_ amount: CGFloat) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        let factor = 1 - min(max(amount, 0), 1)
        return UIColor(red: r * factor, green: g * factor, blue: b * factor, alpha: a)
    }
}
