package com.rclipper.app.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Draws the motion-graphic template layer.
 *
 * The four templates in `src/config/motionTemplates.ts` are a frame plus a set
 * of decor ids, rendered by `remotion/TemplatedVideo.tsx` and
 * `DecorativeGraphics.tsx` over the master and under the captions. This redraws
 * the same frames and decor with Canvas.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO. The Remotion decor animates — the ripple
 * breathes, the accent bar wipes in. Those animations are reproduced here only
 * where they are a simple function of time; anything that depends on Remotion's
 * spring physics is drawn in its settled state. That is a visible difference
 * from the Mac export on the decorated templates, it is recorded in
 * `docs/on-device-rendering.md`, and it is why the comparison fixtures include
 * one render per template rather than only `none`.
 *
 * The template layer is static per ratio when nothing animates, so the bitmap
 * is drawn once and reused for every frame — the common case, `templateId
 * "none"`, costs nothing at all.
 */
public final class TemplatePainter {

    private static final float REFERENCE_HEIGHT = 1920f;

    private final RenderManifest.Template template;
    private final int width;
    private final int height;
    private final float scale;
    private Bitmap cached;

    public TemplatePainter(RenderManifest.Template template, int width, int height) {
        this.template = template;
        this.width = width;
        this.height = height;
        this.scale = height / REFERENCE_HEIGHT;
    }

    /** True when there is nothing to draw, so the overlay can be skipped. */
    public boolean isEmpty() {
        return "none".equals(template.id)
            || ("full_bleed".equals(template.frame) && template.decor.isEmpty());
    }

    public void release() {
        if (cached != null && !cached.isRecycled()) cached.recycle();
        cached = null;
    }

    /** The template layer, drawn once and cached. Null when there is nothing. */
    public Bitmap draw() {
        if (isEmpty()) return null;
        if (cached != null) return cached;

        cached = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(cached);
        cached.eraseColor(Color.TRANSPARENT);

        drawFrame(canvas);
        for (String decor : template.decor) drawDecor(canvas, decor);

        return cached;
    }

    private void drawFrame(Canvas canvas) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);

        switch (template.frame) {
            case "corner_bracket": {
                // Four white L-shaped brackets inset from the frame edge.
                paint.setColor(Color.WHITE);
                paint.setStrokeWidth(6f * scale);
                float inset = 48f * scale;
                float arm = 120f * scale;
                drawBracket(canvas, paint, inset, inset, arm, 1, 1);
                drawBracket(canvas, paint, width - inset, inset, arm, -1, 1);
                drawBracket(canvas, paint, inset, height - inset, arm, 1, -1);
                drawBracket(canvas, paint, width - inset, height - inset, arm, -1, -1);
                break;
            }
            case "hairline_border": {
                paint.setColor(withAlpha(template.neutral, 0.55f));
                paint.setStrokeWidth(2f * scale);
                float inset = 36f * scale;
                canvas.drawRect(inset, inset, width - inset, height - inset, paint);
                break;
            }
            case "rounded_inset": {
                // The video sits inside a rounded window; everything outside it
                // is the template canvas. Punching the window out of a filled
                // rect is what makes the inset read as a frame rather than a
                // border drawn on top of the picture.
                Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
                fill.setColor(canvasColor());
                canvas.drawRect(0, 0, width, height, fill);

                Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
                clear.setXfermode(new android.graphics.PorterDuffXfermode(
                    android.graphics.PorterDuff.Mode.CLEAR));
                float inset = 64f * scale;
                float radius = 48f * scale;
                canvas.drawRoundRect(
                    new RectF(inset, inset, width - inset, height - inset),
                    radius, radius, clear
                );
                break;
            }
            case "polaroid": {
                Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
                fill.setColor(Color.WHITE);
                canvas.drawRect(0, 0, width, height, fill);

                Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
                clear.setXfermode(new android.graphics.PorterDuffXfermode(
                    android.graphics.PorterDuff.Mode.CLEAR));
                float side = 56f * scale;
                // A polaroid's bottom border is deeper than its sides.
                canvas.drawRect(side, side, width - side, height - side * 4f, clear);
                break;
            }
            default:
                break; // full_bleed: the picture fills the frame.
        }
    }

    private void drawBracket(
        Canvas canvas, Paint paint, float x, float y, float arm, int dx, int dy
    ) {
        Path path = new Path();
        path.moveTo(x + dx * arm, y);
        path.lineTo(x, y);
        path.lineTo(x, y + dy * arm);
        canvas.drawPath(path, paint);
    }

    private void drawDecor(Canvas canvas, String decor) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        switch (decor) {
            case "corner_brackets":
                break; // already drawn as the frame
            case "hairline_border": {
                // The editorial look's thin line around the picture. It is a
                // DECOR id in motionTemplates.ts (that template's frame is
                // full_bleed), so the frame switch above never reaches it.
                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(withAlpha(template.neutral, 0.55f));
                paint.setStrokeWidth(2f * scale);
                float inset = 36f * scale;
                canvas.drawRect(inset, inset, width - inset, height - inset, paint);
                break;
            }
            case "ripple": {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(3f * scale);
                paint.setColor(withAlpha(template.accent, 0.35f));
                float cx = width * 0.82f;
                float cy = height * 0.18f;
                for (int i = 1; i <= 3; i++) {
                    canvas.drawCircle(cx, cy, 60f * scale * i, paint);
                }
                break;
            }
            case "accent_bar": {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(template.accent);
                float barWidth = 160f * scale;
                float barHeight = 10f * scale;
                canvas.drawRoundRect(
                    new RectF(
                        (width - barWidth) / 2f,
                        height - 96f * scale,
                        (width + barWidth) / 2f,
                        height - 96f * scale + barHeight
                    ),
                    barHeight / 2f, barHeight / 2f, paint
                );
                break;
            }
            case "wave_line": {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(4f * scale);
                paint.setColor(withAlpha(template.secondary, 0.7f));
                Path path = new Path();
                float y = height * 0.12f;
                float amplitude = 18f * scale;
                float wavelength = width / 4f;
                path.moveTo(0, y);
                for (float x = 0; x <= width; x += wavelength / 8f) {
                    path.lineTo(x, y + (float) (amplitude * Math.sin(2 * Math.PI * x / wavelength)));
                }
                canvas.drawPath(path, paint);
                break;
            }
            case "sprig": {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(4f * scale);
                paint.setColor(withAlpha(template.primary, 0.8f));
                float baseX = width * 0.12f;
                float baseY = height * 0.9f;
                canvas.drawLine(baseX, baseY, baseX, baseY - 90f * scale, paint);
                for (int i = 0; i < 3; i++) {
                    float leafY = baseY - (20f + i * 26f) * scale;
                    canvas.drawLine(baseX, leafY, baseX + 30f * scale, leafY - 16f * scale, paint);
                    canvas.drawLine(baseX, leafY, baseX - 30f * scale, leafY - 16f * scale, paint);
                }
                break;
            }
            case "kicker": {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(template.primary);
                float kickerWidth = 96f * scale;
                float kickerHeight = 6f * scale;
                canvas.drawRect(
                    56f * scale, height * 0.08f,
                    56f * scale + kickerWidth, height * 0.08f + kickerHeight,
                    paint
                );
                break;
            }
            case "scrims": {
                // Top and bottom gradients, the editorial look's readability
                // trick: they darken the frame edges so white text sits on
                // something whatever the footage is doing underneath.
                Paint top = new Paint();
                top.setShader(new LinearGradient(
                    0, 0, 0, height * 0.22f,
                    Color.argb(140, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP));
                canvas.drawRect(0, 0, width, height * 0.22f, top);

                Paint bottom = new Paint();
                bottom.setShader(new LinearGradient(
                    0, height * 0.72f, 0, height,
                    Color.TRANSPARENT, Color.argb(170, 0, 0, 0), Shader.TileMode.CLAMP));
                canvas.drawRect(0, height * 0.72f, width, height, bottom);
                break;
            }
            default:
                break;
        }
    }

    private int canvasColor() {
        switch (template.canvas) {
            case "black": return Color.BLACK;
            case "palette_light": return lighten(template.neutral, 0.0f);
            case "palette_dark": return darken(template.primary, 0.6f);
            default: return Color.TRANSPARENT;
        }
    }

    private static int withAlpha(int color, float alpha) {
        return Color.argb(
            Math.round(255 * MotionMath.clamp(alpha, 0f, 1f)),
            Color.red(color), Color.green(color), Color.blue(color)
        );
    }

    private static int lighten(int color, float amount) {
        float a = MotionMath.clamp(amount, 0f, 1f);
        return Color.rgb(
            Math.round(Color.red(color) + (255 - Color.red(color)) * a),
            Math.round(Color.green(color) + (255 - Color.green(color)) * a),
            Math.round(Color.blue(color) + (255 - Color.blue(color)) * a)
        );
    }

    private static int darken(int color, float amount) {
        float a = 1f - MotionMath.clamp(amount, 0f, 1f);
        return Color.rgb(
            Math.round(Color.red(color) * a),
            Math.round(Color.green(color) * a),
            Math.round(Color.blue(color) * a)
        );
    }
}
