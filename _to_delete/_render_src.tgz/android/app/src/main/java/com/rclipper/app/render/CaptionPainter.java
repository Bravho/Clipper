package com.rclipper.app.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws the caption stack exactly as `remotion/CaptionOverlay.tsx` draws it.
 *
 * The shipped captions come out of a headless browser rendering a flex column
 * of styled spans. A phone has no browser in the render path, so this redraws
 * the same layout with Canvas. Every number is from
 * `src/lib/mobile/deviceRenderCaptions.ts`, which is in turn read off the
 * overlay component — so a caption that sits in the wrong place here is a bug
 * with a specific number attached, not a matter of taste.
 *
 * The reference frame is 1080x1920 and every length is multiplied by
 * `height / 1920`, which is the overlay's own single scaling rule.
 */
public final class CaptionPainter {

    // ── Layout, from CAPTION_LAYOUT ─────────────────────────────────────────
    private static final float REFERENCE_HEIGHT = 1920f;
    private static final float STACK_BOTTOM = 150f;
    private static final float LINE_GAP = 16f;
    private static final float SIDE_PADDING = 40f;
    private static final int MAX_LINES_PER_CUE = 2;
    private static final float LINE_HEIGHT = 1.25f;
    private static final float STROKE_WIDTH = 6f;
    private static final float SHADOW_DX = 3f;
    private static final float SHADOW_DY = 3f;
    private static final float SHADOW_BLUR = 6f;
    private static final float PLATE_RADIUS = 18f;
    private static final float PLATE_PADDING_Y = 10f;
    private static final float PLATE_PADDING_X = 26f;
    private static final float APPEAR_SECONDS = 0.15f;
    private static final float APPEAR_SCALE_FROM = 0.96f;
    private static final int PLATE_COLOR = Color.argb(107, 0, 0, 0);      // rgba(0,0,0,0.42)
    private static final int SHADOW_COLOR = Color.argb(230, 0, 0, 0);     // rgba(0,0,0,0.9)

    private final int width;
    private final int height;
    private final float scale;
    private final List<String> languages;
    private final List<RenderManifest.Caption> captions;

    /**
     * Reusing one bitmap across frames matters: a 1080x1920 ARGB bitmap is
     * 8 MB, and allocating one per frame at 30 fps is how a mid-range Android
     * phone ends up thermally throttled halfway through an export.
     */
    private final Bitmap canvasBitmap;
    private final Canvas canvas;
    private final TextPaint fillPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint strokePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint platePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public CaptionPainter(
        int width, int height, List<String> languages, List<RenderManifest.Caption> captions
    ) {
        this.width = width;
        this.height = height;
        this.scale = height / REFERENCE_HEIGHT;
        this.languages = languages;
        this.captions = captions;
        this.canvasBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        this.canvas = new Canvas(canvasBitmap);
        this.platePaint.setColor(PLATE_COLOR);
    }

    public void release() {
        if (!canvasBitmap.isRecycled()) canvasBitmap.recycle();
    }

    /** The cue showing at `seconds`, or null. Matches the overlay's `find`. */
    public RenderManifest.Caption activeCaption(double seconds) {
        for (RenderManifest.Caption caption : captions) {
            if (seconds >= caption.startSeconds && seconds <= caption.endSeconds) return caption;
        }
        return null;
    }

    public boolean hasCaptions() {
        return !captions.isEmpty() && !languages.isEmpty();
    }

    /**
     * Draw the caption stack for `seconds` onto a transparent bitmap, or return
     * null when nothing is showing so the caller can skip the overlay entirely
     * for that frame.
     */
    public Bitmap draw(double seconds) {
        RenderManifest.Caption active = activeCaption(seconds);
        if (active == null) return null;

        // Linear fade-in over 150 ms with a scale pop 0.96 -> 1.00, anchored at
        // the bottom centre of the stack.
        float appear = MotionMath.clamp(
            (float) ((seconds - active.startSeconds) / APPEAR_SECONDS), 0f, 1f);
        float popScale = APPEAR_SCALE_FROM + (1f - APPEAR_SCALE_FROM) * appear;

        canvasBitmap.eraseColor(Color.TRANSPARENT);

        List<LanguageLine> lines = layoutLines(active);
        if (lines.isEmpty()) return null;

        float gap = LINE_GAP * scale;
        float stackHeight = 0f;
        for (int i = 0; i < lines.size(); i++) {
            stackHeight += lines.get(i).plateHeight();
            if (i > 0) stackHeight += gap;
        }

        float bottom = height - STACK_BOTTOM * scale;
        float top = bottom - stackHeight;

        canvas.save();
        canvas.translate(width / 2f, bottom);
        canvas.scale(popScale, popScale);
        canvas.translate(-width / 2f, -bottom);

        int alpha = Math.round(255 * appear);
        float y = top;
        for (LanguageLine line : lines) {
            drawLine(line, y, alpha);
            y += line.plateHeight() + gap;
        }
        canvas.restore();

        return canvasBitmap;
    }

    // ── internals ───────────────────────────────────────────────────────────

    private static final class LanguageLine {
        StaticLayout layout;
        float fontSize;
        int color;
        float plateWidth;

        float plateHeight() {
            return layout.getHeight() + 2 * PLATE_PADDING_Y_SCALED;
        }

        static float PLATE_PADDING_Y_SCALED;
    }

    /**
     * Lay out one wrapped block per requested language, in the overlay's order
     * (Thai, English, Chinese), skipping languages this cue has no text for.
     */
    private List<LanguageLine> layoutLines(RenderManifest.Caption caption) {
        List<LanguageLine> lines = new ArrayList<>();
        LanguageLine.PLATE_PADDING_Y_SCALED = PLATE_PADDING_Y * scale;

        int maxTextWidth = Math.round(width - 2 * SIDE_PADDING * scale - 2 * PLATE_PADDING_X * scale);
        if (maxTextWidth <= 0) return lines;

        for (String language : languages) {
            String text = caption.textFor(language);
            if (text == null || text.trim().isEmpty()) continue;

            LanguageLine line = new LanguageLine();
            line.fontSize = fontSizeFor(language) * scale;
            line.color = colorFor(language);

            TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            paint.setTypeface(typefaceFor(language));
            paint.setTextSize(line.fontSize);
            paint.setColor(line.color);

            StaticLayout layout = StaticLayout.Builder
                .obtain(text, 0, text.length(), paint, maxTextWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, LINE_HEIGHT)
                .setMaxLines(MAX_LINES_PER_CUE)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .setIncludePad(false)
                .build();

            line.layout = layout;
            float widest = 0f;
            for (int i = 0; i < layout.getLineCount(); i++) {
                widest = Math.max(widest, layout.getLineWidth(i));
            }
            line.plateWidth = widest + 2 * PLATE_PADDING_X * scale;
            lines.add(line);
        }
        return lines;
    }

    private void drawLine(LanguageLine line, float top, int alpha) {
        float plateLeft = (width - line.plateWidth) / 2f;
        float plateTop = top;
        float plateBottom = top + line.plateHeight();

        platePaint.setAlpha(Math.round(Color.alpha(PLATE_COLOR) * (alpha / 255f)));
        canvas.drawRoundRect(
            new RectF(plateLeft, plateTop, plateLeft + line.plateWidth, plateBottom),
            PLATE_RADIUS * scale, PLATE_RADIUS * scale, platePaint
        );

        // `paint-order: stroke fill` in the overlay: the black outline is drawn
        // UNDER the glyph fill so the stroke never eats into the letterforms.
        TextPaint source = line.layout.getPaint();

        strokePaint.set(source);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(STROKE_WIDTH * scale);
        strokePaint.setColor(Color.BLACK);
        strokePaint.setAlpha(alpha);
        strokePaint.setShadowLayer(
            SHADOW_BLUR * scale, SHADOW_DX * scale, SHADOW_DY * scale, SHADOW_COLOR);

        fillPaint.set(source);
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(line.color);
        fillPaint.setAlpha(alpha);

        float textLeft = (width - line.layout.getWidth()) / 2f;
        float textTop = plateTop + PLATE_PADDING_Y * scale;

        drawLayoutWithPaint(line, textLeft, textTop, strokePaint);
        drawLayoutWithPaint(line, textLeft, textTop, fillPaint);
    }

    /**
     * StaticLayout draws with the paint it was built with, so a two-pass
     * stroke-then-fill needs the layout's paint swapped between passes. Mutating
     * and restoring the same paint object is cheaper than rebuilding the layout,
     * which would re-run line breaking twice per caption per frame.
     */
    private void drawLayoutWithPaint(LanguageLine line, float left, float top, TextPaint paint) {
        TextPaint layoutPaint = line.layout.getPaint();
        Typeface typeface = layoutPaint.getTypeface();
        float size = layoutPaint.getTextSize();
        int color = layoutPaint.getColor();
        Paint.Style style = layoutPaint.getStyle();
        float strokeWidth = layoutPaint.getStrokeWidth();

        layoutPaint.set(paint);
        layoutPaint.setTypeface(typeface);
        layoutPaint.setTextSize(size);

        canvas.save();
        canvas.translate(left, top);
        line.layout.draw(canvas);
        canvas.restore();

        layoutPaint.setColor(color);
        layoutPaint.setStyle(style);
        layoutPaint.setStrokeWidth(strokeWidth);
        layoutPaint.clearShadowLayer();
    }

    /** Mirrors `CAPTION_LANGUAGE_STYLES` font sizes at the 1080x1920 reference. */
    private static float fontSizeFor(String language) {
        switch (language) {
            case "th": return 72f;
            case "en": return 64f;
            case "zh": return 58f;
            default: return 64f;
        }
    }

    /** Thai and English are white; Chinese is yellow. */
    private static int colorFor(String language) {
        return "zh".equals(language) ? Color.rgb(255, 255, 0) : Color.WHITE;
    }

    /**
     * Android has no Sarabun or Noto Sans SC in its system fonts, but its
     * default family already covers Thai and Simplified Chinese through font
     * fallback, and the overlay's stacks all end in a generic family. Weight 800
     * maps to BOLD, which is the nearest thing a stock Android typeface offers.
     */
    private static Typeface typefaceFor(String language) {
        return Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
    }
}
