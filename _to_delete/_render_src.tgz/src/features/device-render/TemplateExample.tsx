"use client";

import { useEffect, useState } from "react";

import type { MotionTemplate } from "@/config/motionTemplates";

/**
 * A still example frame of a Look, drawn from the person's own material.
 *
 * WHY DRAWN HERE AND NOT A STOCK PICTURE. A template is judged against the
 * footage it will sit on, so the example uses the first photo or clip frame
 * of THIS request, at the shape being made. The frame and decor are the same
 * geometry the phone renderer paints (`android/.../render/TemplatePainter.java`,
 * itself a port of `remotion/DecorativeGraphics.tsx`): same insets, strokes and
 * placements on a 1920-high reference, scaled down. The decor that animates in
 * the final video is shown in its settled state, as the phone draws it.
 *
 * The palette is the default one. The real render derives a palette from the
 * script, so accent colours can differ; the frame and placement cannot.
 */

// `DEFAULT_PALETTE` in src/lib/ai/paletteService.ts — copied rather than
// imported because that module is server-side (it calls Gemini).
const PALETTE = { primary: "#FF6B35", secondary: "#FFB703", accent: "#06D6A0", neutral: "#FFFFFF" };

const REFERENCE_HEIGHT = 1920;

function ratioSize(ratio: string, height: number): { width: number; height: number } {
  const [w, h] = ratio.split(":").map(Number);
  const width = w > 0 && h > 0 ? Math.round((height * w) / h) : Math.round((height * 9) / 16);
  return { width, height };
}

function withAlpha(hex: string, alpha: number): string {
  const value = parseInt(hex.slice(1), 16);
  return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${alpha})`;
}

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => resolve(null);
    image.src = url;
  });
}

/** Cover-fit the picture into the rect, the way the renderer fills a shot. */
function drawCover(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement | null,
  x: number,
  y: number,
  width: number,
  height: number
) {
  if (!image) {
    const gradient = ctx.createLinearGradient(x, y, x + width, y + height);
    gradient.addColorStop(0, "#3a4455");
    gradient.addColorStop(1, "#141821");
    ctx.fillStyle = gradient;
    ctx.fillRect(x, y, width, height);
    return;
  }
  const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
  const drawWidth = image.naturalWidth * scale;
  const drawHeight = image.naturalHeight * scale;
  ctx.drawImage(image, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
}

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

function canvasColor(template: MotionTemplate): string | null {
  switch (template.canvas) {
    case "black":
      return "#000000";
    case "palette_light":
      return PALETTE.neutral;
    case "palette_dark":
      return withAlpha(PALETTE.primary, 1);
    default:
      return null;
  }
}

/** Paint one example frame. Exported for reuse; the component below calls it. */
export function paintTemplateExample(
  canvas: HTMLCanvasElement,
  template: MotionTemplate,
  picture: HTMLImageElement | null,
  sampleCaption: string
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const { width, height } = canvas;
  const s = height / REFERENCE_HEIGHT;

  // ── the picture, inside the frame's window ──
  if (template.frame === "rounded_inset") {
    ctx.fillStyle = canvasColor(template) ?? "#000";
    ctx.fillRect(0, 0, width, height);
    const inset = 64 * s;
    ctx.save();
    roundRectPath(ctx, inset, inset, width - inset * 2, height - inset * 2, 48 * s);
    ctx.clip();
    drawCover(ctx, picture, inset, inset, width - inset * 2, height - inset * 2);
    ctx.restore();
  } else if (template.frame === "polaroid") {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);
    const side = 56 * s;
    drawCover(ctx, picture, side, side, width - side * 2, height - side * 5);
  } else {
    drawCover(ctx, picture, 0, 0, width, height);
  }

  // ── frame strokes ──
  if (template.frame === "corner_bracket") {
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 6 * s;
    const inset = 48 * s;
    const arm = 120 * s;
    const bracket = (x: number, y: number, dx: number, dy: number) => {
      ctx.beginPath();
      ctx.moveTo(x + dx * arm, y);
      ctx.lineTo(x, y);
      ctx.lineTo(x, y + dy * arm);
      ctx.stroke();
    };
    bracket(inset, inset, 1, 1);
    bracket(width - inset, inset, -1, 1);
    bracket(inset, height - inset, 1, -1);
    bracket(width - inset, height - inset, -1, -1);
  }

  // ── decor ──
  for (const decor of template.decor) {
    switch (decor) {
      case "ripple": {
        ctx.strokeStyle = withAlpha(PALETTE.accent, 0.35);
        ctx.lineWidth = 3 * s;
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath();
          ctx.arc(width * 0.82, height * 0.18, 60 * s * i, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
      }
      case "accent_bar": {
        ctx.fillStyle = PALETTE.accent;
        const barWidth = 160 * s;
        const barHeight = 10 * s;
        roundRectPath(ctx, (width - barWidth) / 2, height - 96 * s, barWidth, barHeight, barHeight / 2);
        ctx.fill();
        break;
      }
      case "wave_line": {
        ctx.strokeStyle = withAlpha(PALETTE.secondary, 0.7);
        ctx.lineWidth = 4 * s;
        const y = height * 0.12;
        const amplitude = 18 * s;
        const wavelength = width / 4;
        ctx.beginPath();
        ctx.moveTo(0, y);
        for (let x = 0; x <= width; x += wavelength / 8) {
          ctx.lineTo(x, y + amplitude * Math.sin((2 * Math.PI * x) / wavelength));
        }
        ctx.stroke();
        break;
      }
      case "sprig": {
        ctx.strokeStyle = withAlpha(PALETTE.primary, 0.8);
        ctx.lineWidth = 4 * s;
        const baseX = width * 0.12;
        const baseY = height * 0.9;
        ctx.beginPath();
        ctx.moveTo(baseX, baseY);
        ctx.lineTo(baseX, baseY - 90 * s);
        for (let i = 0; i < 3; i++) {
          const leafY = baseY - (20 + i * 26) * s;
          ctx.moveTo(baseX, leafY);
          ctx.lineTo(baseX + 30 * s, leafY - 16 * s);
          ctx.moveTo(baseX, leafY);
          ctx.lineTo(baseX - 30 * s, leafY - 16 * s);
        }
        ctx.stroke();
        break;
      }
      case "hairline_border": {
        ctx.strokeStyle = withAlpha(PALETTE.neutral, 0.55);
        ctx.lineWidth = 2 * s;
        const inset = 36 * s;
        ctx.strokeRect(inset, inset, width - inset * 2, height - inset * 2);
        break;
      }
      case "kicker": {
        ctx.fillStyle = PALETTE.primary;
        ctx.fillRect(56 * s, height * 0.08, 96 * s, 6 * s);
        break;
      }
      case "scrims": {
        const top = ctx.createLinearGradient(0, 0, 0, height * 0.22);
        top.addColorStop(0, "rgba(0,0,0,0.55)");
        top.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = top;
        ctx.fillRect(0, 0, width, height * 0.22);
        const bottom = ctx.createLinearGradient(0, height * 0.72, 0, height);
        bottom.addColorStop(0, "rgba(0,0,0,0)");
        bottom.addColorStop(1, "rgba(0,0,0,0.67)");
        ctx.fillStyle = bottom;
        ctx.fillRect(0, height * 0.72, width, height * 0.28);
        break;
      }
      default:
        break;
    }
  }

  // ── a sample caption, where the real ones sit ──
  if (sampleCaption) {
    const fontSize = Math.max(10, Math.round(58 * s));
    ctx.font = `700 ${fontSize}px system-ui, -apple-system, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.lineWidth = Math.max(2, 8 * s);
    ctx.strokeStyle = "rgba(0,0,0,0.75)";
    ctx.fillStyle = "#ffffff";
    const y = height - 260 * s;
    ctx.strokeText(sampleCaption, width / 2, y, width * 0.86);
    ctx.fillText(sampleCaption, width / 2, y, width * 0.86);
  }
}

export function TemplateExample({
  template,
  pictureUrl,
  ratio,
  sampleCaption = "Your caption appears here",
  height = 240,
}: {
  template: MotionTemplate;
  pictureUrl: string | null;
  ratio: string;
  sampleCaption?: string;
  /** Display height in CSS pixels; drawn at twice that for a sharp retina tile. */
  height?: number;
}) {
  const [src, setSrc] = useState<string | null>(null);
  const size = ratioSize(ratio, height);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const picture = pictureUrl ? await loadImage(pictureUrl) : null;
      if (cancelled) return;
      const canvas = document.createElement("canvas");
      const drawn = ratioSize(ratio, height * 2);
      canvas.width = drawn.width;
      canvas.height = drawn.height;
      paintTemplateExample(canvas, template, picture, sampleCaption);
      try {
        setSrc(canvas.toDataURL("image/jpeg", 0.85));
      } catch {
        // A tainted canvas cannot be exported. The picture is always a local
        // object URL, so this should not happen; show the placeholder if it does.
        setSrc(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [height, pictureUrl, ratio, sampleCaption, template]);

  return src ? (
    // eslint-disable-next-line @next/next/no-img-element -- a data URL drawn on the phone
    <img
      src={src}
      alt={`Example frame: ${template.id}`}
      width={size.width}
      height={size.height}
      className="studio-look-frame"
    />
  ) : (
    <span
      className="studio-look-frame studio-look-frame-empty"
      style={{ width: size.width, height: size.height }}
      aria-hidden
    />
  );
}
