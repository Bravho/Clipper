import { RequestStatus } from "@/domain/enums/RequestStatus";
import { EditorType } from "@/domain/enums/EditorType";
import { ClipRequest, CreateClipRequestInput } from "@/domain/models/ClipRequest";
import { ClipRequestFormValues } from "@/features/requests/validation/clipRequestSchema";
import { CREDITS_CONFIG } from "@/config/credits";
import {
  clipRequestRepository,
  requestStatusHistoryRepository,
  userRepository,
} from "@/repositories";
import { creditService } from "@/services/CreditService";
import { uploadService } from "@/services/UploadService";
import { paidExportRetentionService } from "@/services/PaidExportRetentionService";
import type { AppLocale } from "@/i18n/config";

/**
 * ClipRequestService — manages the full lifecycle of a clip request
 * from draft creation through submission.
 *
 * Business rules enforced here:
 * - A requester must have sufficient credits before submission.
 * - Credits are deducted atomically with status change to Submitted.
 * - Legal confirmations (credit + rights) are required at submission.
 * - A draft may be updated freely until submitted.
 * - Only Draft requests may be submitted.
 *
 * TODO: PostgreSQL — wrap credit deduction + status update in a DB transaction
 *   to prevent partial state (e.g., credits deducted but status not updated).
 */
export class ClipRequestService {
  /**
   * Create a new draft request for a requester.
   * Does NOT charge credits — credits are charged at submission.
   */
  async createDraft(
    userId: string,
    data: ClipRequestFormValues,
    contentLanguage: AppLocale = "th"
  ): Promise<ClipRequest> {
    const input: CreateClipRequestInput = {
      userId,
      title: data.title,
      placeName: data.placeName,
      latitude: data.latitude,
      longitude: data.longitude,
      description: data.description,
      targetAudience: data.targetAudience,
      targetPlatforms: data.targetPlatforms,
      preferredStyle: "",
      preferredLanguage: contentLanguage,
      durationSeconds: data.durationSeconds,
    };

    const request = await clipRequestRepository.create(input);

    // Log Draft status history entry
    await requestStatusHistoryRepository.create({
      requestId: request.id,
      status: RequestStatus.Draft,
      note: null,
      changedAt: request.createdAt,
    });

    return request;
  }

  /**
   * Update a draft request.
   * Only allowed while status is Draft.
   */
  async updateDraft(
    requestId: string,
    userId: string,
    data: Partial<ClipRequestFormValues>
  ): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    if (existing.status !== RequestStatus.Draft) {
      throw new Error("Only Draft requests can be edited.");
    }

    return clipRequestRepository.update(requestId, data);
  }

  /**
   * Submit a draft request.
   *
   * Validates:
   * 1. Request exists and belongs to userId
   * 2. Request is currently in Draft status
   * 3. Both legal confirmations are true
   * 4. Requester has sufficient credits
   *
   * On success:
   * - Deducts credits
   * - Updates status to Submitted
   * - Records status history entry
   * - Sets submittedAt timestamp
   */
  async submitRequest(
    requestId: string,
    userId: string,
    creditConfirmed: boolean,
    rightsConfirmed: boolean
  ): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    if (existing.status !== RequestStatus.Draft) {
      throw new Error("Only Draft requests can be submitted.");
    }

    if (!creditConfirmed) {
      throw new Error("Credit use confirmation is required to submit.");
    }

    if (!rightsConfirmed) {
      throw new Error("Rights confirmation is required to submit.");
    }

    // Trial model: a user's FIRST request generates for free (preview only) —
    // it is not charged at submission, and its clean download stays locked until
    // the user pays via unlockDownload(). Every subsequent request is charged at
    // submission and its download is unlocked immediately.
    const isTrial = await this.isFirstRequest(userId);

    // Idempotent charge: never bill the same request twice. This covers a resumed
    // or retried submit, and the partial-failure case where a previous attempt
    // deducted credits but crashed before flipping the status out of Draft — on
    // the retry the status is still Draft, but the charge already exists.
    const alreadyCharged = await creditService.hasChargeForRequest(userId, requestId);

    if (!isTrial && !alreadyCharged) {
      const canAfford = await creditService.hasEnoughCredits(
        userId,
        CREDITS_CONFIG.REQUEST_COST_CREDITS
      );
      if (!canAfford) {
        throw new Error(
          `Insufficient credits. You need ${CREDITS_CONFIG.REQUEST_COST_CREDITS} credits to submit a request.`
        );
      }

      // Deduct credits
      // TODO: PostgreSQL — wrap this and the status update in a DB transaction
      //   to prevent partial state if either operation fails.
      await creditService.deductCredits(
        userId,
        CREDITS_CONFIG.REQUEST_COST_CREDITS,
        `Clip request: ${existing.title}`,
        requestId
      );
    }

    const now = new Date();
    const queuePos = await this.estimateQueuePosition();

    // Update request to Submitted, recording legal confirmations + timestamps
    // TODO: PostgreSQL — wrap this entire block in a DB transaction
    const submitted = await clipRequestRepository.updateStatus(
      requestId,
      RequestStatus.Submitted,
      {
        submittedAt: now,
        queuePosition: queuePos,
        creditConfirmed: true,
        rightsConfirmed: true,
        isTrialRequest: isTrial,
        // Paid-at-submit requests are immediately downloadable; the free trial
        // request is not until unlockDownload() is paid.
        downloadUnlocked: !isTrial,
      }
    );

    // Log status history
    await requestStatusHistoryRepository.create({
      requestId,
      status: RequestStatus.Submitted,
      note: null,
      changedAt: now,
    });

    return submitted;
  }

  /** Get a single request, ensuring it belongs to the specified user. */
  async getOwnedRequest(
    requestId: string,
    userId: string
  ): Promise<ClipRequest> {
    const request = await clipRequestRepository.findById(requestId);
    if (!request) throw new Error("Request not found.");
    if (request.userId !== userId) throw new Error("Access denied.");
    return request;
  }

  /** List all requests for a requester, newest first. */
  async listForUser(userId: string): Promise<ClipRequest[]> {
    return clipRequestRepository.findByUserId(userId);
  }

  /** List active (in-progress) requests for a requester. */
  async listActiveForUser(userId: string): Promise<ClipRequest[]> {
    const active: RequestStatus[] = [
      RequestStatus.Submitted,
      RequestStatus.UnderReview,
      RequestStatus.AcceptedForProduction,
      RequestStatus.Editing,
      RequestStatus.ScheduledForPublishing,
    ];
    return clipRequestRepository.findByUserIdAndStatus(userId, active);
  }

  /**
   * Delete a draft request.
   * Only allowed for Draft status.
   */
  async deleteDraft(requestId: string, userId: string): Promise<void> {
    const existing = await this.getOwnedRequest(requestId, userId);
    if (existing.status !== RequestStatus.Draft) {
      throw new Error("Only Draft requests can be deleted.");
    }
    await uploadService.deleteAssetsByRequestId(requestId);
    await clipRequestRepository.delete(requestId);
  }

  /**
   * Cancel a request that has not yet entered production.
   * Allowed statuses: Draft, Submitted.
   * For Submitted requests, the 10-credit charge is refunded automatically.
   */
  async cancelRequest(requestId: string, userId: string): Promise<void> {
    const existing = await this.getOwnedRequest(requestId, userId);
    const cancellable = [RequestStatus.Draft, RequestStatus.Submitted];
    if (!cancellable.includes(existing.status)) {
      throw new Error("Only Draft or Submitted requests can be cancelled.");
    }
    await uploadService.deleteAssetsByRequestId(requestId);
    await clipRequestRepository.delete(requestId);
  }

  // ── Marketplace methods ─────────────────────────────────────────────────────

  /**
   * Assign an editor and record payment details.
   * Called at checkout after payment is confirmed.
   *
   * Sets:
   * - assignedEditorId, editorType, priceBaht, creditsUsed, discountBaht, amountPaidBaht
   * - Status → Submitted
   */
  async assignEditorAndSubmit(
    requestId: string,
    userId: string,
    editorProfileId: string,
    editorType: EditorType,
    priceBaht: number,
    creditsUsed: number,
    discountBaht: number,
    amountPaidBaht: number,
    rightsConfirmed: boolean
  ): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    if (existing.status !== RequestStatus.Draft) {
      throw new Error("Only Draft requests can be submitted.");
    }
    if (!rightsConfirmed) {
      throw new Error("Rights confirmation is required to submit.");
    }

    const now = new Date();
    const queuePos = await this.estimateQueuePosition();

    const submitted = await clipRequestRepository.updateStatus(
      requestId,
      RequestStatus.Submitted,
      {
        assignedEditorId: editorProfileId,
        editorType,
        priceBaht,
        creditsUsed,
        discountBaht,
        amountPaidBaht,
        submittedAt: now,
        queuePosition: queuePos,
        creditConfirmed: true,
        rightsConfirmed: true,
      }
    );

    await requestStatusHistoryRepository.create({
      requestId,
      status: RequestStatus.Submitted,
      note: `Assigned to editor ${editorProfileId} (${editorType})`,
      changedAt: now,
    });

    return submitted;
  }

  /**
   * Requester approves the delivered clip from a human editor.
   * Advances status to Delivered.
   */
  async approveDelivery(requestId: string, userId: string): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    const allowedStatuses: RequestStatus[] = [
      RequestStatus.ScheduledForPublishing,
      RequestStatus.RevisionRequested,
    ];
    if (!allowedStatuses.includes(existing.status)) {
      throw new Error("Request is not in a state where delivery can be approved.");
    }

    const now = new Date();
    const delivered = await clipRequestRepository.updateStatus(requestId, RequestStatus.Delivered);

    await requestStatusHistoryRepository.create({
      requestId,
      status: RequestStatus.Delivered,
      note: "Requester approved delivery.",
      changedAt: now,
    });

    return delivered;
  }

  /**
   * Requester requests a revision from the human editor.
   * Increments revisionCount and sets status to RevisionRequested.
   */
  async requestRevision(
    requestId: string,
    userId: string,
    reason: string
  ): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    if (existing.status !== RequestStatus.ScheduledForPublishing) {
      throw new Error("Revisions can only be requested after a deliverable has been submitted.");
    }

    const now = new Date();
    const withStatus = await clipRequestRepository.updateStatus(
      requestId,
      RequestStatus.RevisionRequested,
      { revisionCount: (existing.revisionCount ?? 0) + 1 }
    );

    await requestStatusHistoryRepository.create({
      requestId,
      status: RequestStatus.RevisionRequested,
      note: reason,
      changedAt: now,
    });

    return withStatus;
  }

  /**
   * Editor submits a completed deliverable.
   * Moves status to ScheduledForPublishing (awaiting requester review).
   */
  async submitDeliverable(
    requestId: string,
    editorUserId: string,
    assetId: string
  ): Promise<ClipRequest> {
    const request = await clipRequestRepository.findById(requestId);
    if (!request) throw new Error("Request not found.");

    const allowedStatuses: RequestStatus[] = [
      RequestStatus.Editing,
      RequestStatus.AcceptedForProduction,
      RequestStatus.RevisionRequested,
    ];
    if (!allowedStatuses.includes(request.status)) {
      throw new Error("Deliverable can only be submitted while the request is in editing.");
    }

    const now = new Date();
    const updated = await clipRequestRepository.updateStatus(
      requestId,
      RequestStatus.ScheduledForPublishing
    );

    await requestStatusHistoryRepository.create({
      requestId,
      status: RequestStatus.ScheduledForPublishing,
      note: `Deliverable submitted (asset: ${assetId})`,
      changedAt: now,
    });

    return updated;
  }

  /**
   * True when the user has never submitted a request before — i.e. the request
   * they are submitting now is their free trial (first) request.
   *
   * A request counts as "submitted" once it has a submittedAt timestamp, so
   * draft-only requests do not consume the free trial.
   */
  async isFirstRequest(userId: string): Promise<boolean> {
    // Fraud prevention: trial_consumed is set at account creation when the
    // deleted-account registry shows this email/OAuth identity already used
    // its free trial on a previously deleted account.
    const [user, hasSubmittedRequest] = await Promise.all([
      userRepository.findById(userId),
      clipRequestRepository.hasSubmittedRequestByUserId(userId),
    ]);
    if (user?.trialConsumed) return false;
    return !hasSubmittedRequest;
  }

  /**
   * Unlock the clean download for a request by paying the request price.
   *
   * Used for the free trial (first) request, whose download is locked after a
   * free generation. Idempotent: if already unlocked, it charges nothing.
   *
   * Throws "Insufficient credits" (checked before any deduction) so the caller
   * can prompt a top-up.
   */
  async unlockDownload(requestId: string, userId: string): Promise<ClipRequest> {
    const existing = await this.getOwnedRequest(requestId, userId);

    if (existing.downloadUnlocked) {
      return existing; // already paid / unlocked — no double charge
    }

    const price = CREDITS_CONFIG.REQUEST_COST_CREDITS;
    const canAfford = await creditService.hasEnoughCredits(userId, price);
    if (!canAfford) {
      throw new Error(
        `Insufficient credits. You need ${price} credits to unlock the download.`
      );
    }

    await creditService.deductCredits(
      userId,
      price,
      `Unlock download: ${existing.title}`,
      requestId
    );

    const updated = await clipRequestRepository.updateStatus(
      requestId,
      existing.status,
      { downloadUnlocked: true }
    );

    // Distribution paid: relocate the clean masters out of final_exports/ (short
    // window) into paid_exports/ (30-day window), resetting the lifecycle clock.
    // Best-effort — a storage hiccup must never fail an unlock the user paid for;
    // the master would simply expire on its original short window instead.
    try {
      await paidExportRetentionService.promoteForRequest(userId, requestId);
    } catch (err) {
      console.error(
        `[unlockDownload] paid-export promotion failed for ${requestId}:`,
        err instanceof Error ? err.message : err
      );
    }

    return updated;
  }

  /**
   * Estimate a rough queue position for a newly submitted request.
   *
   * TODO: PostgreSQL — implement as:
   *   SELECT COUNT(*) FROM clip_requests
   *   WHERE status IN ('submitted','under_review','accepted_for_production')
   *   AND submitted_at < NOW()
   */
  private async estimateQueuePosition(): Promise<number> {
    return Math.floor(Math.random() * 5) + 3;
  }
}

// Singleton instance
export const clipRequestService = new ClipRequestService();

// Re-exported for convenience — consumers can import either from here or from CreditService directly
export { creditService };
