/**
 * The native plugin version that can render a whole manifest end to end.
 *
 * Its own module because both sides need it and they cannot share a file: the
 * bridge that uses it on the client is `"use client"` and imports Capacitor,
 * which a server route cannot pull in, and the submit route has to check the
 * same number before it agrees to let a clip stay on a phone.
 *
 * Bump this when a change makes an older build unable to render a manifest the
 * current server would issue. Do NOT bump it for a change older builds can
 * ignore — every bump makes an installed app fall back to uploading, which is
 * the cost this whole path exists to avoid.
 */
export const MANIFEST_RENDER_PLUGIN_VERSION = 5;

/** Can a build reporting this version keep moving footage on the device? */
export function canRenderManifestOnDevice(nativePluginVersion: number | null | undefined): boolean {
  return (nativePluginVersion ?? 0) >= MANIFEST_RENDER_PLUGIN_VERSION;
}
