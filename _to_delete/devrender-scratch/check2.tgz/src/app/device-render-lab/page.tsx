import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/helpers";
import { canAccessDeviceRenderLab } from "@/lib/mobile/deviceRenderLabAccess";
import MobileVideoEditor from "@/features/device-render/MobileVideoEditor";

/**
 * The phone video editor.
 *
 * THE GATE STAYS. `canAccessDeviceRenderLab` limits this to one tester account
 * in production, and it stays in front of the page for exactly as long as the
 * renderer is incomplete — the same check also guards every `/api/device-render`
 * route, so a production build exposes neither the screen nor the endpoints that
 * could take a real job off the worker queue.
 *
 * `?request=<id>` connects the editor to a real request: it can then take that
 * request's queued render step, with the server holding the lease and verifying
 * the result. Without it the editor is a draft tool and says so.
 */
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ request?: string }>;
}) {
  const user = process.env.NODE_ENV === "development" ? null : await getCurrentUser();
  if (!canAccessDeviceRenderLab(user?.email)) notFound();

  const { request } = await searchParams;
  return <MobileVideoEditor requestId={request ?? null} />;
}
