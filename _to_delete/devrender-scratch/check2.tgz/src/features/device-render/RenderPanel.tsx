"use client";

import { Capacitor } from "@capacitor/core";
import {
  explainRefusal,
  type DeviceRenderAvailability,
  type DeviceRenderProgress,
} from "@/lib/mobile/deviceRenderClient";
import type { LocalDraftResult } from "./localDraft";

/**
 * Render, watch it happen, and look at what came out.
 *
 * TWO ACTIONS, TWO MEANINGS, SAID PLAINLY. "Draft on this phone" renders and
 * stops; nothing leaves the device. "Render this request" takes the queued step,
 * uploads the result and lets the server verify and attach it. Which one was
 * pressed has to be obvious without reading the code.
 *
 * The outputs section reports what the phone actually produced — length, size,
 * whether there is sound, whether the scene joins are real dissolves — because
 * comparing against a server render is the point of this screen, and "looks
 * about right" is not a comparison.
 */
export function RenderPanel({
  problems,
  totalSeconds,
  busy,
  nativeReady,
  hasVoice,
  availability,
  progress,
  draft,
  serverOutcome,
}: {
  problems: string[];
  totalSeconds: number;
  busy: boolean;
  nativeReady: boolean;
  hasVoice: boolean;
  availability: DeviceRenderAvailability | null;
  progress: DeviceRenderProgress | null;
  draft: LocalDraftResult | null;
  serverOutcome: string | null;
}) {
  const preview = draft?.preview;
  const previewSrc = preview ? Capacitor.convertFileSrc(preview.path) : null;

  return (
    <>
      <section className="studio-panel">
        <h2 className="studio-panel-title">Ready to render</h2>
        <dl className="studio-stats">
          <div className="studio-stat">
            <dt>Picture</dt>
            <dd>{totalSeconds.toFixed(1)}s</dd>
          </div>
          <div className="studio-stat">
            <dt>Sound</dt>
            <dd>{hasVoice ? "Voice + bed" : "Silent"}</dd>
          </div>
        </dl>

        {problems.length > 0 && (
          <ul
            className="studio-note studio-note-warning"
            style={{ marginTop: 12, paddingLeft: 30, display: "grid", gap: 4 }}
          >
            {problems.map((problem) => (
              <li key={problem}>{problem}</li>
            ))}
          </ul>
        )}

        {!nativeReady && problems.length === 0 && (
          <p className="studio-note studio-note-warning" style={{ marginTop: 12 }}>
            This build cannot render on the phone. Your video will be uploaded and rendered on
            the server instead.
          </p>
        )}
      </section>

      {progress && (
        <section className="studio-panel">
          <h2 className="studio-panel-title">
            <span className="studio-eyebrow" style={{ color: "var(--s-accent)" }}>
              {busy && <span className="studio-live-dot" aria-hidden />}
              {progress.phase}
            </span>
          </h2>
          <div className="studio-progress" role="progressbar" aria-valuenow={Math.round(progress.percent)} aria-valuemin={0} aria-valuemax={100}>
            <div className="studio-progress-fill" style={{ width: `${progress.percent}%` }} />
          </div>
          <p className="studio-panel-hint" style={{ margin: "10px 0 0" }}>
            {progress.message} ({Math.round(progress.percent)}%)
          </p>
        </section>
      )}

      {serverOutcome && (
        <p className="studio-note studio-note-accent">{serverOutcome}</p>
      )}

      {availability && !availability.available && (
        <p className="studio-note">{explainRefusal(availability.reason)}</p>
      )}

      {preview && previewSrc && (
        <section className="studio-panel">
          <h2 className="studio-panel-title">What this phone produced</h2>
          <video
            key={preview.path}
            src={previewSrc}
            controls
            playsInline
            className="studio-player"
          />
          <dl className="studio-stats" style={{ marginTop: 12 }}>
            <div className="studio-stat">
              <dt>Length</dt>
              <dd>{preview.durationSeconds.toFixed(2)}s</dd>
            </div>
            <div className="studio-stat">
              <dt>Size</dt>
              <dd>{(preview.fileSizeBytes / 1e6).toFixed(1)} MB</dd>
            </div>
            <div className="studio-stat">
              <dt>Sound</dt>
              <dd style={{ color: preview.hasAudioTrack ? undefined : "var(--s-danger)" }}>
                {preview.hasAudioTrack ? "Present" : "None"}
              </dd>
            </div>
            <div className="studio-stat">
              <dt>Scene joins</dt>
              <dd>{preview.crossDissolved ? "Dissolve" : "Hard cuts"}</dd>
            </div>
          </dl>

          {!preview.crossDissolved && (
            <p className="studio-note studio-note-warning" style={{ marginTop: 12 }}>
              The dissolving composition would not export on this phone, so the scenes were
              joined with hard cuts. A server render dissolves them — worth noting when
              comparing the two.
            </p>
          )}
          {draft?.final?.coverPath && (
            <p className="studio-shot-meta" style={{ marginTop: 10 }}>
              A cover image was taken from this video&apos;s own frames.
            </p>
          )}
        </section>
      )}
    </>
  );
}
