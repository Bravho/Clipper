"use client";

import type { MontageTransition, MotionPreset } from "@/config/montage";
import { findSource, type EditorDocument, type EditorShot } from "./editorState";

const MOTION_LABELS: Record<MotionPreset, string> = {
  ken_burns_in: "Zoom in",
  ken_burns_out: "Zoom out",
  pan_left: "Pan left",
  pan_right: "Pan right",
  static: "Hold",
};

const TRANSITION_LABELS: Record<MontageTransition, string> = {
  cut: "Cut",
  fade: "Dissolve",
  slide: "Slide",
  zoom: "Zoom",
};

/** Scene colours for the proportion bar — the accent plus three neutrals. */
const SEGMENT_COLORS = [
  "var(--s-accent)",
  "#60a5fa",
  "#a78bfa",
  "#34d399",
  "#f472b6",
  "#fbbf24",
];

/**
 * The timeline: scenes, the shots inside them, and what each shot does.
 *
 * WHY TYPED SECONDS AND NOT A DRAG HANDLE. A drag-to-trim strip is nicer at a
 * desk and worse on a phone, where the thing being dragged is a few millimetres
 * wide and a slip costs a whole re-render. Typed seconds are exact, and exact is
 * what makes a trim match the approval the requester signed off on.
 *
 * WHY THE PROPORTION BAR. A column of numbers does not tell you that one photo
 * is holding the screen for a third of the video. A bar drawn to scale does, at
 * a glance — which is the one thing a list cannot do and the reason it is here.
 */
export function SceneList({
  document,
  transitions,
  motions,
  onPatchShot,
  onMoveShot,
  onRemoveShot,
  onAddScene,
  onAddShot,
  onSceneTransition,
  disabled,
}: {
  document: EditorDocument;
  transitions: MontageTransition[];
  motions: MotionPreset[];
  onPatchShot: (sceneId: string, shotId: string, change: Partial<EditorShot>) => void;
  onMoveShot: (sceneId: string, index: number, by: -1 | 1) => void;
  onRemoveShot: (sceneId: string, shotId: string) => void;
  onAddScene: () => void;
  onAddShot: (sceneId: string, sourceId: string) => void;
  onSceneTransition: (sceneId: string, transition: MontageTransition) => void;
  disabled: boolean;
}) {
  if (document.sources.length === 0) {
    return (
      <section className="studio-panel">
        <h2 className="studio-panel-title">Timeline</h2>
        <p className="studio-empty">Add photos or clips first</p>
      </section>
    );
  }

  const total = document.scenes.reduce(
    (sum, scene) => sum + scene.shots.reduce((s, shot) => s + shot.durationSeconds, 0),
    0
  );

  let segmentIndex = -1;

  return (
    <section className="studio-panel">
      <h2 className="studio-panel-title">Timeline</h2>
      <p className="studio-panel-hint">
        {total.toFixed(1)}s across {document.scenes.length} scene
        {document.scenes.length === 1 ? "" : "s"}.
      </p>

      {total > 0 && (
        <div
          className="studio-duration-bar"
          role="img"
          aria-label={`Each shot's share of the ${total.toFixed(1)} second video`}
        >
          {document.scenes.flatMap((scene) =>
            scene.shots.map((shot) => {
              segmentIndex += 1;
              return (
                <span
                  key={shot.id}
                  className="studio-duration-seg"
                  style={{
                    width: `${(shot.durationSeconds / total) * 100}%`,
                    background: SEGMENT_COLORS[segmentIndex % SEGMENT_COLORS.length],
                  }}
                />
              );
            })
          )}
        </div>
      )}

      <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
        {document.scenes.map((scene, sceneIndex) => (
          <article key={scene.id} className="studio-scene">
            <header className="studio-scene-head">
              <h3 className="studio-scene-name">Scene {sceneIndex + 1}</h3>
              {sceneIndex === 0 ? (
                <span style={{ fontSize: 12, color: "var(--s-text-faint)" }}>Opens the video</span>
              ) : (
                <label style={{ fontSize: 12, color: "var(--s-text-muted)" }}>
                  Enters with{" "}
                  <select
                    className="studio-select"
                    style={{ minHeight: 36, width: "auto", display: "inline-block", fontSize: 14 }}
                    value={scene.transitionIn}
                    disabled={disabled}
                    onChange={(event) =>
                      onSceneTransition(scene.id, event.target.value as MontageTransition)
                    }
                  >
                    {transitions.map((transition) => (
                      <option key={transition} value={transition}>
                        {TRANSITION_LABELS[transition]}
                      </option>
                    ))}
                  </select>
                </label>
              )}
            </header>

            {scene.shots.length === 0 && (
              <p className="studio-empty" style={{ margin: 14, padding: 20 }}>
                No shots in this scene yet
              </p>
            )}

            {scene.shots.map((shot, shotIndex) => {
              const source = findSource(document, shot.sourceId);
              if (!source) return null;
              const isClip = source.kind === "clip";
              const window =
                shot.trimEndSeconds != null ? shot.trimEndSeconds - shot.trimStartSeconds : null;
              const slowed = isClip && window != null && window > 0 && shot.durationSeconds > window;

              return (
                <div key={shot.id} className="studio-shot">
                  <div className="studio-shot-thumb">
                    {isClip ? (
                      <video src={source.previewUrl} muted playsInline preload="metadata" />
                    ) : (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={source.previewUrl} alt="" />
                    )}
                  </div>

                  <div className="studio-shot-main">
                    <div
                      style={{
                        display: "flex",
                        alignItems: "flex-start",
                        justifyContent: "space-between",
                        gap: 8,
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div className="studio-shot-name">
                          {shotIndex + 1}. {source.fileName}
                        </div>
                        <div className="studio-shot-meta">
                          {isClip
                            ? `Clip · ${(source.durationSeconds ?? 0).toFixed(1)}s available · no camera sound`
                            : "Photo"}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
                        <button
                          type="button"
                          className="studio-icon-button"
                          aria-label="Move earlier"
                          disabled={disabled || shotIndex === 0}
                          onClick={() => onMoveShot(scene.id, shotIndex, -1)}
                        >
                          ↑
                        </button>
                        <button
                          type="button"
                          className="studio-icon-button"
                          aria-label="Move later"
                          disabled={disabled || shotIndex === scene.shots.length - 1}
                          onClick={() => onMoveShot(scene.id, shotIndex, 1)}
                        >
                          ↓
                        </button>
                        <button
                          type="button"
                          className="studio-icon-button"
                          aria-label="Remove shot"
                          style={{ color: "var(--s-danger)" }}
                          disabled={disabled}
                          onClick={() => onRemoveShot(scene.id, shot.id)}
                        >
                          ×
                        </button>
                      </div>
                    </div>

                    <div className="studio-shot-controls">
                      <label>
                        <span className="studio-label">On screen</span>
                        <input
                          className="studio-input"
                          type="number"
                          inputMode="decimal"
                          min="0.1"
                          step="0.1"
                          value={shot.durationSeconds}
                          disabled={disabled}
                          onChange={(event) =>
                            onPatchShot(scene.id, shot.id, {
                              durationSeconds: Number(event.target.value),
                            })
                          }
                        />
                      </label>

                      {isClip ? (
                        <>
                          <label>
                            <span className="studio-label">Start at</span>
                            <input
                              className="studio-input"
                              type="number"
                              inputMode="decimal"
                              min="0"
                              step="0.1"
                              value={shot.trimStartSeconds}
                              disabled={disabled}
                              onChange={(event) =>
                                onPatchShot(scene.id, shot.id, {
                                  trimStartSeconds: Number(event.target.value),
                                })
                              }
                            />
                          </label>
                          <label style={{ gridColumn: "1 / -1" }}>
                            <span className="studio-label">End at</span>
                            <input
                              className="studio-input"
                              type="number"
                              inputMode="decimal"
                              min="0.1"
                              step="0.1"
                              value={shot.trimEndSeconds ?? ""}
                              disabled={disabled}
                              onChange={(event) =>
                                onPatchShot(scene.id, shot.id, {
                                  trimEndSeconds: event.target.value
                                    ? Number(event.target.value)
                                    : null,
                                })
                              }
                            />
                          </label>
                        </>
                      ) : (
                        <>
                          <label>
                            <span className="studio-label">Camera move</span>
                            <select
                              className="studio-select"
                              value={shot.motion}
                              disabled={disabled}
                              onChange={(event) =>
                                onPatchShot(scene.id, shot.id, {
                                  motion: event.target.value as MotionPreset,
                                })
                              }
                            >
                              {motions.map((motion) => (
                                <option key={motion} value={motion}>
                                  {MOTION_LABELS[motion]}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label style={{ gridColumn: "1 / -1" }}>
                            <span className="studio-label">
                              Keep in frame — across{" "}
                              {Math.round(shot.focusX * 100)}%, down{" "}
                              {Math.round(shot.focusY * 100)}%
                            </span>
                            <div style={{ display: "grid", gap: 10 }}>
                              <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.05"
                                aria-label="Subject position across the frame"
                                value={shot.focusX}
                                disabled={disabled}
                                onChange={(event) =>
                                  onPatchShot(scene.id, shot.id, {
                                    focusX: Number(event.target.value),
                                  })
                                }
                              />
                              <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.05"
                                aria-label="Subject position down the frame"
                                value={shot.focusY}
                                disabled={disabled}
                                onChange={(event) =>
                                  onPatchShot(scene.id, shot.id, {
                                    focusY: Number(event.target.value),
                                  })
                                }
                              />
                            </div>
                          </label>
                        </>
                      )}
                    </div>

                    {slowed && (
                      <p className="studio-shot-meta" style={{ marginTop: 8 }}>
                        On screen longer than the {window!.toFixed(1)}s selected, so it plays
                        slightly slower to fill the gap.
                      </p>
                    )}
                  </div>
                </div>
              );
            })}

            <div style={{ padding: 12 }}>
              <select
                className="studio-select"
                value=""
                disabled={disabled}
                aria-label={`Add a shot to scene ${sceneIndex + 1}`}
                onChange={(event) => {
                  if (event.target.value) onAddShot(scene.id, event.target.value);
                  event.target.value = "";
                }}
              >
                <option value="">+ Add a shot…</option>
                {document.sources.map((source) => (
                  <option key={source.id} value={source.id}>
                    {source.fileName}
                  </option>
                ))}
              </select>
            </div>
          </article>
        ))}
      </div>

      <button
        type="button"
        className="studio-button studio-button-ghost"
        style={{ marginTop: 12 }}
        disabled={disabled}
        onClick={onAddScene}
      >
        Add a scene
      </button>
    </section>
  );
}
