"use client";

import type { MusicTrack } from "@/config/backgroundMusic";
import {
  DEVICE_MUSIC_BED_VOLUME,
  DEVICE_MUSIC_LEAD_IN_SECONDS,
} from "@/lib/mobile/deviceRenderAudio";
import type { EditorDocument } from "./editorState";

/**
 * The speaking voice and the bed.
 *
 * THE ONE THING THIS SCREEN MUST GET ACROSS is where the narration comes from.
 * In a real job it is the approved ElevenLabs voice, generated and approved on
 * the server, and the phone downloads it — a locally chosen file would produce
 * a different video from the one that was approved. In a draft there is no
 * approved voice yet, so a local file stands in. Which is which is the
 * difference between a useful test and a misleading one.
 *
 * The mix numbers are shown rather than hidden because someone listening for
 * "is the bed ducking properly" needs to know what correct sounds like.
 */
export function AudioPanel({
  document,
  tracks,
  hasServerJob,
  onVoiceFile,
  onMusicFile,
  onMusicTrack,
  disabled,
}: {
  document: EditorDocument;
  tracks: MusicTrack[];
  hasServerJob: boolean;
  onVoiceFile: (file: File | null) => void;
  onMusicFile: (file: File | null) => void;
  onMusicTrack: (trackId: string | null) => void;
  disabled: boolean;
}) {
  return (
    <>
      <section className="studio-panel">
        <h2 className="studio-panel-title">Narration</h2>
        <p className="studio-panel-hint">
          {hasServerJob
            ? "A real render downloads the ElevenLabs voice you approved. The file below is only for a draft on this phone."
            : "A real job uses the approved ElevenLabs voice. Pick a stand-in here to hear how the mix sounds."}
        </p>

        <label className="studio-button studio-button-ghost">
          {document.voiceFile ? "Change the stand-in voice" : "Choose a stand-in voice"}
          <input
            type="file"
            accept="audio/mpeg,audio/mp4,audio/wav,audio/x-m4a"
            disabled={disabled}
            onChange={(event) => onVoiceFile(event.target.files?.[0] ?? null)}
            style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
          />
        </label>
        <p className="studio-shot-meta" style={{ marginTop: 8 }}>
          {document.voiceFile
            ? document.voiceFile.name
            : "Without a voice the draft stops at the silent picture."}
        </p>
      </section>

      <section className="studio-panel">
        <h2 className="studio-panel-title">Background</h2>
        <p className="studio-panel-hint">
          The track a real render will use. For a draft, choose the same file below so you can
          hear the mix.
        </p>

        <label className="studio-field">
          <span className="studio-label">Track</span>
          <select
            className="studio-select"
            value={document.musicTrackId ?? ""}
            disabled={disabled}
            onChange={(event) => onMusicTrack(event.target.value || null)}
          >
            <option value="">No background music</option>
            {tracks.map((track) => (
              <option key={track.id} value={track.id}>
                {track.label}
              </option>
            ))}
          </select>
        </label>

        <label className="studio-button studio-button-ghost">
          {document.musicFile ? "Change the draft music file" : "Choose the draft music file"}
          <input
            type="file"
            accept="audio/mpeg,audio/mp4,audio/wav,audio/x-m4a"
            disabled={disabled}
            onChange={(event) => onMusicFile(event.target.files?.[0] ?? null)}
            style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
          />
        </label>
        <p className="studio-shot-meta" style={{ marginTop: 8 }}>
          {document.musicFile ? document.musicFile.name : "Optional."}
        </p>
      </section>

      <section className="studio-panel">
        <h2 className="studio-panel-title">How the mix is built</h2>
        <ul style={{ margin: 0, paddingLeft: 18, display: "grid", gap: 6, fontSize: 13, color: "var(--s-text-muted)" }}>
          <li>Opens on {DEVICE_MUSIC_LEAD_IN_SECONDS}s of music before the narration starts.</li>
          <li>The voice is levelled to −16 LUFS with a −1.5 dBTP ceiling.</li>
          <li>
            The bed sits at {Math.round(DEVICE_MUSIC_BED_VOLUME * 100)}% and ducks under speech,
            recovering between sentences and under the ending.
          </li>
          <li>Camera sound from your clips is never used.</li>
        </ul>
      </section>
    </>
  );
}
