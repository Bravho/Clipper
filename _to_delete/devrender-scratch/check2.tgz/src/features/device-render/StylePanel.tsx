"use client";

import type { MotionTemplate } from "@/config/motionTemplates";
import type { CaptionLanguage } from "@/lib/mobile/deviceRenderCaptions";
import type { EditorDocument } from "./editorState";

const LANGUAGES: { id: CaptionLanguage; label: string; note: string }[] = [
  { id: "th", label: "ไทย", note: "White, largest" },
  { id: "en", label: "English", note: "White" },
  { id: "zh", label: "中文", note: "Yellow" },
];

/**
 * Captions and the graphic template.
 *
 * Caption language is a distribution decision rather than a preference: the
 * Travy export ships English and Chinese whatever is chosen here. That is said
 * on the screen rather than discovered later in the outputs list.
 */
export function StylePanel({
  document,
  templates,
  onLanguages,
  onTemplate,
  disabled,
}: {
  document: EditorDocument;
  templates: MotionTemplate[];
  onLanguages: (languages: CaptionLanguage[]) => void;
  onTemplate: (templateId: string) => void;
  disabled: boolean;
}) {
  const toggle = (language: CaptionLanguage) => {
    const next = document.captionLanguages.includes(language)
      ? document.captionLanguages.filter((item) => item !== language)
      : // Keep the stack in the overlay's own order (Thai, English, Chinese)
        // rather than in the order they happened to be tapped.
        (["th", "en", "zh"] as CaptionLanguage[]).filter(
          (item) => item === language || document.captionLanguages.includes(item)
        );
    onLanguages(next);
  };

  return (
    <>
      <section className="studio-panel">
        <h2 className="studio-panel-title">Captions</h2>
        <p className="studio-panel-hint">
          Burned into the video, stacked from the bottom in this order.
        </p>

        <div className="studio-chip-row" role="group" aria-label="Caption languages">
          {LANGUAGES.map((language) => (
            <button
              key={language.id}
              type="button"
              className="studio-chip"
              aria-pressed={document.captionLanguages.includes(language.id)}
              disabled={disabled}
              onClick={() => toggle(language.id)}
            >
              <strong>{language.label}</strong>
              <span style={{ color: "var(--s-text-faint)", fontWeight: 500 }}>{language.note}</span>
            </button>
          ))}
        </div>

        {document.captionLanguages.length === 0 ? (
          <p className="studio-note studio-note-warning" style={{ marginTop: 12 }}>
            With no languages chosen there is nothing to burn in, so a draft stops at the sound
            mix.
          </p>
        ) : (
          <p className="studio-shot-meta" style={{ marginTop: 12 }}>
            The Travy export always carries English and Chinese, whatever you pick here.
          </p>
        )}
      </section>

      <section className="studio-panel">
        <h2 className="studio-panel-title">Look</h2>
        <p className="studio-panel-hint">
          On this phone a template&apos;s decoration is drawn still; the server animates it. The
          frame, colours and placement match.
        </p>

        <div style={{ display: "grid", gap: 8 }}>
          {templates.map((template) => {
            const selected = document.templateId === template.id;
            return (
              <button
                key={template.id}
                type="button"
                disabled={disabled}
                onClick={() => onTemplate(template.id)}
                aria-pressed={selected}
                style={{
                  display: "block",
                  textAlign: "left",
                  padding: 14,
                  borderRadius: "var(--s-radius)",
                  border: `1px solid ${selected ? "var(--s-accent)" : "var(--s-border)"}`,
                  background: selected
                    ? "color-mix(in srgb, var(--s-accent) 14%, var(--s-surface-raised))"
                    : "var(--s-surface-raised)",
                  color: "var(--s-text)",
                }}
              >
                <span style={{ display: "block", fontWeight: 700, fontSize: 15 }}>
                  {template.name}
                </span>
                <span
                  style={{
                    display: "block",
                    marginTop: 3,
                    fontSize: 13,
                    color: "var(--s-text-muted)",
                  }}
                >
                  {template.description}
                </span>
              </button>
            );
          })}
        </div>
      </section>
    </>
  );
}
