"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import "./studio.css";

import {
  MONTAGE_TRANSITIONS,
  MOTION_PRESETS,
  type MontageTransition,
  type MotionPreset,
} from "@/config/montage";
import { MOTION_TEMPLATES } from "@/config/motionTemplates";
import { BACKGROUND_MUSIC_TRACKS } from "@/config/backgroundMusic";
import type { CaptionLanguage } from "@/lib/mobile/deviceRenderCaptions";
import { cancelDeviceRender } from "@/lib/mobile/deviceRenderBridge";
import {
  checkDeviceRenderAvailability,
  explainRefusal,
  runDeviceRender,
  type DeviceRenderAvailability,
  type DeviceRenderProgress,
} from "@/lib/mobile/deviceRenderClient";
import {
  autoArrange,
  documentDurationSeconds,
  emptyDocument,
  findSource,
  nextId,
  readDuration,
  validateDocument,
  type EditorDocument,
  type EditorRatio,
  type EditorShot,
  type EditorSource,
} from "./editorState";
import { releaseLocalDraft, renderLocalDraft, type LocalDraftResult } from "./localDraft";
import { CapabilityNotice, ServerBadge, useStudioCapability } from "./StudioChrome";
import { SourcePicker } from "./SourcePicker";
import { SceneList } from "./SceneList";
import { AudioPanel } from "./AudioPanel";
import { StylePanel } from "./StylePanel";
import { RenderPanel } from "./RenderPanel";

/**
 * The phone video editor.
 *
 * TWO MODES, NEVER CONFUSED. Without a `requestId` this is a DRAFT tool: it
 * renders on the phone and nothing it produces touches a job, a channel or a
 * credit. With one, it can also take that request's queued render step, and
 * everything then goes through the server's lease, verification and completion.
 * The distinction is stated on screen rather than left to be inferred from
 * which buttons happen to be enabled.
 *
 * WHY THE ACTION BAR IS FIXED. The primary action has to be reachable without
 * scrolling past a long timeline, and a thumb reaches the bottom of a phone far
 * more easily than the top. The bar sits above the home indicator, which is why
 * the layout carries a safe-area inset rather than a fixed padding.
 */

export interface MobileVideoEditorProps {
  /** When present, the editor can also render this request's queued step. */
  requestId?: string | null;
  /** Shown in the header so a tester knows which video they are looking at. */
  requestLabel?: string | null;
}

type Step = "source" | "scenes" | "audio" | "style" | "render";

const STEPS: { id: Step; label: string }[] = [
  { id: "source", label: "Media" },
  { id: "scenes", label: "Timeline" },
  { id: "audio", label: "Sound" },
  { id: "style", label: "Captions" },
  { id: "render", label: "Render" },
];

export default function MobileVideoEditor({ requestId, requestLabel }: MobileVideoEditorProps) {
  const [step, setStep] = useState<Step>("source");
  const [document, setDocument] = useState<EditorDocument>(emptyDocument);
  const [availability, setAvailability] = useState<DeviceRenderAvailability | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<DeviceRenderProgress | null>(null);
  const [draft, setDraft] = useState<LocalDraftResult | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [serverOutcome, setServerOutcome] = useState<string | null>(null);

  const capability = useStudioCapability();
  const nativeReady = capability?.canRender === true;

  const cancelRequested = useRef(false);
  const draftRef = useRef<LocalDraftResult | null>(null);
  draftRef.current = draft;

  // ── what the server would hand this phone ─────────────────────────────────
  useEffect(() => {
    if (!requestId) return;
    let cancelled = false;
    const poll = async () => {
      const result = await checkDeviceRenderAvailability(requestId);
      if (!cancelled) setAvailability(result);
    };
    void poll();
    // Slow on purpose: the answer changes when an approval gate clears, which is
    // a human-speed event. A tight poll would be a request a second for as long
    // as the screen is open.
    const timer = setInterval(() => void poll(), 15_000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [requestId]);

  useEffect(() => {
    return () => {
      void releaseLocalDraft(draftRef.current);
    };
  }, []);

  const problems = useMemo(() => validateDocument(document), [document]);
  const totalSeconds = useMemo(() => documentDurationSeconds(document), [document]);

  const update = useCallback((change: (current: EditorDocument) => EditorDocument) => {
    // Any edit invalidates the rendered draft: a preview that no longer matches
    // the timeline is how someone signs off on the wrong thing.
    setDraft((current) => {
      void releaseLocalDraft(current);
      return null;
    });
    setDocument(change);
  }, []);

  // ── media ─────────────────────────────────────────────────────────────────
  const addFiles = useCallback(
    async (files: FileList | null) => {
      setError(null);
      const picked = Array.from(files ?? []).slice(0, 20);
      if (picked.length === 0) return;

      try {
        const added: EditorSource[] = [];
        for (const file of picked) {
          const isClip = file.type.startsWith("video/");
          added.push({
            id: nextId("src"),
            kind: isClip ? "clip" : "image",
            file,
            previewUrl: URL.createObjectURL(file),
            durationSeconds: isClip ? await readDuration(file) : null,
            fileName: file.name,
          });
        }
        update((current) => {
          const sources = [...current.sources, ...added];
          return {
            ...current,
            sources,
            // Auto-arrange only the first time, so adding a photo later does not
            // throw away an order someone has already set.
            scenes: current.scenes.length === 0 ? autoArrange(sources) : current.scenes,
          };
        });
        setMessage(`${added.length} item(s) added. Originals stay on this phone.`);
      } catch (failure) {
        setError(failure instanceof Error ? failure.message : String(failure));
      }
    },
    [update]
  );

  const removeSource = useCallback(
    (sourceId: string) => {
      update((current) => {
        const source = findSource(current, sourceId);
        if (source) URL.revokeObjectURL(source.previewUrl);
        return {
          ...current,
          sources: current.sources.filter((item) => item.id !== sourceId),
          scenes: current.scenes.map((scene) => ({
            ...scene,
            shots: scene.shots.filter((shot) => shot.sourceId !== sourceId),
          })),
        };
      });
    },
    [update]
  );

  // ── timeline ──────────────────────────────────────────────────────────────
  const patchShot = useCallback(
    (sceneId: string, shotId: string, change: Partial<EditorShot>) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) =>
          scene.id !== sceneId
            ? scene
            : {
                ...scene,
                shots: scene.shots.map((shot) =>
                  shot.id === shotId ? { ...shot, ...change } : shot
                ),
              }
        ),
      }));
    },
    [update]
  );

  const moveShot = useCallback(
    (sceneId: string, index: number, by: -1 | 1) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) => {
          if (scene.id !== sceneId) return scene;
          const target = index + by;
          if (target < 0 || target >= scene.shots.length) return scene;
          const shots = [...scene.shots];
          [shots[index], shots[target]] = [shots[target], shots[index]];
          return { ...scene, shots };
        }),
      }));
    },
    [update]
  );

  const removeShot = useCallback(
    (sceneId: string, shotId: string) => {
      update((current) => ({
        ...current,
        scenes: current.scenes
          .map((scene) =>
            scene.id !== sceneId
              ? scene
              : { ...scene, shots: scene.shots.filter((shot) => shot.id !== shotId) }
          )
          // A scene with nothing in it renders nothing, so it is dropped rather
          // than left as an empty row someone has to tidy up.
          .filter((scene) => scene.shots.length > 0),
      }));
    },
    [update]
  );

  const addScene = useCallback(() => {
    update((current) => ({
      ...current,
      scenes: [...current.scenes, { id: nextId("scene"), transitionIn: "fade", shots: [] }],
    }));
  }, [update]);

  const addShotToScene = useCallback(
    (sceneId: string, sourceId: string) => {
      update((current) => {
        const source = findSource(current, sourceId);
        if (!source) return current;
        const clipLength = source.durationSeconds ?? 0;
        const duration =
          source.kind === "clip" && clipLength > 0 ? Math.min(3, Math.max(0.5, clipLength)) : 3;
        return {
          ...current,
          scenes: current.scenes.map((scene) =>
            scene.id !== sceneId
              ? scene
              : {
                  ...scene,
                  shots: [
                    ...scene.shots,
                    {
                      id: nextId("shot"),
                      sourceId,
                      durationSeconds: Math.round(duration * 10) / 10,
                      motion: source.kind === "clip" ? "static" : "ken_burns_in",
                      trimStartSeconds: 0,
                      trimEndSeconds:
                        source.kind === "clip" && clipLength > 0
                          ? Math.round(Math.min(clipLength, duration) * 10) / 10
                          : null,
                      focusX: 0.5,
                      focusY: 0.5,
                    } satisfies EditorShot,
                  ],
                }
          ),
        };
      });
    },
    [update]
  );

  const setSceneTransition = useCallback(
    (sceneId: string, transition: MontageTransition) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) =>
          scene.id === sceneId ? { ...scene, transitionIn: transition } : scene
        ),
      }));
    },
    [update]
  );

  // ── rendering ─────────────────────────────────────────────────────────────
  const renderDraft = useCallback(async () => {
    setBusy(true);
    setError(null);
    setServerOutcome(null);
    cancelRequested.current = false;
    setStep("render");
    setProgress({ phase: "rendering", percent: 0, message: "Starting the draft render…" });

    try {
      const result = await renderLocalDraft(document, {
        onProgress: (stage, percent) =>
          setProgress({
            phase: "rendering",
            percent,
            message:
              stage === "montage"
                ? "Building the picture from your photos and clips…"
                : stage === "master"
                  ? "Mixing the voice and the bed…"
                  : "Burning in the captions and template…",
          }),
        shouldCancel: () => cancelRequested.current,
      });
      void releaseLocalDraft(draftRef.current);
      setDraft(result);
      setMessage(
        result.final
          ? "Draft finished with captions and sound."
          : result.master
            ? "Draft finished with sound. Add captions to see the finished look."
            : "Silent draft finished. Add a speaking voice to hear it."
      );
      setProgress({ phase: "done", percent: 100, message: "Draft ready." });
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
      setProgress(null);
    } finally {
      setBusy(false);
    }
  }, [document]);

  const renderForServer = useCallback(async () => {
    if (!requestId) return;
    setBusy(true);
    setError(null);
    setServerOutcome(null);
    cancelRequested.current = false;
    setStep("render");

    try {
      const outcome = await runDeviceRender({
        requestId,
        onProgress: setProgress,
        shouldCancel: () => cancelRequested.current,
      });

      if (outcome.status === "completed") {
        setServerOutcome("Done. The server checked the video and attached it to your request.");
      } else if (outcome.status === "refused") {
        setServerOutcome(explainRefusal(outcome.reason));
      } else if (outcome.status === "released") {
        setServerOutcome("Stopped. The server will render this one instead.");
      } else {
        setServerOutcome(
          `This phone could not finish it, so the server will: ${outcome.reason ?? "unknown"}`
        );
      }
      setAvailability(await checkDeviceRenderAvailability(requestId));
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    } finally {
      setBusy(false);
    }
  }, [requestId]);

  const cancel = useCallback(async () => {
    cancelRequested.current = true;
    await cancelDeviceRender();
    setMessage("Stopping…");
  }, []);

  // ── step completion, for the rail's ticks ─────────────────────────────────
  const stepDone: Record<Step, boolean> = {
    source: document.sources.length > 0,
    scenes: document.scenes.some((scene) => scene.shots.length > 0) && problems.length === 0,
    audio: Boolean(document.voiceFile || document.musicTrackId),
    style: document.captionLanguages.length > 0,
    render: Boolean(draft),
  };

  const blocked = problems.length > 0 || !nativeReady;

  return (
    <main className="studio">
      <header className="studio-header">
        <ServerBadge />
        <h1 className="studio-title">{requestLabel ?? "Video studio"}</h1>
        <p className="studio-subtitle">
          {requestId
            ? "Edit and render this request on your phone. Approvals, credits and publishing stay on the server."
            : "A draft tool. Nothing here submits a request, spends credits or publishes anything."}
        </p>
      </header>

      <nav className="studio-steps" aria-label="Editing steps">
        {STEPS.map((entry, index) => (
          <button
            key={entry.id}
            type="button"
            className={`studio-step${stepDone[entry.id] ? " studio-step-done" : ""}`}
            aria-current={step === entry.id ? "step" : undefined}
            onClick={() => setStep(entry.id)}
          >
            <span className="studio-step-index" aria-hidden>
              {stepDone[entry.id] ? "✓" : index + 1}
            </span>
            {entry.label}
          </button>
        ))}
      </nav>

      <div className="studio-body">
        <CapabilityNotice capability={capability} />

        {step === "source" && (
          <SourcePicker
            sources={document.sources}
            ratio={document.ratio}
            onAdd={addFiles}
            onRemove={removeSource}
            onRatioChange={(ratio: EditorRatio) => update((current) => ({ ...current, ratio }))}
            disabled={busy}
          />
        )}

        {step === "scenes" && (
          <SceneList
            document={document}
            transitions={MONTAGE_TRANSITIONS}
            motions={MOTION_PRESETS as MotionPreset[]}
            onPatchShot={patchShot}
            onMoveShot={moveShot}
            onRemoveShot={removeShot}
            onAddScene={addScene}
            onAddShot={addShotToScene}
            onSceneTransition={setSceneTransition}
            disabled={busy}
          />
        )}

        {step === "audio" && (
          <AudioPanel
            document={document}
            tracks={BACKGROUND_MUSIC_TRACKS}
            hasServerJob={Boolean(requestId)}
            onVoiceFile={(file) => update((current) => ({ ...current, voiceFile: file }))}
            onMusicFile={(file) => update((current) => ({ ...current, musicFile: file }))}
            onMusicTrack={(trackId) => update((current) => ({ ...current, musicTrackId: trackId }))}
            disabled={busy}
          />
        )}

        {step === "style" && (
          <StylePanel
            document={document}
            templates={MOTION_TEMPLATES}
            onLanguages={(languages: CaptionLanguage[]) =>
              update((current) => ({ ...current, captionLanguages: languages }))
            }
            onTemplate={(templateId) => update((current) => ({ ...current, templateId }))}
            disabled={busy}
          />
        )}

        {step === "render" && (
          <RenderPanel
            problems={problems}
            totalSeconds={totalSeconds}
            busy={busy}
            nativeReady={nativeReady}
            hasVoice={Boolean(document.voiceFile)}
            availability={availability}
            progress={progress}
            draft={draft}
            serverOutcome={serverOutcome}
          />
        )}

        <div role="status" aria-live="polite" style={{ display: "grid", gap: 8 }}>
          {message && <p className="studio-note">{message}</p>}
          {error && <p className="studio-note studio-note-danger">{error}</p>}
        </div>
      </div>

      <div className="studio-actions">
        {busy ? (
          <button type="button" className="studio-button studio-button-ghost" onClick={() => void cancel()}>
            Stop
          </button>
        ) : (
          <>
            {requestId && availability?.available && (
              <button
                type="button"
                className="studio-button studio-button-primary"
                disabled={!nativeReady}
                onClick={() => void renderForServer()}
              >
                Render this request
                {availability.ratio ? ` · ${availability.ratio}` : ""}
              </button>
            )}
            <div className="studio-actions-row">
              <button
                type="button"
                className={`studio-button ${
                  requestId && availability?.available
                    ? "studio-button-ghost"
                    : "studio-button-primary"
                }`}
                disabled={blocked}
                onClick={() => void renderDraft()}
              >
                Draft on this phone
              </button>
            </div>
          </>
        )}
      </div>
    </main>
  );
}
