"use client";

import type { MontageTransition, MotionPreset } from "@/config/montage";
import type { CaptionLanguage } from "@/lib/mobile/deviceRenderCaptions";

/**
 * The editor's working document.
 *
 * A deliberately small, serialisable shape. It is NOT the job — the job lives on
 * the server and is the only thing that can approve, charge or publish anything.
 * This is what the person is arranging on the phone before any of that happens,
 * and what a local draft render is built from.
 */

export type EditorRatio = "9:16" | "16:9" | "1:1" | "4:5";

export interface EditorSource {
  /** Stable within this editing session. */
  id: string;
  kind: "image" | "clip";
  /** The picked file, held in memory for the session. */
  file: File;
  /** Object URL for the preview thumbnail. Revoked on removal. */
  previewUrl: string;
  /** Real length for a clip; null for a still. */
  durationSeconds: number | null;
  fileName: string;
}

export interface EditorShot {
  id: string;
  sourceId: string;
  /** How long this shot is on screen. */
  durationSeconds: number;
  motion: MotionPreset;
  /** Clips only. */
  trimStartSeconds: number;
  trimEndSeconds: number | null;
  focusX: number;
  focusY: number;
}

export interface EditorScene {
  id: string;
  transitionIn: MontageTransition;
  shots: EditorShot[];
}

export interface EditorDocument {
  ratio: EditorRatio;
  sources: EditorSource[];
  scenes: EditorScene[];
  captionLanguages: CaptionLanguage[];
  templateId: string;
  /** Id of a track in `public/music`, or null for no bed. */
  musicTrackId: string | null;
  /** A locally chosen voice file, for a draft before the approved voice exists. */
  voiceFile: File | null;
  musicFile: File | null;
}

export const DEFAULT_SHOT_SECONDS = 3;

export function emptyDocument(): EditorDocument {
  return {
    ratio: "9:16",
    sources: [],
    scenes: [],
    captionLanguages: ["en", "zh"],
    templateId: "none",
    musicTrackId: null,
    voiceFile: null,
    musicFile: null,
  };
}

let counter = 0;
export function nextId(prefix: string): string {
  counter += 1;
  return `${prefix}_${Date.now().toString(36)}_${counter}`;
}

/**
 * Read a picked file's real duration.
 *
 * The trim UI is only honest if it knows the true length: a slot longer than
 * the footage is what the renderer fills by slowing the clip down, and a trim
 * past the end is what the server rejects. Getting this from the browser
 * up front is cheaper than discovering it during a render.
 */
export function readDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const element = document.createElement("video");
    element.preload = "metadata";
    const finish = (run: () => void) => {
      element.removeAttribute("src");
      element.load();
      URL.revokeObjectURL(url);
      run();
    };
    const timeout = window.setTimeout(
      () => finish(() => reject(new Error(`Could not read ${file.name}`))),
      15_000
    );
    element.onloadedmetadata = () => {
      window.clearTimeout(timeout);
      const duration = element.duration;
      finish(() =>
        Number.isFinite(duration) && duration > 0
          ? resolve(duration)
          : reject(new Error(`Invalid duration: ${file.name}`))
      );
    };
    element.onerror = () => {
      window.clearTimeout(timeout);
      finish(() => reject(new Error(`Cannot decode ${file.name}`)));
    };
    element.src = url;
  });
}

/** Total on-screen length: shots are contiguous, so a dissolve adds nothing. */
export function documentDurationSeconds(document: EditorDocument): number {
  return document.scenes.reduce(
    (total, scene) => total + scene.shots.reduce((sum, shot) => sum + shot.durationSeconds, 0),
    0
  );
}

export function findSource(document: EditorDocument, sourceId: string): EditorSource | undefined {
  return document.sources.find((source) => source.id === sourceId);
}

/**
 * Everything wrong with the document, as sentences.
 *
 * Returned rather than thrown so the editor can disable the render button AND
 * say why — "Render" greyed out with no explanation is the thing people file
 * bugs about.
 */
export function validateDocument(document: EditorDocument): string[] {
  const problems: string[] = [];

  if (document.sources.length === 0) {
    problems.push("Add at least one photo or clip.");
  }
  if (document.scenes.length === 0 || document.scenes.every((s) => s.shots.length === 0)) {
    problems.push("Add at least one shot to a scene.");
  }

  for (const [sceneIndex, scene] of document.scenes.entries()) {
    for (const [shotIndex, shot] of scene.shots.entries()) {
      const label = `Scene ${sceneIndex + 1}, shot ${shotIndex + 1}`;
      const source = findSource(document, shot.sourceId);
      if (!source) {
        problems.push(`${label} refers to media that is no longer here.`);
        continue;
      }
      if (!(shot.durationSeconds > 0)) {
        problems.push(`${label} needs a length greater than zero.`);
      }
      if (source.kind === "clip") {
        const available = source.durationSeconds ?? 0;
        if (shot.trimStartSeconds < 0) {
          problems.push(`${label} starts before the beginning of its clip.`);
        }
        if (shot.trimEndSeconds != null && shot.trimEndSeconds <= shot.trimStartSeconds) {
          problems.push(`${label} ends before it starts.`);
        }
        if (
          shot.trimEndSeconds != null &&
          available > 0 &&
          shot.trimEndSeconds > available + 0.05
        ) {
          problems.push(
            `${label} plays past the end of its clip (${available.toFixed(1)}s available).`
          );
        }
      }
    }
  }

  return problems;
}

/**
 * Put every source into one scene, one shot each, with sensible defaults.
 *
 * Stills alternate zoom in and out, which is what the scene designer does when
 * it has no reason to prefer one; clips play their first few seconds. It is a
 * starting point to edit, not a decision.
 */
export function autoArrange(sources: EditorSource[]): EditorScene[] {
  if (sources.length === 0) return [];
  return [
    {
      id: nextId("scene"),
      transitionIn: "fade",
      shots: sources.map((source, index) => {
        const clipLength = source.durationSeconds ?? 0;
        const duration =
          source.kind === "clip" && clipLength > 0
            ? Math.min(DEFAULT_SHOT_SECONDS, Math.max(0.5, clipLength))
            : DEFAULT_SHOT_SECONDS;
        return {
          id: nextId("shot"),
          sourceId: source.id,
          durationSeconds: Math.round(duration * 10) / 10,
          motion:
            source.kind === "clip"
              ? "static"
              : index % 2 === 0
                ? "ken_burns_in"
                : "ken_burns_out",
          trimStartSeconds: 0,
          trimEndSeconds: source.kind === "clip" && clipLength > 0
            ? Math.round(Math.min(clipLength, duration) * 10) / 10
            : null,
          focusX: 0.5,
          focusY: 0.5,
        };
      }),
    },
  ];
}
