"use client";

import type { EditorRatio, EditorSource } from "./editorState";

const RATIOS: { id: EditorRatio; label: string }[] = [
  { id: "9:16", label: "9:16 · Reels, Shorts, TikTok" },
  { id: "16:9", label: "16:9 · YouTube, Facebook" },
  { id: "1:1", label: "1:1 · Square" },
  { id: "4:5", label: "4:5 · Instagram feed" },
];

/**
 * Choosing the material and the canvas.
 *
 * The ratio lives here rather than in the render step because it changes what
 * every later decision looks like — a Ken Burns pan reads differently on a
 * square canvas than on a portrait one, and picking it last means re-reviewing
 * the whole timeline.
 */
export function SourcePicker({
  sources,
  ratio,
  onAdd,
  onRemove,
  onRatioChange,
  disabled,
}: {
  sources: EditorSource[];
  ratio: EditorRatio;
  onAdd: (files: FileList | null) => void | Promise<void>;
  onRemove: (sourceId: string) => void;
  onRatioChange: (ratio: EditorRatio) => void;
  disabled: boolean;
}) {
  return (
    <div className="mt-3 space-y-4">
      <label className="block text-sm">
        <span className="font-medium">Output shape</span>
        <select
          value={ratio}
          disabled={disabled}
          onChange={(event) => onRatioChange(event.target.value as EditorRatio)}
          className="mt-1 block w-full rounded-lg border border-slate-300 p-2"
        >
          {RATIOS.map((entry) => (
            <option key={entry.id} value={entry.id}>
              {entry.label}
            </option>
          ))}
        </select>
      </label>

      <label className="block text-sm">
        <span className="font-medium">Add photos and clips</span>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime"
          multiple
          disabled={disabled}
          onChange={(event) => void onAdd(event.target.files)}
          className="mt-1 block w-full text-sm"
        />
        <span className="mt-1 block text-xs text-slate-500">
          Originals stay on this phone. Camera sound in a clip is removed — the narration is
          the approved speaking voice.
        </span>
      </label>

      {sources.length === 0 ? (
        <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
          Nothing added yet.
        </p>
      ) : (
        <ul className="grid grid-cols-3 gap-2">
          {sources.map((source) => (
            <li key={source.id} className="relative overflow-hidden rounded-xl border bg-slate-100">
              {source.kind === "clip" ? (
                <video
                  src={source.previewUrl}
                  muted
                  playsInline
                  preload="metadata"
                  className="aspect-square w-full object-cover"
                />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={source.previewUrl}
                  alt={source.fileName}
                  className="aspect-square w-full object-cover"
                />
              )}
              <span className="absolute left-1 top-1 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-white">
                {source.kind === "clip"
                  ? `${(source.durationSeconds ?? 0).toFixed(1)}s`
                  : "photo"}
              </span>
              <button
                type="button"
                disabled={disabled}
                onClick={() => onRemove(source.id)}
                aria-label={`Remove ${source.fileName}`}
                className="absolute right-1 top-1 rounded-full bg-black/70 px-2 text-sm font-bold text-white disabled:opacity-40"
              >
                ×
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
