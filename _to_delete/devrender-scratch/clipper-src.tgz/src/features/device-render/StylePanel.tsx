"use client";

import type { MotionTemplate } from "@/config/motionTemplates";
import type { CaptionLanguage } from "@/lib/mobile/deviceRenderCaptions";
import type { EditorDocument } from "./editorState";

const LANGUAGES: { id: CaptionLanguage; label: string; note: string }[] = [
  { id: "th", label: "ไทย · Thai", note: "White, largest" },
  { id: "en", label: "English", note: "White" },
  { id: "zh", label: "中文 · Chinese", note: "Yellow" },
];

/**
 * Captions and the graphic template.
 *
 * Caption language is a real distribution decision, not a preference: the Travy
 * export ships English and Chinese whatever is chosen here, and that is stated
 * rather than left as a surprise in the outputs list.
 *
 * The templates are listed with their Thai names, which is what the picker in
 * the main app shows, so a tester comparing a phone render to a server render is
 * choosing from the same list.
 */
export function StylePanel({
  document,
  templates,
  onLanguages,
  onTemplate,
  disabled,
}: {
  document: EditorDocument;
  templates: MotionTemplate[];
  onLanguages: (languages: CaptionLanguage[]) => void;
  onTemplate: (templateId: string) => void;
  disabled: boolean;
}) {
  const toggle = (language: CaptionLanguage) => {
    const next = document.captionLanguages.includes(language)
      ? document.captionLanguages.filter((item) => item !== language)
      : // Keep the stack in the overlay's own order (Thai, English, Chinese)
        // rather than in the order they were clicked.
        (["th", "en", "zh"] as CaptionLanguage[]).filter(
          (item) => item === language || document.captionLanguages.includes(item)
        );
    onLanguages(next);
  };

  return (
    <div className="mt-3 space-y-5">
      <fieldset>
        <legend className="text-sm font-medium">Burned-in caption languages</legend>
        <div className="mt-2 space-y-2">
          {LANGUAGES.map((language) => (
            <label
              key={language.id}
              className="flex items-center gap-3 rounded-lg border border-slate-200 p-3"
            >
              <input
                type="checkbox"
                checked={document.captionLanguages.includes(language.id)}
                disabled={disabled}
                onChange={() => toggle(language.id)}
                className="h-5 w-5"
              />
              <span className="text-sm">
                <span className="font-semibold">{language.label}</span>
                <span className="ml-2 text-xs text-slate-500">{language.note}</span>
              </span>
            </label>
          ))}
        </div>
        <p className="mt-2 text-xs text-slate-500">
          Captions are stacked from the bottom in this order. The Travy export always carries
          English and Chinese, whatever you pick here.
        </p>
        {document.captionLanguages.length === 0 && (
          <p className="mt-2 text-xs text-amber-800">
            With no languages selected, the draft stops at the sound mix — there is nothing to
            burn in.
          </p>
        )}
      </fieldset>

      <fieldset>
        <legend className="text-sm font-medium">Graphic template</legend>
        <div className="mt-2 space-y-2">
          {templates.map((template) => (
            <label
              key={template.id}
              className={`flex items-start gap-3 rounded-lg border p-3 ${
                document.templateId === template.id
                  ? "border-blue-500 bg-blue-50"
                  : "border-slate-200"
              }`}
            >
              <input
                type="radio"
                name="template"
                value={template.id}
                checked={document.templateId === template.id}
                disabled={disabled}
                onChange={() => onTemplate(template.id)}
                className="mt-1 h-4 w-4"
              />
              <span className="text-sm">
                <span className="block font-semibold">{template.name}</span>
                <span className="block text-xs text-slate-600">{template.description}</span>
              </span>
            </label>
          ))}
        </div>
        <p className="mt-2 text-xs text-slate-500">
          On this phone a template&apos;s decoration is drawn in its settled state; the server
          animates it. The frame, colours and placement match.
        </p>
      </fieldset>
    </div>
  );
}
