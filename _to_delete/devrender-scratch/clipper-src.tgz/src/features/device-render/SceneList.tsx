"use client";

import type { MontageTransition, MotionPreset } from "@/config/montage";
import { findSource, type EditorDocument, type EditorShot } from "./editorState";

const MOTION_LABELS: Record<MotionPreset, string> = {
  ken_burns_in: "Zoom in",
  ken_burns_out: "Zoom out",
  pan_left: "Pan left",
  pan_right: "Pan right",
  static: "Hold still",
};

const TRANSITION_LABELS: Record<MontageTransition, string> = {
  cut: "Hard cut",
  fade: "Dissolve",
  slide: "Slide in",
  zoom: "Zoom in",
};

/**
 * The timeline: scenes, the shots inside them, and what each shot does.
 *
 * WHY EVERY CONTROL IS A NUMBER OR A SELECT. A drag-to-trim strip is nicer on a
 * desktop and worse on a phone, where the thing being dragged is a few
 * millimetres wide and the consequence of a slip is a render nobody wants.
 * Typed seconds are exact, and exactness is what makes a trim match the approval
 * the requester signed off on.
 *
 * Clips show what the renderer will do when a slot outruns the footage — slow
 * the clip down rather than freeze it — because that is a real visual change
 * someone should be able to see coming.
 */
export function SceneList({
  document,
  transitions,
  motions,
  onPatchShot,
  onMoveShot,
  onRemoveShot,
  onAddScene,
  onAddShot,
  onSceneTransition,
  disabled,
}: {
  document: EditorDocument;
  transitions: MontageTransition[];
  motions: MotionPreset[];
  onPatchShot: (sceneId: string, shotId: string, change: Partial<EditorShot>) => void;
  onMoveShot: (sceneId: string, index: number, by: -1 | 1) => void;
  onRemoveShot: (sceneId: string, shotId: string) => void;
  onAddScene: () => void;
  onAddShot: (sceneId: string, sourceId: string) => void;
  onSceneTransition: (sceneId: string, transition: MontageTransition) => void;
  disabled: boolean;
}) {
  if (document.sources.length === 0) {
    return (
      <p className="mt-3 rounded-xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
        Add photos or clips first.
      </p>
    );
  }

  return (
    <div className="mt-3 space-y-4">
      {document.scenes.map((scene, sceneIndex) => (
        <article key={scene.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-bold">Scene {sceneIndex + 1}</h3>
            <label className="text-xs">
              <span className="mr-1 text-slate-600">Enters with</span>
              <select
                value={scene.transitionIn}
                disabled={disabled || sceneIndex === 0}
                onChange={(event) =>
                  onSceneTransition(scene.id, event.target.value as MontageTransition)
                }
                className="rounded border border-slate-300 p-1"
              >
                {transitions.map((transition) => (
                  <option key={transition} value={transition}>
                    {TRANSITION_LABELS[transition]}
                  </option>
                ))}
              </select>
            </label>
          </div>
          {sceneIndex === 0 && (
            <p className="mt-1 text-xs text-slate-500">
              The first scene has nothing to dissolve from.
            </p>
          )}

          <ol className="mt-3 space-y-3">
            {scene.shots.map((shot, shotIndex) => {
              const source = findSource(document, shot.sourceId);
              if (!source) return null;
              const isClip = source.kind === "clip";
              const window =
                shot.trimEndSeconds != null
                  ? shot.trimEndSeconds - shot.trimStartSeconds
                  : null;
              const slowed =
                isClip && window != null && window > 0 && shot.durationSeconds > window;

              return (
                <li key={shot.id} className="rounded-lg border border-slate-200 bg-white p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex min-w-0 items-center gap-2">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      {isClip ? (
                        <video
                          src={source.previewUrl}
                          muted
                          playsInline
                          preload="metadata"
                          className="h-12 w-12 shrink-0 rounded object-cover"
                        />
                      ) : (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={source.previewUrl}
                          alt=""
                          className="h-12 w-12 shrink-0 rounded object-cover"
                        />
                      )}
                      <span className="min-w-0 truncate text-sm font-semibold">
                        {shotIndex + 1}. {source.fileName}
                      </span>
                    </div>
                    <span className="flex shrink-0 gap-1">
                      <button
                        type="button"
                        aria-label="Move earlier"
                        disabled={disabled || shotIndex === 0}
                        onClick={() => onMoveShot(scene.id, shotIndex, -1)}
                        className="rounded border px-2 py-1 disabled:opacity-30"
                      >
                        ↑
                      </button>
                      <button
                        type="button"
                        aria-label="Move later"
                        disabled={disabled || shotIndex === scene.shots.length - 1}
                        onClick={() => onMoveShot(scene.id, shotIndex, 1)}
                        className="rounded border px-2 py-1 disabled:opacity-30"
                      >
                        ↓
                      </button>
                      <button
                        type="button"
                        aria-label="Remove shot"
                        disabled={disabled}
                        onClick={() => onRemoveShot(scene.id, shot.id)}
                        className="rounded border px-2 py-1 text-red-700 disabled:opacity-30"
                      >
                        ×
                      </button>
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                    <label>
                      <span className="text-xs text-slate-600">On screen (s)</span>
                      <input
                        type="number"
                        min="0.1"
                        step="0.1"
                        value={shot.durationSeconds}
                        disabled={disabled}
                        onChange={(event) =>
                          onPatchShot(scene.id, shot.id, {
                            durationSeconds: Number(event.target.value),
                          })
                        }
                        className="mt-1 w-full rounded-lg border border-slate-300 p-2"
                      />
                    </label>

                    {isClip ? (
                      <>
                        <label>
                          <span className="text-xs text-slate-600">Start at (s)</span>
                          <input
                            type="number"
                            min="0"
                            step="0.1"
                            value={shot.trimStartSeconds}
                            disabled={disabled}
                            onChange={(event) =>
                              onPatchShot(scene.id, shot.id, {
                                trimStartSeconds: Number(event.target.value),
                              })
                            }
                            className="mt-1 w-full rounded-lg border border-slate-300 p-2"
                          />
                        </label>
                        <label>
                          <span className="text-xs text-slate-600">
                            End at (s) · clip is {(source.durationSeconds ?? 0).toFixed(1)}s
                          </span>
                          <input
                            type="number"
                            min="0.1"
                            step="0.1"
                            value={shot.trimEndSeconds ?? ""}
                            disabled={disabled}
                            onChange={(event) =>
                              onPatchShot(scene.id, shot.id, {
                                trimEndSeconds: event.target.value
                                  ? Number(event.target.value)
                                  : null,
                              })
                            }
                            className="mt-1 w-full rounded-lg border border-slate-300 p-2"
                          />
                        </label>
                      </>
                    ) : (
                      <>
                        <label>
                          <span className="text-xs text-slate-600">Camera move</span>
                          <select
                            value={shot.motion}
                            disabled={disabled}
                            onChange={(event) =>
                              onPatchShot(scene.id, shot.id, {
                                motion: event.target.value as MotionPreset,
                              })
                            }
                            className="mt-1 w-full rounded-lg border border-slate-300 p-2"
                          >
                            {motions.map((motion) => (
                              <option key={motion} value={motion}>
                                {MOTION_LABELS[motion]}
                              </option>
                            ))}
                          </select>
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <label>
                            <span className="text-xs text-slate-600">Focus ←→</span>
                            <input
                              type="range"
                              min="0"
                              max="1"
                              step="0.05"
                              value={shot.focusX}
                              disabled={disabled}
                              onChange={(event) =>
                                onPatchShot(scene.id, shot.id, {
                                  focusX: Number(event.target.value),
                                })
                              }
                              className="mt-2 w-full"
                            />
                          </label>
                          <label>
                            <span className="text-xs text-slate-600">Focus ↑↓</span>
                            <input
                              type="range"
                              min="0"
                              max="1"
                              step="0.05"
                              value={shot.focusY}
                              disabled={disabled}
                              onChange={(event) =>
                                onPatchShot(scene.id, shot.id, {
                                  focusY: Number(event.target.value),
                                })
                              }
                              className="mt-2 w-full"
                            />
                          </label>
                        </div>
                      </>
                    )}
                  </div>

                  {isClip && (
                    <p className="mt-2 text-xs text-slate-500">
                      Camera sound removed.
                      {slowed
                        ? ` This shot is on screen longer than the ${window!.toFixed(1)}s you selected, so it plays slightly slower to fill the gap.`
                        : ""}
                    </p>
                  )}
                  {!isClip && (
                    <p className="mt-2 text-xs text-slate-500">
                      The move is anchored on the focus point, so the zoom keeps your subject in
                      frame.
                    </p>
                  )}
                </li>
              );
            })}
          </ol>

          <label className="mt-3 block text-sm">
            <span className="text-xs text-slate-600">Add a shot to this scene</span>
            <select
              value=""
              disabled={disabled}
              onChange={(event) => {
                if (event.target.value) onAddShot(scene.id, event.target.value);
                event.target.value = "";
              }}
              className="mt-1 w-full rounded-lg border border-slate-300 p-2"
            >
              <option value="">Choose media…</option>
              {document.sources.map((source) => (
                <option key={source.id} value={source.id}>
                  {source.fileName}
                </option>
              ))}
            </select>
          </label>
        </article>
      ))}

      <button
        type="button"
        disabled={disabled}
        onClick={onAddScene}
        className="w-full rounded-xl border border-dashed border-slate-400 py-3 text-sm font-semibold text-slate-700 disabled:opacity-40"
      >
        Add a scene
      </button>
    </div>
  );
}
