"use client";

import { Capacitor } from "@capacitor/core";
import { explainRefusal, type DeviceRenderAvailability, type DeviceRenderProgress } from "@/lib/mobile/deviceRenderClient";
import type { LocalDraftResult } from "./localDraft";

/**
 * Render, watch it happen, and look at what came out.
 *
 * TWO BUTTONS, TWO MEANINGS, SAID PLAINLY. "Draft on this phone" renders and
 * stops; nothing leaves the device. "Render this request" takes the queued step,
 * uploads the result and lets the server verify and attach it. A tester needs to
 * know which one they just pressed without reading the code.
 *
 * The outputs section reports what the phone actually produced — length, size,
 * whether there is sound, whether the scene joins are real dissolves — because
 * the comparison against a Mac export is the whole point of this screen, and
 * "looks about right" is not a comparison.
 */
export function RenderPanel({
  problems,
  totalSeconds,
  busy,
  nativeReady,
  hasVoice,
  availability,
  progress,
  draft,
  serverOutcome,
  onRenderDraft,
  onRenderForServer,
  onCancel,
}: {
  problems: string[];
  totalSeconds: number;
  busy: boolean;
  nativeReady: boolean;
  hasVoice: boolean;
  availability: DeviceRenderAvailability | null;
  progress: DeviceRenderProgress | null;
  draft: LocalDraftResult | null;
  serverOutcome: string | null;
  onRenderDraft: () => void;
  onRenderForServer?: () => void;
  onCancel: () => void;
}) {
  const blocked = problems.length > 0 || !nativeReady;
  const primary =
    "w-full rounded-xl px-5 py-3 text-base font-semibold text-white disabled:opacity-40";

  const preview = draft?.preview;
  const previewSrc = preview ? Capacitor.convertFileSrc(preview.path) : null;

  return (
    <div className="mt-3 space-y-5">
      <dl className="grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-lg border border-slate-200 p-3">
          <dt className="text-xs text-slate-600">Picture length</dt>
          <dd className="text-lg font-bold">{totalSeconds.toFixed(1)}s</dd>
        </div>
        <div className="rounded-lg border border-slate-200 p-3">
          <dt className="text-xs text-slate-600">Sound</dt>
          <dd className="text-lg font-bold">{hasVoice ? "Voice + bed" : "Silent"}</dd>
        </div>
      </dl>

      {problems.length > 0 && (
        <ul className="space-y-1 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          {problems.map((problem) => (
            <li key={problem}>· {problem}</li>
          ))}
        </ul>
      )}

      <div className="space-y-3">
        <button
          type="button"
          disabled={busy || blocked}
          onClick={onRenderDraft}
          className={`${primary} bg-slate-800`}
        >
          Draft on this phone
        </button>
        <p className="text-xs text-slate-500">
          Renders here and stops. Nothing is uploaded, submitted or published.
        </p>

        {onRenderForServer && (
          <>
            <button
              type="button"
              disabled={busy || !nativeReady || !availability?.available}
              onClick={onRenderForServer}
              className={`${primary} bg-blue-700`}
            >
              {availability?.available
                ? `Render this request (${availability.ratio ?? ""} ${availability.stage ?? ""})`.trim()
                : "Render this request"}
            </button>
            <p className="text-xs text-slate-500">
              {availability?.available
                ? "Takes the step that is waiting, uploads the result, and lets the server check it before it counts."
                : explainRefusal(availability?.reason)}
            </p>
          </>
        )}

        {busy && (
          <button
            type="button"
            onClick={onCancel}
            className="w-full rounded-xl border border-slate-400 px-5 py-3 text-sm font-semibold"
          >
            Stop
          </button>
        )}
      </div>

      {progress && (
        <div className="space-y-2">
          <progress value={progress.percent} max={100} className="w-full" />
          <p className="text-sm text-slate-700">
            {progress.message} ({Math.round(progress.percent)}%)
          </p>
        </div>
      )}

      {serverOutcome && (
        <p className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
          {serverOutcome}
        </p>
      )}

      {preview && previewSrc && (
        <section aria-labelledby="output-heading" className="space-y-3">
          <h3 id="output-heading" className="text-sm font-bold">
            What this phone produced
          </h3>
          <video
            key={preview.path}
            src={previewSrc}
            controls
            playsInline
            className="w-full rounded-xl bg-black"
          />
          <dl className="grid grid-cols-2 gap-2 text-xs">
            <div className="rounded border border-slate-200 p-2">
              <dt className="text-slate-600">Length</dt>
              <dd className="font-semibold">{preview.durationSeconds.toFixed(2)}s</dd>
            </div>
            <div className="rounded border border-slate-200 p-2">
              <dt className="text-slate-600">Size</dt>
              <dd className="font-semibold">
                {(preview.fileSizeBytes / 1e6).toFixed(1)} MB
              </dd>
            </div>
            <div className="rounded border border-slate-200 p-2">
              <dt className="text-slate-600">Sound</dt>
              <dd className="font-semibold">
                {preview.hasAudioTrack ? "Present" : "None"}
              </dd>
            </div>
            <div className="rounded border border-slate-200 p-2">
              <dt className="text-slate-600">Scene joins</dt>
              <dd className="font-semibold">
                {preview.crossDissolved ? "Cross-dissolve" : "Hard cuts"}
              </dd>
            </div>
          </dl>
          {!preview.crossDissolved && draft?.montage && (
            <p className="text-xs text-amber-800">
              The dissolving composition would not export on this phone, so the scenes were
              joined with hard cuts. A server render dissolves them — worth noting when
              comparing the two.
            </p>
          )}
          {draft?.final?.coverPath && (
            <p className="text-xs text-slate-600">
              A cover image was taken from this video&apos;s own frames.
            </p>
          )}
        </section>
      )}
    </div>
  );
}
