"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Capacitor } from "@capacitor/core";

import { MONTAGE_TRANSITIONS, MOTION_PRESETS, type MontageTransition, type MotionPreset } from "@/config/montage";
import { MOTION_TEMPLATES } from "@/config/motionTemplates";
import { BACKGROUND_MUSIC_TRACKS } from "@/config/backgroundMusic";
import type { CaptionLanguage } from "@/lib/mobile/deviceRenderCaptions";
import { getNativeRenderCapabilities } from "@/lib/mobile/deviceVideoRender";
import { supportsManifestRender, cancelDeviceRender } from "@/lib/mobile/deviceRenderBridge";
import {
  checkDeviceRenderAvailability,
  explainRefusal,
  runDeviceRender,
  type DeviceRenderAvailability,
  type DeviceRenderProgress,
} from "@/lib/mobile/deviceRenderClient";
import {
  autoArrange,
  documentDurationSeconds,
  emptyDocument,
  findSource,
  nextId,
  readDuration,
  validateDocument,
  type EditorDocument,
  type EditorRatio,
  type EditorShot,
  type EditorSource,
} from "./editorState";
import { releaseLocalDraft, renderLocalDraft, type LocalDraftResult } from "./localDraft";
import { CapabilityBanner } from "./CapabilityBanner";
import { SourcePicker } from "./SourcePicker";
import { SceneList } from "./SceneList";
import { AudioPanel } from "./AudioPanel";
import { StylePanel } from "./StylePanel";
import { RenderPanel } from "./RenderPanel";

/**
 * The phone video editor.
 *
 * Replaces the old two-button lab. The workflow is the one the pipeline already
 * has — choose material, order it into scenes, set motion and trims, pick the
 * voice and bed, choose captions and a template, render, review, deliver —
 * arranged as steps on a phone screen rather than as a flat page.
 *
 * TWO MODES, NEVER CONFUSED. Without a `requestId` this is a DRAFT tool: it
 * renders on the phone and nothing it produces touches a job, a channel or a
 * credit. With one, it also offers to take that request's queued render step,
 * and then everything goes through the server's lease, verification and
 * completion. The distinction is stated on screen, not left to be inferred from
 * which buttons happen to be enabled.
 *
 * EVERY UNFINISHED CAPABILITY IS LABELLED. `CapabilityBanner` reads the native
 * build and says what this phone can and cannot do; `RenderPanel` says which
 * parts of a render are approximations of the Mac's output. An editor that
 * silently omits a transition is worse than one that says it did.
 */

export interface MobileVideoEditorProps {
  /** When present, the editor can also render this request's queued step. */
  requestId?: string | null;
  /** Shown in the header so a tester knows which video they are looking at. */
  requestLabel?: string | null;
}

type Step = "source" | "scenes" | "audio" | "style" | "render";

const STEPS: { id: Step; label: string }[] = [
  { id: "source", label: "Media" },
  { id: "scenes", label: "Scenes" },
  { id: "audio", label: "Sound" },
  { id: "style", label: "Captions" },
  { id: "render", label: "Render" },
];

export default function MobileVideoEditor({ requestId, requestLabel }: MobileVideoEditorProps) {
  const [step, setStep] = useState<Step>("source");
  const [document, setDocument] = useState<EditorDocument>(emptyDocument);
  const [nativeReady, setNativeReady] = useState<boolean | null>(null);
  const [pluginVersion, setPluginVersion] = useState<number | null>(null);
  const [freeBytes, setFreeBytes] = useState<number | null>(null);
  const [availability, setAvailability] = useState<DeviceRenderAvailability | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<DeviceRenderProgress | null>(null);
  const [draft, setDraft] = useState<LocalDraftResult | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [serverOutcome, setServerOutcome] = useState<string | null>(null);

  const cancelRequested = useRef(false);
  const draftRef = useRef<LocalDraftResult | null>(null);
  draftRef.current = draft;

  // ── native capability probe ───────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const capabilities = await getNativeRenderCapabilities();
      const ready = await supportsManifestRender();
      if (cancelled) return;
      setPluginVersion(capabilities?.nativePluginVersion ?? null);
      setFreeBytes(capabilities?.freeBytes ?? null);
      setNativeReady(ready);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // ── what the server would hand this phone ─────────────────────────────────
  useEffect(() => {
    if (!requestId) return;
    let cancelled = false;
    const poll = async () => {
      const result = await checkDeviceRenderAvailability(requestId);
      if (!cancelled) setAvailability(result);
    };
    void poll();
    // Slow on purpose: the answer changes when an approval gate clears, which
    // is a human-speed event. A tight poll would be a request per second for
    // the whole time the screen is open.
    const timer = setInterval(() => void poll(), 15_000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [requestId]);

  // Free the previews and native files this screen is holding.
  useEffect(() => {
    return () => {
      void releaseLocalDraft(draftRef.current);
    };
  }, []);

  const problems = useMemo(() => validateDocument(document), [document]);
  const totalSeconds = useMemo(() => documentDurationSeconds(document), [document]);

  const update = useCallback((change: (current: EditorDocument) => EditorDocument) => {
    // Any edit invalidates the rendered draft: showing a preview that no longer
    // matches the timeline is how a tester signs off on the wrong thing.
    setDraft((current) => {
      void releaseLocalDraft(current);
      return null;
    });
    setDocument(change);
  }, []);

  // ── media ─────────────────────────────────────────────────────────────────
  const addFiles = useCallback(
    async (files: FileList | null) => {
      setError(null);
      const picked = Array.from(files ?? []).slice(0, 20);
      if (picked.length === 0) return;

      try {
        const added: EditorSource[] = [];
        for (const file of picked) {
          const isClip = file.type.startsWith("video/");
          added.push({
            id: nextId("src"),
            kind: isClip ? "clip" : "image",
            file,
            previewUrl: URL.createObjectURL(file),
            durationSeconds: isClip ? await readDuration(file) : null,
            fileName: file.name,
          });
        }
        update((current) => {
          const sources = [...current.sources, ...added];
          return {
            ...current,
            sources,
            // Only auto-arrange the first time, so adding a photo later does not
            // throw away an order someone has already set.
            scenes: current.scenes.length === 0 ? autoArrange(sources) : current.scenes,
          };
        });
        setMessage(`${added.length} item(s) added. Originals stay on this phone.`);
      } catch (failure) {
        setError(failure instanceof Error ? failure.message : String(failure));
      }
    },
    [update]
  );

  const removeSource = useCallback(
    (sourceId: string) => {
      update((current) => {
        const source = findSource(current, sourceId);
        if (source) URL.revokeObjectURL(source.previewUrl);
        return {
          ...current,
          sources: current.sources.filter((item) => item.id !== sourceId),
          scenes: current.scenes.map((scene) => ({
            ...scene,
            shots: scene.shots.filter((shot) => shot.sourceId !== sourceId),
          })),
        };
      });
    },
    [update]
  );

  // ── scenes ────────────────────────────────────────────────────────────────
  const patchShot = useCallback(
    (sceneId: string, shotId: string, change: Partial<EditorShot>) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) =>
          scene.id !== sceneId
            ? scene
            : {
                ...scene,
                shots: scene.shots.map((shot) =>
                  shot.id === shotId ? { ...shot, ...change } : shot
                ),
              }
        ),
      }));
    },
    [update]
  );

  const moveShot = useCallback(
    (sceneId: string, index: number, by: -1 | 1) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) => {
          if (scene.id !== sceneId) return scene;
          const target = index + by;
          if (target < 0 || target >= scene.shots.length) return scene;
          const shots = [...scene.shots];
          [shots[index], shots[target]] = [shots[target], shots[index]];
          return { ...scene, shots };
        }),
      }));
    },
    [update]
  );

  const removeShot = useCallback(
    (sceneId: string, shotId: string) => {
      update((current) => ({
        ...current,
        scenes: current.scenes
          .map((scene) =>
            scene.id !== sceneId
              ? scene
              : { ...scene, shots: scene.shots.filter((shot) => shot.id !== shotId) }
          )
          .filter((scene) => scene.shots.length > 0),
      }));
    },
    [update]
  );

  const addScene = useCallback(() => {
    update((current) => ({
      ...current,
      scenes: [...current.scenes, { id: nextId("scene"), transitionIn: "fade", shots: [] }],
    }));
  }, [update]);

  const addShotToScene = useCallback(
    (sceneId: string, sourceId: string) => {
      update((current) => {
        const source = findSource(current, sourceId);
        if (!source) return current;
        const clipLength = source.durationSeconds ?? 0;
        const duration = source.kind === "clip" && clipLength > 0
          ? Math.min(3, Math.max(0.5, clipLength))
          : 3;
        return {
          ...current,
          scenes: current.scenes.map((scene) =>
            scene.id !== sceneId
              ? scene
              : {
                  ...scene,
                  shots: [
                    ...scene.shots,
                    {
                      id: nextId("shot"),
                      sourceId,
                      durationSeconds: Math.round(duration * 10) / 10,
                      motion: source.kind === "clip" ? "static" : "ken_burns_in",
                      trimStartSeconds: 0,
                      trimEndSeconds:
                        source.kind === "clip" && clipLength > 0
                          ? Math.round(Math.min(clipLength, duration) * 10) / 10
                          : null,
                      focusX: 0.5,
                      focusY: 0.5,
                    } satisfies EditorShot,
                  ],
                }
          ),
        };
      });
    },
    [update]
  );

  const setSceneTransition = useCallback(
    (sceneId: string, transition: MontageTransition) => {
      update((current) => ({
        ...current,
        scenes: current.scenes.map((scene) =>
          scene.id === sceneId ? { ...scene, transitionIn: transition } : scene
        ),
      }));
    },
    [update]
  );

  // ── rendering ─────────────────────────────────────────────────────────────
  const renderDraft = useCallback(async () => {
    setBusy(true);
    setError(null);
    setServerOutcome(null);
    cancelRequested.current = false;
    setProgress({ phase: "rendering", percent: 0, message: "Starting the draft render…" });

    try {
      const result = await renderLocalDraft(document, {
        onProgress: (stage, percent) =>
          setProgress({
            phase: "rendering",
            percent,
            message:
              stage === "montage"
                ? "Building the picture from your photos and clips…"
                : stage === "master"
                  ? "Mixing the voice and the bed…"
                  : "Burning in the captions and template…",
          }),
        shouldCancel: () => cancelRequested.current,
      });
      void releaseLocalDraft(draftRef.current);
      setDraft(result);
      setMessage(
        result.final
          ? "Draft finished with captions and sound."
          : result.master
            ? "Draft finished with sound. Add captions to see the finished look."
            : "Silent draft finished. Add a speaking voice to hear it."
      );
      setProgress({ phase: "done", percent: 100, message: "Draft ready." });
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
      setProgress(null);
    } finally {
      setBusy(false);
    }
  }, [document]);

  const renderForServer = useCallback(async () => {
    if (!requestId) return;
    setBusy(true);
    setError(null);
    setServerOutcome(null);
    cancelRequested.current = false;

    try {
      const outcome = await runDeviceRender({
        requestId,
        onProgress: setProgress,
        shouldCancel: () => cancelRequested.current,
      });

      if (outcome.status === "completed") {
        setServerOutcome("Done. The server checked the video and attached it to your request.");
      } else if (outcome.status === "refused") {
        setServerOutcome(explainRefusal(outcome.reason));
      } else if (outcome.status === "released") {
        setServerOutcome("Stopped. The server will render this one instead.");
      } else {
        setServerOutcome(
          `This phone could not finish it, so the server will: ${outcome.reason ?? "unknown"}`
        );
      }
      // Refresh what is available now that the step may have moved on.
      setAvailability(await checkDeviceRenderAvailability(requestId));
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    } finally {
      setBusy(false);
    }
  }, [requestId]);

  const cancel = useCallback(async () => {
    cancelRequested.current = true;
    await cancelDeviceRender();
    setMessage("Stopping…");
  }, []);

  // ── layout ────────────────────────────────────────────────────────────────
  const card = "rounded-2xl border border-slate-200 bg-white p-4 shadow-sm";

  return (
    <main className="mx-auto max-w-3xl space-y-4 bg-slate-50 px-4 pb-24 pt-5 text-slate-900 sm:px-6">
      <header className="space-y-1">
        <p className="text-xs font-bold uppercase tracking-widest text-blue-700">
          Phone video editor
        </p>
        <h1 className="text-2xl font-bold">
          {requestLabel ? requestLabel : "Make a video on this phone"}
        </h1>
        <p className="text-sm text-slate-600">
          {requestId
            ? "Edit and render this request on your phone. Approvals, credits and publishing stay on the server."
            : "A draft tool. Nothing here submits a request, spends credits or publishes anything."}
        </p>
      </header>

      <CapabilityBanner
        nativeReady={nativeReady}
        pluginVersion={pluginVersion}
        freeBytes={freeBytes}
        isNative={Capacitor.isNativePlatform()}
      />

      <nav
        aria-label="Editing steps"
        className="sticky top-0 z-10 -mx-4 flex gap-1 overflow-x-auto bg-slate-50/95 px-4 py-2 backdrop-blur sm:-mx-6 sm:px-6"
      >
        {STEPS.map((entry) => (
          <button
            key={entry.id}
            type="button"
            onClick={() => setStep(entry.id)}
            aria-current={step === entry.id ? "step" : undefined}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold ${
              step === entry.id
                ? "bg-blue-700 text-white"
                : "border border-slate-300 bg-white text-slate-700"
            }`}
          >
            {entry.label}
          </button>
        ))}
      </nav>

      {step === "source" && (
        <section className={card} aria-labelledby="media-heading">
          <h2 id="media-heading" className="text-lg font-semibold">
            Photos and clips
          </h2>
          <SourcePicker
            sources={document.sources}
            ratio={document.ratio}
            onAdd={addFiles}
            onRemove={removeSource}
            onRatioChange={(ratio: EditorRatio) =>
              update((current) => ({ ...current, ratio }))
            }
            disabled={busy}
          />
        </section>
      )}

      {step === "scenes" && (
        <section className={card} aria-labelledby="scenes-heading">
          <h2 id="scenes-heading" className="text-lg font-semibold">
            Scenes, order and motion
          </h2>
          <SceneList
            document={document}
            transitions={MONTAGE_TRANSITIONS}
            motions={MOTION_PRESETS as MotionPreset[]}
            onPatchShot={patchShot}
            onMoveShot={moveShot}
            onRemoveShot={removeShot}
            onAddScene={addScene}
            onAddShot={addShotToScene}
            onSceneTransition={setSceneTransition}
            disabled={busy}
          />
        </section>
      )}

      {step === "audio" && (
        <section className={card} aria-labelledby="audio-heading">
          <h2 id="audio-heading" className="text-lg font-semibold">
            Speaking voice and background
          </h2>
          <AudioPanel
            document={document}
            tracks={BACKGROUND_MUSIC_TRACKS}
            hasServerJob={Boolean(requestId)}
            onVoiceFile={(file) => update((current) => ({ ...current, voiceFile: file }))}
            onMusicFile={(file) => update((current) => ({ ...current, musicFile: file }))}
            onMusicTrack={(trackId) =>
              update((current) => ({ ...current, musicTrackId: trackId }))
            }
            disabled={busy}
          />
        </section>
      )}

      {step === "style" && (
        <section className={card} aria-labelledby="style-heading">
          <h2 id="style-heading" className="text-lg font-semibold">
            Captions and template
          </h2>
          <StylePanel
            document={document}
            templates={MOTION_TEMPLATES}
            onLanguages={(languages: CaptionLanguage[]) =>
              update((current) => ({ ...current, captionLanguages: languages }))
            }
            onTemplate={(templateId) =>
              update((current) => ({ ...current, templateId }))
            }
            disabled={busy}
          />
        </section>
      )}

      {step === "render" && (
        <section className={card} aria-labelledby="render-heading">
          <h2 id="render-heading" className="text-lg font-semibold">
            Render and review
          </h2>
          <RenderPanel
            problems={problems}
            totalSeconds={totalSeconds}
            busy={busy}
            nativeReady={nativeReady === true}
            hasVoice={Boolean(document.voiceFile)}
            availability={availability}
            progress={progress}
            draft={draft}
            serverOutcome={serverOutcome}
            onRenderDraft={() => void renderDraft()}
            onRenderForServer={requestId ? () => void renderForServer() : undefined}
            onCancel={() => void cancel()}
          />
        </section>
      )}

      <div role="status" aria-live="polite" className="space-y-2">
        {message && <p className="text-sm text-slate-700">{message}</p>}
        {error && (
          <p className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            {error}
          </p>
        )}
      </div>
    </main>
  );
}
