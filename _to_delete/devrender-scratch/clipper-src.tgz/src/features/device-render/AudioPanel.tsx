"use client";

import type { MusicTrack } from "@/config/backgroundMusic";
import {
  DEVICE_MUSIC_BED_VOLUME,
  DEVICE_MUSIC_LEAD_IN_SECONDS,
} from "@/lib/mobile/deviceRenderAudio";
import type { EditorDocument } from "./editorState";

/**
 * The speaking voice and the bed.
 *
 * THE ONE THING THIS SCREEN HAS TO GET ACROSS is where the narration comes
 * from. In a real job it is the approved ElevenLabs voice, generated and
 * approved on the server, and the phone downloads it — a locally chosen file
 * would be a different video from the one that was approved. In a draft there is
 * no approved voice yet, so a local file stands in. Saying which is which is the
 * difference between a useful test and a misleading one.
 *
 * The mix numbers are shown rather than hidden because a tester listening for
 * "is the bed ducking correctly" needs to know what correct sounds like.
 */
export function AudioPanel({
  document,
  tracks,
  hasServerJob,
  onVoiceFile,
  onMusicFile,
  onMusicTrack,
  disabled,
}: {
  document: EditorDocument;
  tracks: MusicTrack[];
  hasServerJob: boolean;
  onVoiceFile: (file: File | null) => void;
  onMusicFile: (file: File | null) => void;
  onMusicTrack: (trackId: string | null) => void;
  disabled: boolean;
}) {
  return (
    <div className="mt-3 space-y-4">
      <div className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
        {hasServerJob ? (
          <>
            <p className="font-semibold">A real render uses the approved voice.</p>
            <p className="mt-1">
              When this phone renders your request, it downloads the ElevenLabs voice you
              approved. The file below is only used for a draft.
            </p>
          </>
        ) : (
          <>
            <p className="font-semibold">This is a draft, so choose a stand-in voice.</p>
            <p className="mt-1">
              A real job uses the approved ElevenLabs voice instead. Nothing you pick here is
              ever published.
            </p>
          </>
        )}
      </div>

      <label className="block text-sm">
        <span className="font-medium">Speaking voice (for the draft)</span>
        <input
          type="file"
          accept="audio/mpeg,audio/mp4,audio/wav,audio/x-m4a"
          disabled={disabled}
          onChange={(event) => onVoiceFile(event.target.files?.[0] ?? null)}
          className="mt-1 block w-full text-sm"
        />
        <span className="mt-1 block text-xs text-slate-500">
          {document.voiceFile
            ? `Using ${document.voiceFile.name}.`
            : "Without a voice the draft stops at the silent picture."}
        </span>
      </label>

      <label className="block text-sm">
        <span className="font-medium">Background track</span>
        <select
          value={document.musicTrackId ?? ""}
          disabled={disabled}
          onChange={(event) => onMusicTrack(event.target.value || null)}
          className="mt-1 block w-full rounded-lg border border-slate-300 p-2"
        >
          <option value="">No background music</option>
          {tracks.map((track) => (
            <option key={track.id} value={track.id}>
              {track.label}
            </option>
          ))}
        </select>
        <span className="mt-1 block text-xs text-slate-500">
          This is the track a real render would use. For a draft on this phone, pick the same
          file below so you can hear the mix.
        </span>
      </label>

      <label className="block text-sm">
        <span className="font-medium">Background track file (for the draft)</span>
        <input
          type="file"
          accept="audio/mpeg,audio/mp4,audio/wav,audio/x-m4a"
          disabled={disabled}
          onChange={(event) => onMusicFile(event.target.files?.[0] ?? null)}
          className="mt-1 block w-full text-sm"
        />
        <span className="mt-1 block text-xs text-slate-500">
          {document.musicFile ? `Using ${document.musicFile.name}.` : "Optional."}
        </span>
      </label>

      <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
        <p className="font-semibold text-slate-800">How the mix is built</p>
        <ul className="mt-1 list-disc space-y-1 pl-5">
          <li>
            The clip opens on {DEVICE_MUSIC_LEAD_IN_SECONDS}s of music before the narration
            starts.
          </li>
          <li>The voice is levelled to −16 LUFS with a −1.5 dBTP ceiling.</li>
          <li>
            The bed sits at {Math.round(DEVICE_MUSIC_BED_VOLUME * 100)}% and ducks under speech,
            recovering between sentences and under the ending.
          </li>
          <li>Camera sound from your clips is never used.</li>
        </ul>
      </div>
    </div>
  );
}
