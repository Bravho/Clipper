"use client";

import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";
import type { DeviceRenderManifest } from "@/lib/mobile/deviceRenderContract";
import {
  getNativeRenderCapabilities,
  releaseStagedLocalSource,
  stageLocalSourceForNative,
} from "@/lib/mobile/deviceVideoRender";
import { readLocalMaterial } from "@/features/requests/localMediaStore";
import type { LocalMediaDescriptor } from "@/lib/mobile/localMediaContract";

/**
 * The v5 half of the native bridge: render a whole manifest, and upload what it
 * produced.
 *
 * Kept separate from `deviceVideoRender.ts` on purpose. That module is the v1-v4
 * surface — staging, the single-clip primitive, the silent timeline, the audible
 * draft — and installed apps still run it. This module is only reachable once a
 * device reports plugin version 5, so a build that predates the editor can go on
 * working as a draft tester instead of failing on a method it does not have.
 */

/** The minimum native build that can render a manifest end to end. */
export const MANIFEST_RENDER_PLUGIN_VERSION = 5;

export interface NativeManifestResult {
  /** Native path of the rendered MP4. Release it once the server confirms. */
  path: string;
  fileSizeBytes: number;
  durationSeconds: number;
  hasAudioTrack: boolean;
  width: number;
  height: number;
  stage: string;
  /**
   * Whether the montage's scene joins are true cross-dissolves.
   *
   * Android builds the dissolve from a two-sequence composition, which is the
   * one operation with no FFmpeg equivalent; if that fails to export it retries
   * with hard cuts. A tester comparing a phone export against the Mac's needs to
   * know which they are looking at, so the flag is surfaced rather than buried.
   */
  crossDissolved: boolean;
  /** Native path of the cover still, for a stage that produces one. */
  coverPath?: string;
}

export interface NativeUploadPart {
  partNumber: number;
  eTag: string;
}

interface DeviceManifestRenderPlugin {
  renderManifest(input: {
    manifest: string;
    stagedSources: { key: string; sourceUrl: string }[];
  }): Promise<NativeManifestResult>;
  uploadOutput(input: {
    path: string;
    partUrls: string[];
    partSizeBytes: number;
    coverPath?: string;
    coverUrl?: string;
  }): Promise<{ parts: NativeUploadPart[] }>;
  cancel(): Promise<void>;
  releaseOutput(input: { path: string }): Promise<void>;
  addListener(
    eventName: "renderProgress" | "uploadProgress",
    listener: (event: { percent: number }) => void
  ): Promise<PluginListenerHandle>;
}

const NativeRenderer = registerPlugin<DeviceManifestRenderPlugin>("DeviceVideoRender");

/** Can this build render a manifest, or only the older draft primitives? */
export async function supportsManifestRender(): Promise<boolean> {
  const capabilities = await getNativeRenderCapabilities();
  return Boolean(
    capabilities &&
      capabilities.nativePluginVersion >= MANIFEST_RENDER_PLUGIN_VERSION &&
      capabilities.supportsH264Encode &&
      capabilities.supportsAacEncode
  );
}

/** One device-private original, staged into native cache for the renderer. */
export interface StagedLocalSource {
  key: string;
  sourceUrl: string;
}

/**
 * Copy the device-private originals a manifest names into native cache.
 *
 * This is the whole point of the local-first path: a photo or clip the
 * requester chose never leaves the phone, so the manifest refers to it by
 * `localId` and the bytes move from the WebView's private storage into the
 * plugin's cache without touching the network. Anything with a `url` is left
 * alone — the renderer fetches it itself.
 *
 * The caller MUST release these afterwards; `renderManifestOnDevice` does.
 */
export async function stageManifestSources(
  manifest: DeviceRenderManifest,
  descriptorsByLocalId: Map<string, LocalMediaDescriptor>
): Promise<StagedLocalSource[]> {
  const staged: StagedLocalSource[] = [];
  try {
    for (const source of manifest.sources) {
      if (!source.localId) continue;
      const descriptor = descriptorsByLocalId.get(source.localId);
      if (!descriptor) {
        throw new Error(
          `This phone no longer has the original for ${source.localId}. Re-select it to render here.`
        );
      }
      const file = await readLocalMaterial(descriptor);
      const result = await stageLocalSourceForNative(file);
      staged.push({ key: source.assetId, sourceUrl: result.sourceUrl });
    }
    return staged;
  } catch (error) {
    await releaseStagedSources(staged);
    throw error;
  }
}

export async function releaseStagedSources(staged: StagedLocalSource[]): Promise<void> {
  await Promise.allSettled(
    staged.map((source) => releaseStagedLocalSource(source.sourceUrl))
  );
}

/**
 * Render one manifest stage natively.
 *
 * Staged sources are released as soon as the render returns, whether it
 * succeeded or not — they are copies, and leaving them in the plugin's cache is
 * how a phone with a full disk gets fuller.
 */
export async function renderManifestOnDevice(
  manifest: DeviceRenderManifest,
  staged: StagedLocalSource[]
): Promise<NativeManifestResult> {
  if (!Capacitor.isNativePlatform() || !(await supportsManifestRender())) {
    throw new Error("This app build cannot render a video on this phone yet.");
  }
  try {
    return await NativeRenderer.renderManifest({
      manifest: JSON.stringify(manifest),
      stagedSources: staged,
    });
  } finally {
    await releaseStagedSources(staged);
  }
}

/** Upload a rendered file to the presigned part URLs the server minted. */
export async function uploadRenderedOutput(input: {
  path: string;
  partUrls: string[];
  partSizeBytes: number;
  coverPath?: string | null;
  coverUrl?: string | null;
}): Promise<NativeUploadPart[]> {
  const { parts } = await NativeRenderer.uploadOutput({
    path: input.path,
    partUrls: input.partUrls,
    partSizeBytes: input.partSizeBytes,
    ...(input.coverPath ? { coverPath: input.coverPath } : {}),
    ...(input.coverUrl ? { coverUrl: input.coverUrl } : {}),
  });
  return parts;
}

export async function cancelDeviceRender(): Promise<void> {
  await NativeRenderer.cancel().catch(() => undefined);
}

export async function releaseRenderedOutput(path: string): Promise<void> {
  await NativeRenderer.releaseOutput({ path }).catch(() => undefined);
}

/** Subscribe to render and upload progress as separate streams. */
export async function observeManifestProgress(listeners: {
  onRender?: (percent: number) => void;
  onUpload?: (percent: number) => void;
}): Promise<() => Promise<void>> {
  const handles: PluginListenerHandle[] = [];
  if (listeners.onRender) {
    handles.push(
      await NativeRenderer.addListener("renderProgress", ({ percent }) =>
        listeners.onRender?.(percent)
      )
    );
  }
  if (listeners.onUpload) {
    handles.push(
      await NativeRenderer.addListener("uploadProgress", ({ percent }) =>
        listeners.onUpload?.(percent)
      )
    );
  }
  return async () => {
    await Promise.allSettled(handles.map((handle) => handle.remove()));
  };
}
