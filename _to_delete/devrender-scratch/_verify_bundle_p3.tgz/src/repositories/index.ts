/**
 * Repository registry — single source of repository instances.
 *
 * Services import repositories from here only.
 *
 * Phase 2A repositories: backed by PostgreSQL.
 * Phase 2B repositories: backed by in-memory mock (PostgreSQL not yet connected).
 *
 * To swap Phase 2B to PostgreSQL:
 *   1. Implement Postgres* classes under repositories/postgres/.
 *   2. Import them below and replace the Mock* instances.
 *   3. Delete the corresponding Mock* files.
 *
 * To revert Phase 2A to mocks for isolated unit tests, swap the imports
 * back to the Mock* implementations and pass a fresh Map() to each constructor.
 */

// ── Phase 2A — PostgreSQL ────────────────────────────────────────────────────
import { PostgresUserRepository } from "./postgres/PostgresUserRepository";
import { PostgresAuthIdentityRepository } from "./postgres/PostgresAuthIdentityRepository";
import { PostgresCreditWalletRepository } from "./postgres/PostgresCreditWalletRepository";
import { PostgresCreditTransactionRepository } from "./postgres/PostgresCreditTransactionRepository";
import { PostgresTermsAcceptanceRepository } from "./postgres/PostgresTermsAcceptanceRepository";
import { PostgresEmailVerificationTokenRepository } from "./postgres/PostgresEmailVerificationTokenRepository";
import { PostgresPasswordResetTokenRepository } from "./postgres/PostgresPasswordResetTokenRepository";

export const userRepository = new PostgresUserRepository();
export const authIdentityRepository = new PostgresAuthIdentityRepository();
export const creditWalletRepository = new PostgresCreditWalletRepository();
export const creditTransactionRepository = new PostgresCreditTransactionRepository();
export const termsAcceptanceRepository = new PostgresTermsAcceptanceRepository();
export const emailVerificationTokenRepository = new PostgresEmailVerificationTokenRepository();
// "ลืมรหัสผ่าน" reset links. Requires migration 029.
export const passwordResetTokenRepository = new PostgresPasswordResetTokenRepository();

// ── New Repositories — PostgreSQL ────────────────────────────────────────────
import { PostgresDeletedAccountRegistryRepository } from "./postgres/PostgresDeletedAccountRegistryRepository";
import { PostgresBusinessProfileRepository } from "./postgres/PostgresBusinessProfileRepository";
import { PostgresCreditPurchaseLogRepository } from "./postgres/PostgresCreditPurchaseLogRepository";
import { PostgresPaymentIntentRepository } from "./postgres/PostgresPaymentIntentRepository";

// Account-deletion fraud-prevention registry. Requires migration 014.
export const deletedAccountRegistryRepository =
  new PostgresDeletedAccountRegistryRepository();
export const businessProfileRepository = new PostgresBusinessProfileRepository();
export const creditPurchaseLogRepository = new PostgresCreditPurchaseLogRepository();
// PromptPay top-up intents (Stripe). Requires migration 007.
export const paymentIntentRepository = new PostgresPaymentIntentRepository();

// ── Phase 2B — PostgreSQL ────────────────────────────────────────────────────
// Clip requests, their status history, and uploaded assets now persist to
// PostgreSQL so they survive server restarts and page refreshes. Requires
// migration 006 (id defaults) to have been applied — the Phase 2B tables
// declared `id TEXT PRIMARY KEY` with no default, which 006 backfills.
import { PostgresClipRequestRepository } from "./postgres/PostgresClipRequestRepository";
import { PostgresRequestStatusHistoryRepository } from "./postgres/PostgresRequestStatusHistoryRepository";
import { PostgresUploadedAssetRepository } from "./postgres/PostgresUploadedAssetRepository";
import { MockPublishingLinkRepository } from "./mock/MockPublishingLinkRepository";

export const clipRequestRepository = new PostgresClipRequestRepository();
export const requestStatusHistoryRepository = new PostgresRequestStatusHistoryRepository();
export const uploadedAssetRepository = new PostgresUploadedAssetRepository();
export const publishingLinkRepository = new MockPublishingLinkRepository(); // TODO: PostgresPublishingLinkRepository (no Postgres impl yet)

// ── Phase 2C — Mock (TODO: replace with Postgres implementations) ────────────
import { MockInternalNoteRepository } from "./mock/MockInternalNoteRepository";

// TODO: PostgreSQL Phase 2C — replace each Mock* below with Postgres* equivalent.
//   PostgresInternalNoteRepository
export const internalNoteRepository = new MockInternalNoteRepository();

// ── Phase 2D — Mock (TODO: replace with Postgres implementations) ────────────
import { MockProductionReviewRepository } from "./mock/MockProductionReviewRepository";

// TODO: PostgreSQL Phase 2D — replace each Mock* below with Postgres* equivalent.
//   PostgresProductionReviewRepository
export const productionReviewRepository = new MockProductionReviewRepository();

// ── Editor Profiles — Mock (TODO: replace with Postgres implementation) ──────
import { MockEditorProfileRepository } from "./mock/MockEditorProfileRepository";

export const editorProfileRepository = new MockEditorProfileRepository();

// AI Video Pipeline - PostgreSQL
// Pipeline jobs are PostgreSQL-backed so browser reloads and server restarts
// resume from the current AI generation/approval step.
import { PostgresVideoGenerationJobRepository } from "./postgres/PostgresVideoGenerationJobRepository";
import { MockVideoPublishRecordRepository } from "./mock/MockVideoPublishRecordRepository";

export const videoGenerationJobRepository = new PostgresVideoGenerationJobRepository();
export const videoPublishRecordRepository = new MockVideoPublishRecordRepository(); // TODO: PostgresVideoPublishRecordRepository (no Postgres impl / table yet)

// Flat FIFO render-task queue (Mac Mini worker). One row per enqueued heavy
// step, mixed across all requesters. Requires migration 025.
import { PostgresRenderTaskRepository } from "./postgres/PostgresRenderTaskRepository";
// Purchased monthly video allowances (migration 033). The free allowance needs
// no table — it is derived from submitted requests in the last 30 days.
import { PostgresVideoAllowanceWindowRepository } from "./postgres/PostgresVideoAllowanceWindowRepository";

export const renderTaskRepository = new PostgresRenderTaskRepository();
export const videoAllowanceWindowRepository = new PostgresVideoAllowanceWindowRepository();

// ── RClipper Management — PostgreSQL ─────────────────────────────────────────
// Videos collected free (transferred from a generation project, or uploaded by
// the user) and published to the user's own social channels. Payment gates
// PUBLISHING, not collecting. Requires migration 019.
import {
  PostgresManagementProductRepository,
  PostgresManagementPurchaseRepository,
  PostgresManagementAccessPassRepository,
  PostgresManagementPublishEntitlementRepository,
  PostgresManagementUploadBundleRepository,
  PostgresManagementContentRepository,
} from "./postgres/PostgresManagementRepositories";

// Maps our users to accounts connected through the publishing provider. This
// mapping — not the provider's own filtering — is what enforces ownership.
import { PostgresSocialConnectionRepository } from "./postgres/PostgresSocialConnectionRepository";

export const socialConnectionRepository = new PostgresSocialConnectionRepository();

export const managementProductRepository = new PostgresManagementProductRepository();
export const managementPurchaseRepository = new PostgresManagementPurchaseRepository();
export const managementAccessPassRepository = new PostgresManagementAccessPassRepository();
export const managementPublishEntitlementRepository =
  new PostgresManagementPublishEntitlementRepository();
// Consumable upload-token bundles — the entry product (management_single_video).
// One token = one video to one channel; consumed atomically at publish time.
// Requires migration 020.
export const managementUploadBundleRepository =
  new PostgresManagementUploadBundleRepository();
export const managementContentRepository = new PostgresManagementContentRepository();

// Publishing: publications + their per-destination targets, and the async job
// queue that reconciles provider results. Both back the composer publish path.
import { PostgresManagementPublicationRepository } from "./postgres/PostgresManagementPublicationRepository";
import { PostgresManagementJobRepository } from "./postgres/PostgresManagementJobRepository";

export const managementPublicationRepository =
  new PostgresManagementPublicationRepository();
export const managementJobRepository = new PostgresManagementJobRepository();
