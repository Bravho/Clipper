/**
 * In-app purchase catalogue for the native shells.
 *
 * WHY PRICES DIFFER BY PLATFORM. A package always costs the SAME number of
 * credits everywhere (see src/config/videoPackages.ts and management.ts) — what
 * differs is the real money a credit costs, because Apple and Google take a
 * commission (commonly 15–30%) and only offer fixed price tiers. Absorbing that
 * at the top-up keeps every downstream price uniform: one catalogue of packages,
 * no per-platform package logic, and nothing for a store reviewer to compare
 * against a cheaper in-app price.
 *
 * ⚠️ THESE MUST MATCH THE REAL STORE CONSOLE PRODUCTS.
 * The server grants `credits` from THIS table after verifying a receipt, so a
 * mismatch either shortchanges a buyer or gives credits away. The `priceBaht`
 * figures below are the commission-adjusted intent (roughly web ÷ 0.7, rounded
 * to a plausible tier) and are DISPLAY/reference only — the store shows its own
 * localized price. Before release, reconcile every `productId` and `priceBaht`
 * against App Store Connect and Google Play Console.
 *
 * Web (Stripe PromptPay/Card) keeps 1 credit = ฿1 and lives in
 * `TOPUP_BUNDLES` in src/config/credits.ts.
 */

export interface StoreProduct {
  /** Must match the product identifier registered in the store console. */
  productId: string;
  /** Credits granted on a verified purchase. Server-side truth. */
  credits: number;
  /** Reference price in ฿ for display and reconciliation, not for charging. */
  priceBaht: number;
}

/**
 * Apple App Store products.
 *
 * Apple's Thai tiers are coarse, so the credit yield per baht is a little lower
 * than web. That is the commission, made explicit rather than hidden.
 */
export const IOS_STORE_PRODUCTS: readonly StoreProduct[] = [
  { productId: "com.rclipper.credits.50", credits: 50, priceBaht: 69 },
  { productId: "com.rclipper.credits.100", credits: 100, priceBaht: 149 },
  { productId: "com.rclipper.credits.200", credits: 200, priceBaht: 279 },
  { productId: "com.rclipper.credits.500", credits: 500, priceBaht: 699 },
  { productId: "com.rclipper.credits.1000", credits: 1000, priceBaht: 1390 },
] as const;

/** Google Play products. Play's tiers are finer, so these sit slightly lower. */
export const ANDROID_STORE_PRODUCTS: readonly StoreProduct[] = [
  { productId: "com.rclipper.credits.50", credits: 50, priceBaht: 65 },
  { productId: "com.rclipper.credits.100", credits: 100, priceBaht: 139 },
  { productId: "com.rclipper.credits.200", credits: 200, priceBaht: 269 },
  { productId: "com.rclipper.credits.500", credits: 500, priceBaht: 669 },
  { productId: "com.rclipper.credits.1000", credits: 1000, priceBaht: 1350 },
] as const;

/** The two stores the native shells ship to. */
export type StorePlatform = "ios" | "android";

export function storeProductsFor(
  platform: StorePlatform
): readonly StoreProduct[] {
  return platform === "ios" ? IOS_STORE_PRODUCTS : ANDROID_STORE_PRODUCTS;
}

/**
 * Credits a verified purchase grants.
 *
 * The PLATFORM MUST come from the verified receipt, never from the client: it
 * selects which price table is authoritative, and trusting a client-supplied
 * platform would let a caller pick whichever table is more generous.
 */
export function creditsForStoreProduct(
  productId: string,
  platform: StorePlatform
): number | null {
  return (
    storeProductsFor(platform).find((p) => p.productId === productId)?.credits ??
    null
  );
}

/**
 * @deprecated Product ids are shared across stores today, so this still resolves
 * — but it cannot express a platform-specific credit yield. Pass the receipt's
 * platform to {@link creditsForStoreProduct} instead.
 */
export const MOBILE_STORE_PRODUCTS = IOS_STORE_PRODUCTS;
