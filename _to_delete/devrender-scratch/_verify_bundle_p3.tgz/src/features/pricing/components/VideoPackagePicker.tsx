"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import {
  VIDEO_PACKAGES,
  REQUESTS_PER_PAID_MONTH,
  creditsPerMonth,
} from "@/config/videoPackages";
import type { VideoProductCode } from "@/domain/enums/VideoProductCode";
import { useI18n } from "@/i18n/client";
import { ROUTES } from "@/config/routes";

interface Props {
  /** Credits available to spend, for the "not enough" state. */
  balanceCredits: number;
  /** When the user's paid allowance currently ends, if any. */
  activeUntil?: string | null;
}

/**
 * The video package picker.
 *
 * Buying is a wallet debit against the server-side catalogue: the client sends a
 * product CODE and nothing else, so no price shown here can influence what is
 * charged. If the balance is short we send the user to top up rather than
 * failing — the 402 the API returns says the same thing.
 */
export function VideoPackagePicker({ balanceCredits, activeUntil }: Props) {
  const router = useRouter();
  const { t } = useI18n();
  const [buying, setBuying] = useState<VideoProductCode | null>(null);
  const [error, setError] = useState<string | null>(null);

  // One token per mount: a double-clicked or refreshed checkout collapses onto
  // the same purchase instead of granting two runs of months.
  const [token] = useState(() =>
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`
  );

  const cheapestPerMonth = Math.min(...VIDEO_PACKAGES.map(creditsPerMonth));

  const buy = async (code: VideoProductCode, price: number) => {
    setError(null);
    if (balanceCredits < price) {
      router.push(`${ROUTES.CREDITS}?returnTo=${encodeURIComponent(ROUTES.PRICING)}`);
      return;
    }
    setBuying(code);
    try {
      const res = await fetch("/api/video-packages/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productCode: code, idempotencyToken: `${token}-${code}` }),
      });
      const body = await res.json().catch(() => ({}));
      if (res.status === 402) {
        router.push(`${ROUTES.CREDITS}?returnTo=${encodeURIComponent(ROUTES.PRICING)}`);
        return;
      }
      if (!res.ok) throw new Error(body.error ?? t("pricing.buyFailed"));
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("pricing.buyFailed"));
    } finally {
      setBuying(null);
    }
  };

  return (
    <section>
      <h2 className="text-base font-semibold text-slate-900">
        {t("pricing.videoHeading")}
      </h2>
      <p className="mt-1 text-sm text-slate-500">
        {t("pricing.videoSubheading", { paidTotal: REQUESTS_PER_PAID_MONTH })}
      </p>

      {activeUntil && (
        <p className="mt-3 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-800">
          {t("pricing.activeUntil", { date: activeUntil })}
        </p>
      )}

      {error && (
        <div className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {error}
        </div>
      )}

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        {VIDEO_PACKAGES.map((pkg) => {
          const perMonth = creditsPerMonth(pkg);
          const isBest = perMonth === cheapestPerMonth && pkg.months > 1;
          return (
            <Card
              key={pkg.code}
              className={isBest ? "border-blue-300 ring-1 ring-blue-200" : undefined}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-slate-900">
                    {t(pkg.nameKey as never)}
                  </h3>
                  <p className="mt-1 text-xs text-slate-500">
                    {t(pkg.descriptionKey as never, {
                      paidTotal: REQUESTS_PER_PAID_MONTH,
                      months: pkg.months,
                    })}
                  </p>
                </div>
                {isBest && (
                  <span className="flex-shrink-0 rounded-full bg-blue-600 px-2 py-0.5 text-[10px] font-semibold text-white">
                    {t("pricing.bestValue")}
                  </span>
                )}
              </div>

              <div className="mt-4 flex items-end justify-between gap-3">
                <div>
                  <p className="text-2xl font-bold tabular-nums text-slate-900">
                    {pkg.priceCredits.toLocaleString()}
                  </p>
                  <p className="text-xs text-slate-400">
                    {t("pricing.creditsPerMonth", {
                      perMonth: Math.round(perMonth),
                    })}
                  </p>
                </div>
                <Button
                  size="sm"
                  loading={buying === pkg.code}
                  disabled={buying !== null}
                  onClick={() => void buy(pkg.code, pkg.priceCredits)}
                >
                  {balanceCredits < pkg.priceCredits
                    ? t("pricing.topUpFirst")
                    : t("pricing.buy")}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      <p className="mt-3 text-xs text-slate-400">{t("pricing.videoFootnote")}</p>
    </section>
  );
}
