/**
 * Which pricing tier a clip request was submitted under.
 *
 * The tier is decided ONCE, at submission, from how much of the account's trial
 * allowance had already been used (see `src/config/trial.ts`). It is then frozen
 * on the request so the paywall, the download gate and the analytics all read the
 * same answer for the rest of the request's life — changing the allowance
 * configuration later never re-prices a request that is already in flight.
 *
 * TODO: PostgreSQL — stored as TEXT on `clip_requests.pricing_tier`
 *   (migration 031, NOT NULL DEFAULT 'paid_upfront').
 */
export enum RequestPricingTier {
  /**
   * The account's free clean clip (request #1). Not charged at submission and
   * delivered WITHOUT a watermark — the download is unlocked from the moment the
   * request is submitted.
   */
  FreeClean = "free_clean",

  /**
   * A free preview clip (requests #2–#4). Not charged at submission, but the
   * requester only ever sees the watermarked sibling; paying the request price
   * via `unlockDownload()` releases the clean master.
   */
  FreePreview = "free_preview",

  /**
   * A normal paid request (#5 onward). The request price is deducted at
   * submission, so the clean master is downloadable as soon as it is produced.
   */
  PaidUpfront = "paid_upfront",
}
