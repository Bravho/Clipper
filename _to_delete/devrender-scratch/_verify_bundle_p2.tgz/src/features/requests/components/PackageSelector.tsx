"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import { CREDITS_CONFIG } from "@/config/credits";
import { EXHAUSTED_ENTITLEMENT, type RequestEntitlement } from "@/config/trial";
import { trialPriceNote } from "@/features/requests/trialCopy";
import { useI18n } from "@/i18n/client";
import type { ResumeUploadedAsset } from "./NewRequestForm";
import type { SubmitClipRequestValues } from "@/features/requests/validation/clipRequestSchema";

const NewRequestForm = dynamic(() =>
  import("./NewRequestForm").then((module) => module.NewRequestForm)
);
const ProductionPipeline = dynamic(() =>
  import("./ProductionPipeline").then((module) => module.ProductionPipeline)
);

/** Data needed to resume an existing draft (opened from the dashboard). */
export interface ResumeData {
  requestId: string;
  initialValues: Partial<SubmitClipRequestValues>;
  uploadedAssets: ResumeUploadedAsset[];
}

interface Props {
  creditBalance: number;
  /** Which rung of the trial ladder the user's next request lands on. */
  entitlement?: RequestEntitlement;
  /** When present, skip the track chooser and resume this draft directly. */
  resume?: ResumeData;
}

export function PackageSelector({
  creditBalance,
  // Defaulting to the exhausted (fully paid) entitlement is deliberate: if the
  // prop ever fails to arrive, the chooser quotes the paid price rather than
  // silently advertising a free clip the server will then charge for.
  entitlement = EXHAUSTED_ENTITLEMENT,
  resume,
}: Props) {
  const { t } = useI18n();
  const freeAvailable = entitlement.hasFreeAllowanceLeft;
  const priceNote = trialPriceNote(t, entitlement);
  // Resuming a draft jumps straight into the AI track (the only live track).
  const [selected, setSelected] = useState<"ai" | "editor" | null>(resume ? "ai" : null);
  // Duration / channels are creative preferences only — they no longer affect
  // the price (a request is a single flat charge). Kept for the pipeline display.
  const [durationSeconds, setDurationSeconds] = useState<number>(15);
  const [platformCount, setPlatformCount] = useState<number>(2);

  if (selected === "ai") {
    return (
      <div>
        {/* No track switch while resuming — the draft is already an AI request. */}
        {!resume && (
          <button
            type="button"
            onClick={() => setSelected(null)}
            className="mb-6 flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700"
          >
            {t("request.changeProduction")}
          </button>
        )}

        <div className="mb-6 rounded-xl border border-blue-200 bg-blue-50 px-5 py-4 flex items-center gap-3">
          <div className="rounded-full bg-blue-600 p-1.5">
            <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-semibold text-blue-800">{t("request.aiTrackTitle")}</p>
            <p className="text-xs text-blue-600 mt-0.5">{t("request.aiTrackBody")}</p>
          </div>
        </div>

        <NewRequestForm
          creditBalance={creditBalance}
          entitlement={entitlement}
          existingRequestId={resume?.requestId}
          initialValues={resume?.initialValues}
          uploadedAssets={resume?.uploadedAssets}
          onCreditParamsChange={(d, p) => {
            setDurationSeconds(d);
            setPlatformCount(p);
          }}
        />

        <ProductionPipeline
          durationSeconds={durationSeconds}
          totalChannels={platformCount}
        />
      </div>
    );
  }

  return (
    <div>
      <p className="mb-6 text-sm text-slate-500">
        {t("request.chooseTrack")}
      </p>

      <div className="grid gap-6 md:grid-cols-2">
        {/* AI Track */}
        <div
          className="rounded-2xl border-2 border-blue-100 bg-blue-50 p-8 flex flex-col cursor-pointer hover:border-blue-400 hover:shadow-md transition-all"
          onClick={() => setSelected("ai")}
        >
          <div className="mb-4 inline-block self-start rounded-full bg-blue-600 px-3 py-1 text-xs font-semibold text-white uppercase tracking-wider">
            AI Track
          </div>
          <h3 className="mb-3 text-2xl font-bold text-slate-900">
            {t("request.aiHeadline")}
          </h3>
          <p className="mb-6 text-slate-600 leading-relaxed flex-1">
            {t("request.aiDescription")}
          </p>
          <ul className="mb-8 space-y-2.5 text-sm text-slate-700">
            {[
              t("request.aiFeatureSubtitles"),
              t("request.aiFeatureRatios"),
              t("request.aiFeatureReady"),
              t("request.aiTurnaround"),
            ].map((f) => (
              <li key={f} className="flex items-start gap-2.5">
                <span className="mt-0.5 h-4 w-4 flex-shrink-0 rounded-full bg-blue-600 flex items-center justify-center text-white text-[10px] font-bold">
                  ✓
                </span>
                {f}
              </li>
            ))}
          </ul>
          <div className="flex items-center justify-between">
            <div>
              {freeAvailable ? (
                <>
                  <span className="text-2xl font-bold text-green-600">{t("request.free")}</span>
                  {priceNote && (
                    <span className="ml-2 text-xs text-slate-500">{priceNote}</span>
                  )}
                </>
              ) : (
                <>
              <span className="text-xs text-slate-500">{t("request.onePrice")}</span>
              <span className="ml-1 text-2xl font-bold text-slate-900">
                {CREDITS_CONFIG.REQUEST_COST_CREDITS}
              </span>
              <span className="ml-1 text-sm text-slate-400">{t("request.creditsUnit")}</span>
                </>
              )}
              {!freeAvailable && CREDITS_CONFIG.LAUNCH_DISCOUNT_ACTIVE ? (
                <p className="text-xs text-slate-400 mt-0.5">
                  <span className="line-through">
                    ฿{CREDITS_CONFIG.REQUEST_FULL_PRICE_CREDITS}
                  </span>{" "}
                  <span className="font-medium text-green-600">
                    {t("request.launchPrice", { cost: CREDITS_CONFIG.REQUEST_COST_CREDITS })}
                  </span>
                </p>
              ) : (
                <p className="text-xs text-slate-400 mt-0.5">{t("request.allStepsIncluded")}</p>
              )}
            </div>
            <span className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white">
              {t("request.startAi")}
            </span>
          </div>
        </div>

        {/* Editor Track */}
        <div className="rounded-2xl border-2 border-amber-100 bg-amber-50 p-8 flex flex-col opacity-70 cursor-not-allowed relative">
          <div className="absolute top-4 right-4 rounded-full bg-amber-500 px-3 py-1 text-xs font-semibold text-white">
            เร็วๆ นี้
          </div>
          <div className="mb-4 inline-block self-start rounded-full bg-amber-500 px-3 py-1 text-xs font-semibold text-white uppercase tracking-wider">
            Editor Track
          </div>
          <h3 className="mb-3 text-2xl font-bold text-slate-900">
            เจาะลึก · เข้าใจตลาด · เพิ่ม Reach
          </h3>
          <p className="mb-6 text-slate-600 leading-relaxed flex-1">
            เลือก Editor ที่เชี่ยวชาญ TikTok / YouTube algorithm และเข้าใจพฤติกรรม
            นักท่องเที่ยวต่างชาติ เหมาะสำหรับธุรกิจที่ต้องการ engagement สูง
          </p>
          <ul className="mb-8 space-y-2.5 text-sm text-slate-700">
            {[
              "Editor รู้จัก algorithm ของแต่ละ platform",
              "สคริปต์และ hook เฉพาะตลาดต่างชาติ",
              "Voice-over และ narration หลายภาษา",
              "ปรึกษา strategy ก่อนผลิต",
            ].map((f) => (
              <li key={f} className="flex items-start gap-2.5">
                <span className="mt-0.5 h-4 w-4 flex-shrink-0 rounded-full bg-amber-400 flex items-center justify-center text-white text-[10px] font-bold">
                  ✓
                </span>
                {f}
              </li>
            ))}
          </ul>
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm text-slate-400 italic">ราคา TBA</span>
            </div>
            <span className="rounded-lg bg-amber-300 px-4 py-2 text-sm font-semibold text-white cursor-not-allowed">
              เร็วๆ นี้
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
