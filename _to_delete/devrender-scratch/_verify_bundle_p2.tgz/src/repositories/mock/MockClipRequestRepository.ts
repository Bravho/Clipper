import { IClipRequestRepository } from "@/repositories/interfaces/IClipRequestRepository";
import {
  ClipRequest,
  CreateClipRequestInput,
  UpdateClipRequestInput,
  UpdateStaffFieldsInput,
} from "@/domain/models/ClipRequest";
import { RequestStatus } from "@/domain/enums/RequestStatus";
import { RequestPricingTier } from "@/domain/enums/RequestPricingTier";
import { CREDITS_CONFIG } from "@/config/credits";
import { SEED_CLIP_REQUESTS } from "@/seed/requestSeedData";
import { ADMIN_SEED_CLIP_REQUESTS } from "@/seed/adminSeedData";

// TODO: PostgreSQL — replace this entire class with PostgresClipRequestRepository.
//   The interface contract (IClipRequestRepository) stays the same.
//   Remove the globalThis singleton pattern and use the db pool from @/lib/db instead.

declare global {
  // eslint-disable-next-line no-var
  var __mockClipRequestStore: Map<string, ClipRequest> | undefined;
}

function getStore(): Map<string, ClipRequest> {
  if (!global.__mockClipRequestStore) {
    global.__mockClipRequestStore = new Map();
    SEED_CLIP_REQUESTS.forEach((r) =>
      global.__mockClipRequestStore!.set(r.id, { ...r })
    );
    ADMIN_SEED_CLIP_REQUESTS.forEach((r) =>
      global.__mockClipRequestStore!.set(r.id, { ...r })
    );
  }
  return global.__mockClipRequestStore;
}

export class MockClipRequestRepository implements IClipRequestRepository {
  private store: Map<string, ClipRequest>;

  constructor(store?: Map<string, ClipRequest>) {
    this.store = store ?? getStore();
  }

  // ── Requester queries ───────────────────────────────────────────────────────

  async findById(id: string): Promise<ClipRequest | null> {
    const req = this.store.get(id);
    return req ? { ...req } : null;
  }

  async findByUserId(userId: string): Promise<ClipRequest[]> {
    return [...this.store.values()]
      .filter((r) => r.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async countSubmittedRequestsByUserId(userId: string): Promise<number> {
    return [...this.store.values()].filter(
      (request) => request.userId === userId && request.submittedAt !== null
    ).length;
  }

  async findByUserIdAndStatus(
    userId: string,
    statuses: RequestStatus[]
  ): Promise<ClipRequest[]> {
    return [...this.store.values()]
      .filter((r) => r.userId === userId && statuses.includes(r.status))
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  // ── Editor queries ──────────────────────────────────────────────────────────

  async findByEditorId(editorId: string): Promise<ClipRequest[]> {
    return [...this.store.values()]
      .filter((r) => r.assignedEditorId === editorId)
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async findByEditorIdAndStatus(
    editorId: string,
    statuses: RequestStatus[]
  ): Promise<ClipRequest[]> {
    return [...this.store.values()]
      .filter((r) => r.assignedEditorId === editorId && statuses.includes(r.status))
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  // ── Staff queries ───────────────────────────────────────────────────────────

  async findByStatus(statuses: RequestStatus[]): Promise<ClipRequest[]> {
    return [...this.store.values()]
      .filter((r) => statuses.includes(r.status))
      .sort((a, b) => {
        // Sort by submittedAt ascending (oldest first) for queue processing.
        // Fall back to createdAt if submittedAt is null.
        const aTime = (a.submittedAt ?? a.createdAt).getTime();
        const bTime = (b.submittedAt ?? b.createdAt).getTime();
        return aTime - bTime;
      });
  }

  async findAll(limit?: number): Promise<ClipRequest[]> {
    const all = [...this.store.values()].sort(
      (a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()
    );
    return limit ? all.slice(0, limit) : all;
  }

  async countByStatus(): Promise<Partial<Record<RequestStatus, number>>> {
    const counts: Partial<Record<RequestStatus, number>> = {};
    for (const request of this.store.values()) {
      counts[request.status] = (counts[request.status] ?? 0) + 1;
    }
    return counts;
  }

  async findOverdue(): Promise<ClipRequest[]> {
    const now = new Date();
    const nonTerminal = new Set([
      RequestStatus.Submitted,
      RequestStatus.UnderReview,
      RequestStatus.AcceptedForProduction,
      RequestStatus.Editing,
      RequestStatus.ScheduledForPublishing,
    ]);
    return [...this.store.values()].filter(
      (r) =>
        r.confirmedDueDate !== null &&
        r.confirmedDueDate < now &&
        nonTerminal.has(r.status)
    );
  }

  async findPendingDueDateConfirmation(): Promise<ClipRequest[]> {
    const needsConfirmation = new Set([
      RequestStatus.AcceptedForProduction,
      RequestStatus.Editing,
      RequestStatus.UnderReview,
    ]);
    return [...this.store.values()]
      .filter((r) => needsConfirmation.has(r.status) && !r.dueDateConfirmed)
      .sort((a, b) => {
        const aTime = (a.submittedAt ?? a.createdAt).getTime();
        const bTime = (b.submittedAt ?? b.createdAt).getTime();
        return aTime - bTime;
      });
  }

  // ── Mutations ───────────────────────────────────────────────────────────────

  async create(input: CreateClipRequestInput): Promise<ClipRequest> {
    const request: ClipRequest = {
      ...input,
      id: crypto.randomUUID(),
      status: RequestStatus.Draft,
      estimatedDueDate: null,
      confirmedDueDate: null,
      dueDateConfirmed: false,
      holdReason: null,
      rejectionReason: null,
      queuePosition: null,
      creditConfirmed: false,
      rightsConfirmed: false,
      aiProcessingConfirmed: false,
      aiConsentVersion: null,
      aiConsentAcceptedAt: null,
      creditsCost: CREDITS_CONFIG.REQUEST_COST_CREDITS,
      // Marketplace fields
      assignedEditorId: null,
      editorType: null,
      priceBaht: 0,
      creditsUsed: 0,
      discountBaht: 0,
      amountPaidBaht: 0,
      revisionCount: 0,
      downloadUnlocked: false,
      isTrialRequest: false,
      pricingTier: RequestPricingTier.PaidUpfront,
      submittedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      effortClass: null,
      assignedStaffId: null,
    };
    this.store.set(request.id, request);
    return { ...request };
  }

  async update(id: string, input: UpdateClipRequestInput): Promise<ClipRequest> {
    const existing = this.store.get(id);
    if (!existing) throw new Error(`ClipRequest not found: ${id}`);
    const updated: ClipRequest = {
      ...existing,
      ...input,
      updatedAt: new Date(),
    };
    this.store.set(id, updated);
    return { ...updated };
  }

  async updateStaffFields(
    id: string,
    input: UpdateStaffFieldsInput
  ): Promise<ClipRequest> {
    const existing = this.store.get(id);
    if (!existing) throw new Error(`ClipRequest not found: ${id}`);
    const updated: ClipRequest = {
      ...existing,
      ...input,
      updatedAt: new Date(),
    };
    this.store.set(id, updated);
    return { ...updated };
  }

  async updateStatus(
    id: string,
    status: RequestStatus,
    extra?: Partial<
      Pick<
        ClipRequest,
        | "holdReason"
        | "rejectionReason"
        | "confirmedDueDate"
        | "dueDateConfirmed"
        | "estimatedDueDate"
        | "queuePosition"
        | "submittedAt"
        | "creditConfirmed"
        | "rightsConfirmed"
        | "aiProcessingConfirmed"
        | "aiConsentVersion"
        | "aiConsentAcceptedAt"
        | "assignedStaffId"
        | "assignedEditorId"
        | "editorType"
        | "priceBaht"
        | "creditsUsed"
        | "discountBaht"
        | "amountPaidBaht"
        | "downloadUnlocked"
        | "isTrialRequest"
        | "pricingTier"
      >
    >
  ): Promise<ClipRequest> {
    const existing = this.store.get(id);
    if (!existing) throw new Error(`ClipRequest not found: ${id}`);
    const updated: ClipRequest = {
      ...existing,
      status,
      ...(extra ?? {}),
      updatedAt: new Date(),
    };
    this.store.set(id, updated);
    return { ...updated };
  }

  async delete(id: string): Promise<void> {
    this.store.delete(id);
  }
}
