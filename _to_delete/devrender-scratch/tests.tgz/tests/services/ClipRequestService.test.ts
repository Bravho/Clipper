import { ClipRequestService } from "@/services/ClipRequestService";
import { MockClipRequestRepository } from "@/repositories/mock/MockClipRequestRepository";
import { MockRequestStatusHistoryRepository } from "@/repositories/mock/MockRequestStatusHistoryRepository";
import { MockCreditWalletRepository } from "@/repositories/mock/MockCreditWalletRepository";
import { MockCreditTransactionRepository } from "@/repositories/mock/MockCreditTransactionRepository";
import { CreditService } from "@/services/CreditService";
import { RequestStatus } from "@/domain/enums/RequestStatus";
import { Platform } from "@/domain/enums/Platform";
import { CREDITS_CONFIG } from "@/config/credits";

// ── Test helpers ──────────────────────────────────────────────────────────────

function makeIsolatedDeps() {
  const requestStore = new Map();
  const historyStore = new Map();
  const walletStore = new Map();
  const txStore = new Map();

  const requestRepo = new MockClipRequestRepository(requestStore);
  const historyRepo = new MockRequestStatusHistoryRepository(historyStore);
  const walletRepo = new MockCreditWalletRepository(walletStore);
  const txRepo = new MockCreditTransactionRepository(txStore);

  return { requestRepo, historyRepo, walletRepo, txRepo };
}

const VALID_FORM_DATA = {
  title: "Test Clip Title",
  description: "A description that is definitely long enough to pass the validation.",
  targetAudience: "People who like testing software",
  targetPlatforms: [Platform.TikTok] as [Platform, ...Platform[]],
  preferredStyle: "Dynamic / Energetic",
  preferredLanguage: "English",
  durationSeconds: 15,
};

const COST = CREDITS_CONFIG.REQUEST_COST_CREDITS;

// ── Suite ─────────────────────────────────────────────────────────────────────

describe("MockClipRequestRepository", () => {
  it("creates a draft request with correct defaults", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({
      userId: "user-001",
      ...VALID_FORM_DATA,
    });

    expect(req.id).toBeTruthy();
    expect(req.status).toBe(RequestStatus.Draft);
    expect(req.creditsCost).toBe(COST);
    expect(req.submittedAt).toBeNull();
    expect(req.dueDateConfirmed).toBe(false);
    expect(req.creditConfirmed).toBe(false);
    expect(req.rightsConfirmed).toBe(false);
  });

  it("findByUserId returns only requests for the user", async () => {
    const { requestRepo } = makeIsolatedDeps();
    await requestRepo.create({ userId: "user-A", ...VALID_FORM_DATA });
    await requestRepo.create({ userId: "user-A", ...VALID_FORM_DATA });
    await requestRepo.create({ userId: "user-B", ...VALID_FORM_DATA });

    const userARequests = await requestRepo.findByUserId("user-A");
    expect(userARequests).toHaveLength(2);
    userARequests.forEach((r) => expect(r.userId).toBe("user-A"));
  });

  it("updateStatus transitions status and sets extra fields", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });

    const now = new Date();
    const submitted = await requestRepo.updateStatus(
      req.id,
      RequestStatus.Submitted,
      { submittedAt: now, queuePosition: 3 }
    );

    expect(submitted.status).toBe(RequestStatus.Submitted);
    expect(submitted.submittedAt?.getTime()).toBe(now.getTime());
    expect(submitted.queuePosition).toBe(3);
  });

  it("delete removes the request", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    await requestRepo.delete(req.id);
    const found = await requestRepo.findById(req.id);
    expect(found).toBeNull();
  });

  it("findByUserIdAndStatus filters by statuses", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const r1 = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    const r2 = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    await requestRepo.updateStatus(r2.id, RequestStatus.Submitted, {});

    const drafts = await requestRepo.findByUserIdAndStatus("user-001", [
      RequestStatus.Draft,
    ]);
    expect(drafts).toHaveLength(1);
    expect(drafts[0].id).toBe(r1.id);
  });
});

describe("ClipRequestService — draft creation and editing", () => {
  async function setup() {
    const { requestRepo, historyRepo, walletRepo, txRepo } = makeIsolatedDeps();

    // Give the user 30 credits
    const wallet = await walletRepo.create({
      userId: "user-001",
      balance: 30,
      initialCreditsGranted: true,
    });

    // We can't easily inject repos into the singleton service via its current
    // architecture (imports from @/repositories index). Instead we test the
    // mock repositories directly, which the service delegates to.
    return { requestRepo, historyRepo, wallet, walletRepo, txRepo };
  }

  it("creates a draft with status Draft", async () => {
    const { requestRepo } = await setup();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    expect(req.status).toBe(RequestStatus.Draft);
  });

  it("can update a draft's fields", async () => {
    const { requestRepo } = await setup();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    const updated = await requestRepo.update(req.id, {
      title: "Updated Title",
    });
    expect(updated.title).toBe("Updated Title");
  });

  it("does not allow updating a non-draft via service guard", async () => {
    const { requestRepo } = await setup();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    await requestRepo.updateStatus(req.id, RequestStatus.Submitted, {});

    // Simulate the service guard
    const found = await requestRepo.findById(req.id);
    expect(found?.status).toBe(RequestStatus.Submitted);
    // Service.updateDraft would throw "Only Draft requests can be edited."
    // We verify the status is indeed non-Draft, making the guard condition true.
    expect(found?.status !== RequestStatus.Draft).toBe(true);
  });
});

describe("ClipRequestService — insufficient credits guard", () => {
  it("CreditService.hasEnoughCredits returns false when balance is low", async () => {
    const walletRepo = new MockCreditWalletRepository(new Map());
    const txRepo = new MockCreditTransactionRepository(new Map());

    const wallet = await walletRepo.create({
      userId: "poor-user",
      balance: 5, // less than the request cost
      initialCreditsGranted: true,
    });

    // Simulate the check in ClipRequestService.submitRequest
    const balance = wallet.balance;
    const canAfford = balance >= COST;
    expect(canAfford).toBe(false);
  });

  it("CreditService.hasEnoughCredits returns true when balance is sufficient", async () => {
    const walletRepo = new MockCreditWalletRepository(new Map());

    const wallet = await walletRepo.create({
      userId: "rich-user",
      balance: COST + 50, // comfortably above the request cost
      initialCreditsGranted: true,
    });

    const canAfford = wallet.balance >= COST;
    expect(canAfford).toBe(true);
  });
});

describe("ClipRequestService — credit deduction", () => {
  it("deducts correct amount from wallet on submission", async () => {
    const walletRepo = new MockCreditWalletRepository(new Map());
    const txRepo = new MockCreditTransactionRepository(new Map());

    const wallet = await walletRepo.create({
      userId: "user-deduct",
      balance: 30,
      initialCreditsGranted: true,
    });

    // Simulate credit deduction
    const newBalance = wallet.balance - COST;
    const updated = await walletRepo.updateBalance(wallet.id, newBalance);
    expect(updated.balance).toBe(30 - COST);
  });

  it("cannot deduct below zero (service guard)", () => {
    const balance = 5;
    const cost = COST;
    // Service throws if balance < cost
    expect(() => {
      if (balance < cost) throw new Error("Insufficient credits.");
    }).toThrow("Insufficient credits.");
  });

  it("records a RequestCharge transaction on submission", async () => {
    const txRepo = new MockCreditTransactionRepository(new Map());
    const { TransactionType } = require("@/domain/enums/TransactionType");

    await txRepo.create({
      userId: "user-001",
      amount: -COST,
      type: TransactionType.RequestCharge,
      description: "Clip request: Test Clip",
      referenceId: "req-test-001",
    });

    const txns = await txRepo.findByUserId("user-001");
    expect(txns).toHaveLength(1);
    expect(txns[0].amount).toBe(-COST);
    expect(txns[0].type).toBe(TransactionType.RequestCharge);
  });
});

describe("ClipRequestService — draft deletion", () => {
  it("allows deleting a draft", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    await requestRepo.delete(req.id);
    const found = await requestRepo.findById(req.id);
    expect(found).toBeNull();
  });

  it("non-draft requests cannot be deleted (status guard)", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ userId: "user-001", ...VALID_FORM_DATA });
    await requestRepo.updateStatus(req.id, RequestStatus.UnderReview, {});

    const found = await requestRepo.findById(req.id);
    expect(found?.status !== RequestStatus.Draft).toBe(true);
    // The service guard would throw: "Only Draft requests can be deleted."
  });
});

describe("Trial / pay-to-download entitlement (repo-level)", () => {
  it("new requests default to download-locked and non-trial", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ ...VALID_FORM_DATA, userId: "u-1" });
    expect(req.downloadUnlocked ?? false).toBe(false);
    expect(req.isTrialRequest ?? false).toBe(false);
  });

  it("a paid (non-trial) submission is created download-unlocked", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ ...VALID_FORM_DATA, userId: "u-1" });
    const submitted = await requestRepo.updateStatus(req.id, RequestStatus.Submitted, {
      submittedAt: new Date(),
      isTrialRequest: false,
      downloadUnlocked: true,
    });
    expect(submitted.downloadUnlocked).toBe(true);
    expect(submitted.isTrialRequest).toBe(false);
  });

  it("a trial submission stays locked until unlocked", async () => {
    const { requestRepo } = makeIsolatedDeps();
    const req = await requestRepo.create({ ...VALID_FORM_DATA, userId: "u-1" });

    const trial = await requestRepo.updateStatus(req.id, RequestStatus.Submitted, {
      submittedAt: new Date(),
      isTrialRequest: true,
      downloadUnlocked: false,
    });
    expect(trial.isTrialRequest).toBe(true);
    expect(trial.downloadUnlocked).toBe(false);

    // unlockDownload() effect: flip the flag
    const unlocked = await requestRepo.updateStatus(req.id, trial.status, {
      downloadUnlocked: true,
    });
    expect(unlocked.downloadUnlocked).toBe(true);
  });

  it("isFirstRequest is true only until a request has been submitted", async () => {
    const { requestRepo } = makeIsolatedDeps();
    // Mirrors ClipRequestService.isFirstRequest: every request has null submittedAt.
    await requestRepo.create({ ...VALID_FORM_DATA, userId: "u-1" });
    let all = await requestRepo.findByUserId("u-1");
    expect(all.every((r) => r.submittedAt === null)).toBe(true);

    const [first] = all;
    await requestRepo.updateStatus(first.id, RequestStatus.Submitted, {
      submittedAt: new Date(),
    });
    all = await requestRepo.findByUserId("u-1");
    expect(all.every((r) => r.submittedAt === null)).toBe(false);
  });
});

describe("MockRequestStatusHistoryRepository", () => {
  it("records status history in chronological order", async () => {
    const { historyRepo } = makeIsolatedDeps();

    const t1 = new Date("2026-03-01T10:00:00Z");
    const t2 = new Date("2026-03-02T10:00:00Z");
    const t3 = new Date("2026-03-03T10:00:00Z");

    await historyRepo.create({ requestId: "req-001", status: RequestStatus.Draft, note: null, changedAt: t1 });
    await historyRepo.create({ requestId: "req-001", status: RequestStatus.Submitted, note: null, changedAt: t2 });
    await historyRepo.create({ requestId: "req-001", status: RequestStatus.UnderReview, note: null, changedAt: t3 });

    const history = await historyRepo.findByRequestId("req-001");
    expect(history).toHaveLength(3);
    expect(history[0].status).toBe(RequestStatus.Draft);
    expect(history[2].status).toBe(RequestStatus.UnderReview);
    // Sorted ascending by changedAt
    expect(history[0].changedAt.getTime()).toBeLessThan(history[2].changedAt.getTime());
  });

  it("only returns history for the given requestId", async () => {
    const { historyRepo } = makeIsolatedDeps();
    await historyRepo.create({ requestId: "req-A", status: RequestStatus.Draft, note: null, changedAt: new Date() });
    await historyRepo.create({ requestId: "req-B", status: RequestStatus.Draft, note: null, changedAt: new Date() });

    const history = await historyRepo.findByRequestId("req-A");
    expect(history).toHaveLength(1);
    expect(history[0].requestId).toBe("req-A");
  });
});
