import json,sys
d=json.load(open('dex.json'))
for cls in sys.argv[1:]:
    k='L'+cls.replace('.','/')+';'
    e=d.get(k)
    if not e: print("MISSING",cls); continue
    print("==",cls,"extends",e['super'],"impl",e['interfaces'],e['access'])
    for m in e['methods']:
        if 'synthetic' in m[2] or 'bridge' in m[2]: continue
        print("  ",m[0],m[1],m[2])
