import sys, json, glob
from androguard.core.dex import DEX
from loguru import logger
logger.remove()
out = {}
for path in sorted(glob.glob('/mnt/user-data/uploads/clipper_agent/android/app/build/intermediates/dex/debug/mergeExtDexDebug/*.dex')):
    d = DEX(open(path,'rb').read())
    for c in d.get_classes():
        name = c.get_name()
        entry = out.setdefault(name, {"super": c.get_superclassname(), "interfaces": list(c.get_interfaces() or []), "access": c.get_access_flags_string(), "methods": [], "fields": []})
        for m in c.get_methods():
            entry["methods"].append([m.get_name(), m.get_descriptor(), m.get_access_flags_string()])
        for f in c.get_fields():
            entry["fields"].append([f.get_name(), f.get_descriptor(), f.get_access_flags_string()])
json.dump(out, open('dex.json','w'))
print(len(out))
