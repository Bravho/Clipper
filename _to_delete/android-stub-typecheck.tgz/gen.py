import json, os, re, collections, shutil
d = json.load(open('dex.json'))
OUT = 'stubs'
shutil.rmtree(OUT, ignore_errors=True)
PREFIXES = ('Landroidx/media3/', 'Lcom/google/common/', 'Landroidx/annotation/')
KEYWORDS = set('abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null var record yield'.split())

def is_anon(name):
    inner = name[1:-1].split('/')[-1].split('$')[1:]
    return any(p == '' or p[0].isdigit() for p in inner) or '-' in name

classes = {k: v for k, v in d.items() if k.startswith(PREFIXES) and not is_anon(k)}
# hand-written stubs live in handstubs/ and override
referenced = set()

prim = {'V':'void','Z':'boolean','B':'byte','S':'short','C':'char','I':'int','J':'long','F':'float','D':'double'}
def jtype(desc):
    dims = 0
    while desc.startswith('['):
        dims += 1; desc = desc[1:]
    if desc in prim: t = prim[desc]
    else:
        referenced.add(desc)
        t = desc[1:-1].replace('/', '.').replace('$', '.')
    return t + '[]' * dims

def parse_desc(desc):
    m = re.match(r'\((.*)\)(.*)', desc)
    args, ret = m.group(1).strip(), m.group(2).strip()
    return ([a for a in args.split(' ') if a] if args else []), ret

def default_ret(t):
    if t == 'void': return ''
    if t == 'boolean': return 'return false;'
    if t in ('byte','short','char','int','long','float','double'): return 'return 0;'
    return 'return null;'

# group nested
tops = collections.defaultdict(list)
for name in classes:
    outer = name.split('$')[0] + (';' if '$' in name else '')
    tops[outer if '$' in name else name].append(name)

def simple(name):
    return name[1:-1].split('/')[-1].split('$')[-1]

GENERATED = set(classes)
def emit(name, indent, nested_static):
    e = classes[name]
    acc = e['access']
    is_iface = 'interface' in acc
    is_anno = 'annotation' in acc or 'Ljava/lang/annotation/Annotation;' in e['interfaces']
    kind = '@interface' if is_anno else ('interface' if is_iface else 'class')
    mods = 'public ' + ('static ' if nested_static else '') + ('abstract ' if ('abstract' in acc and not is_iface) else '')
    sup = e['super']
    ext = ''
    if not is_iface and sup and sup != 'Ljava/lang/Object;' and not sup.startswith('Ljava/lang/Enum'):
        ext = ' extends ' + jtype(sup)
    ifs = [jtype(i) for i in e['interfaces'] if not i.startswith('Ljava/lang/annotation')]
    impl = ''
    if ifs: impl = (' extends ' if is_iface else ' implements ') + ', '.join(ifs)
    lines = [f'{indent}{mods}{kind} {simple(name)}{ext}{impl} {{']
    ind = indent + '    '
    if is_anno:
        for mname, mdesc, macc in e['methods']:
            args, ret = parse_desc(mdesc)
            rt = jtype(ret)
            dflt = '{}' if rt.endswith('[]') else ('0' if rt in prim.values() else ('""' if rt=='java.lang.String' else None))
            if dflt is None: lines.append(f'{indent}    {rt} {mname}();')
            else: lines.append(f'{indent}    {rt} {mname}() default {dflt};')
        lines.append(indent + '}'); return lines
    if not is_iface:
        superCall = ''
        if sup in GENERATED: superCall = 'super((Void) null);'
        lines.append(f'{ind}protected {simple(name)}(Void __stub) {{ {superCall} }}')
    seen = set()
    for fname, fdesc, facc in e['fields']:
        if 'synthetic' in facc or 'private' in facc: continue
        st = 'static ' if 'static' in facc else ''
        t = jtype(fdesc)
        if is_iface:
            lines.append(f'{ind}public static final {t} {fname} = {"false" if t=="boolean" else ("0" if t in prim.values() else "null")};' if t != 'char' else f'{ind}public static final char {fname} = 0;')
        else:
            lines.append(f'{ind}public {st}{t} {fname};')
    for mname, mdesc, macc in e['methods']:
        if 'synthetic' in macc or 'bridge' in macc or 'private' in macc: continue
        if mname == '<clinit>': continue
        if not ('public' in macc or 'protected' in macc): continue
        args, ret = parse_desc(mdesc)
        ats = [jtype(a) for a in args]
        if 'varargs' in macc and ats and ats[-1].endswith('[]'):
            ats[-1] = ats[-1][:-2] + '...'
        params = ', '.join(f'{t} p{i}' for i, t in enumerate(ats))
        key = (mname, tuple(ats))
        if key in seen: continue
        seen.add(key)
        vis = 'public' if 'public' in macc else 'protected'
        if mname == '<init>':
            if is_iface: continue
            superCall = 'super((Void) null);' if sup in GENERATED else ''
            if ats == ['java.lang.Void']: continue
            lines.append(f'{ind}{vis} {simple(name)}({params}) {{ {superCall} }}')
            continue
        if mname in KEYWORDS: continue
        rt = jtype(ret)
        st = 'static ' if 'static' in macc else ''
        if is_iface:
            if 'abstract' in macc:
                lines.append(f'{ind}{rt} {mname}({params});')
            elif st:
                lines.append(f'{ind}static {rt} {mname}({params}) {{ {default_ret(rt)} }}')
            else:
                lines.append(f'{ind}default {rt} {mname}({params}) {{ {default_ret(rt)} }}')
        else:
            if 'abstract' in macc:
                lines.append(f'{ind}{vis} abstract {rt} {mname}({params});')
            else:
                lines.append(f'{ind}{vis} {st}{rt} {mname}({params}) {{ {default_ret(rt)} }}')
    # nested
    prefix = name[:-1] + '$'
    for other in sorted(classes):
        if other.startswith(prefix) and '$' not in other[len(prefix):]:
            lines += emit(other, ind, True)
    lines.append(indent + '}')
    return lines

count = 0
for name in classes:
    if '$' in name: continue
    pkg = '.'.join(name[1:-1].split('/')[:-1])
    path = os.path.join(OUT, *name[1:-1].split('/')) + '.java'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = emit(name, '', False)
    open(path, 'w').write(f'package {pkg};\n' + '\n'.join(body) + '\n')
    count += 1
# missing referenced types → empty stubs (unless hand-written)
iface_refs = set()
for v in classes.values():
    for i in v['interfaces']: iface_refs.add(i)
missing = sorted(r for r in referenced if r not in classes and not r.startswith(('Ljava/', 'Ljavax/annotation','Ljavax/net','Ljavax/crypto','Ljavax/xml','Ljavax/security')))
hand = set()
for root, _, files in os.walk('handstubs'):
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), 'handstubs')[:-5]
        hand.add('L' + rel + ';')
made = 0
bynest = collections.defaultdict(list)
for r in missing:
    top = r.split('$')[0] + (';' if '$' in r else '')
    bynest[top if '$' in r else r].append(r)
for top, members in bynest.items():
    topname = top if top.endswith(';') else top + ';'
    if topname in hand or is_anon(topname): continue
    pkg = '.'.join(topname[1:-1].split('/')[:-1])
    def body(n, indent, nested):
        kind = 'interface' if n in iface_refs else 'class'
        s = simple(n)
        lines = [f'{indent}public {"static " if nested else ""}{kind} {s} {{']
        if kind == 'class': lines.append(f'{indent}    public {s}(Void __stub) {{}}')
        for m in members:
            if m != n and m.startswith(n[:-1] + '$') and '$' not in m[len(n)-1+1:]:
                lines += body(m, indent + '    ', True)
        lines.append(indent + '}')
        return lines
    path = os.path.join(OUT, *topname[1:-1].split('/')) + '.java'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w').write(f'package {pkg};\n' + '\n'.join(body(topname, '', False)) + '\n')
    made += 1
print('generated', count, 'empty', made)
