package org.json;
public class JSONException extends Exception { public JSONException(String m) {} public JSONException(Throwable t) {} }
