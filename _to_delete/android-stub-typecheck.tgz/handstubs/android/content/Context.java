package android.content;
public abstract class Context { public Context() {} public abstract java.io.File getCacheDir(); public abstract java.io.File getFilesDir(); public abstract android.content.Context getApplicationContext(); }
