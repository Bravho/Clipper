package android.text;
public class TextPaint extends android.graphics.Paint { public TextPaint() {} public TextPaint(int flags) {} public TextPaint(android.graphics.Paint p) {} public void set(TextPaint p) {} }
