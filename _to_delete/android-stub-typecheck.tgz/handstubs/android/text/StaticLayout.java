package android.text;
public class StaticLayout extends Layout { public int getLineCount() { return 0; }
  public static final class Builder { public static Builder obtain(CharSequence s, int start, int end, TextPaint p, int width) { return null; }
    public Builder setAlignment(Layout.Alignment a) { return this; } public Builder setLineSpacing(float add, float mult) { return this; } public Builder setMaxLines(int m) { return this; } public Builder setEllipsize(TextUtils.TruncateAt t) { return this; } public Builder setIncludePad(boolean b) { return this; } public Builder setBreakStrategy(int s) { return this; } public StaticLayout build() { return null; } } }
