package android.text;
public class TextUtils { public enum TruncateAt { START, MIDDLE, END, MARQUEE } public static boolean isEmpty(CharSequence s) { return true; } }
