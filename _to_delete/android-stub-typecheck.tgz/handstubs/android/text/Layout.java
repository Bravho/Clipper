package android.text;
public abstract class Layout { public enum Alignment { ALIGN_NORMAL, ALIGN_OPPOSITE, ALIGN_CENTER }
  public final int getWidth() { return 0; } public int getHeight() { return 0; } public abstract int getLineCount(); public float getLineWidth(int l) { return 0; } public float getLineLeft(int l) { return 0; } public final TextPaint getPaint() { return null; } public void draw(android.graphics.Canvas c) {} public int getLineStart(int l) { return 0; } public int getLineEnd(int l) { return 0; } }
