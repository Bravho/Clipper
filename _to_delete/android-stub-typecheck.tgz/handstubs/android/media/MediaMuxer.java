package android.media;
public final class MediaMuxer { public MediaMuxer(String p, int f) throws java.io.IOException {} public int addTrack(MediaFormat f) { return 0; } public void start() {} public void stop() {} public void release() {} public void writeSampleData(int t, java.nio.ByteBuffer b, MediaCodec.BufferInfo i) {}
  public static final class OutputFormat { public static final int MUXER_OUTPUT_MPEG_4 = 0; } }
