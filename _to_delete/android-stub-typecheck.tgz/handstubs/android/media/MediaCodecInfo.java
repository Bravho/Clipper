package android.media;
public final class MediaCodecInfo { public String getName() { return null; } public boolean isEncoder() { return false; } public String[] getSupportedTypes() { return null; } public CodecCapabilities getCapabilitiesForType(String t) { return null; }
  public static final class CodecProfileLevel { public static final int AACObjectLC = 2; public int profile; public int level; }
  public static final class CodecCapabilities { public VideoCapabilities getVideoCapabilities() { return null; } }
  public static final class VideoCapabilities { public boolean isSizeSupported(int w, int h) { return false; } } }
