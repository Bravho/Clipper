package android.media;
public final class MediaCodecList { public static final int REGULAR_CODECS = 0; public static final int ALL_CODECS = 1; public MediaCodecList(int k) {} public final MediaCodecInfo[] getCodecInfos() { return null; } public final String findEncoderForFormat(MediaFormat f) { return null; } }
