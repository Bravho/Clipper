package android.media;
public final class MediaCrypto { }
