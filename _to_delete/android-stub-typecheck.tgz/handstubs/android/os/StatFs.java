package android.os;
public class StatFs { public StatFs(String p) {} public long getAvailableBytes() { return 0; } public long getTotalBytes() { return 0; } }
