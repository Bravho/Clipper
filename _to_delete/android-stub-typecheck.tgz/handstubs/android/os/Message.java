package android.os;
public final class Message { }
