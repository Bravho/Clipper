package android.os;
public final class Looper { public static Looper getMainLooper() { return null; } public static Looper myLooper() { return null; } }
