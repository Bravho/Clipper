package android.graphics;
public class Color { public static final int BLACK = 0xFF000000; public static final int WHITE = 0xFFFFFFFF; public static final int TRANSPARENT = 0;
  public static int argb(int a, int r, int g, int b) { return 0; } public static int rgb(int r, int g, int b) { return 0; }
  public static int red(int c) { return 0; } public static int green(int c) { return 0; } public static int blue(int c) { return 0; } public static int alpha(int c) { return 0; } public static int parseColor(String s) { return 0; } }
