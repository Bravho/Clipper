package android.graphics;
public final class Bitmap {
  public enum Config { ALPHA_8, RGB_565, ARGB_4444, ARGB_8888, RGBA_F16, HARDWARE }
  public enum CompressFormat { JPEG, PNG, WEBP }
  public static Bitmap createBitmap(int w, int h, Config c) { return null; }
  public static Bitmap createBitmap(Bitmap src) { return null; }
  public static Bitmap createScaledBitmap(Bitmap src, int w, int h, boolean filter) { return null; }
  public int getWidth() { return 0; } public int getHeight() { return 0; }
  public void eraseColor(int c) {} public boolean isRecycled() { return false; } public void recycle() {}
  public boolean compress(CompressFormat f, int q, java.io.OutputStream o) { return true; }
  public int getGenerationId() { return 0; }
  public Config getConfig() { return null; }
}
