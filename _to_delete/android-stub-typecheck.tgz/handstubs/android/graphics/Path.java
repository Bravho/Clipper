package android.graphics;
public class Path { public enum Direction { CW, CCW } public enum FillType { WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD }
  public Path() {} public Path(Path p) {} public void reset() {} public void moveTo(float x, float y) {} public void lineTo(float x, float y) {} public void rLineTo(float x, float y) {} public void rMoveTo(float x, float y) {}
  public void quadTo(float a, float b, float c, float d) {} public void rQuadTo(float a, float b, float c, float d) {} public void cubicTo(float a, float b, float c, float d, float e, float f) {} public void rCubicTo(float a, float b, float c, float d, float e, float f) {}
  public void arcTo(RectF o, float s, float sw) {} public void arcTo(RectF o, float s, float sw, boolean force) {} public void close() {}
  public void addRoundRect(RectF r, float rx, float ry, Direction d) {} public void addRect(RectF r, Direction d) {} public void addRect(float l, float t, float r, float b, Direction d) {} public void addCircle(float x, float y, float r, Direction d) {} public void addPath(Path p) {}
  public void setFillType(FillType f) {} public void transform(Matrix m) {} public void transform(Matrix m, Path dst) {} }
