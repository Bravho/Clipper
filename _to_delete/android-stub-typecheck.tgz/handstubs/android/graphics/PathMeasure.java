package android.graphics;
public class PathMeasure { public PathMeasure() {} public PathMeasure(Path p, boolean forceClosed) {} public void setPath(Path p, boolean c) {} public float getLength() { return 0; } public boolean getSegment(float s, float e, Path dst, boolean startWithMoveTo) { return true; } public boolean nextContour() { return false; } }
