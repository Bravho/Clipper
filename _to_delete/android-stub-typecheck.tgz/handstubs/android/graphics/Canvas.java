package android.graphics;
public class Canvas {
  public Canvas() {} public Canvas(Bitmap b) {}
  public int save() { return 0; } public void restore() {} public int saveLayerAlpha(RectF r, int a) { return 0; } public int saveLayerAlpha(float l, float t, float r, float b, int a) { return 0; } public int saveLayer(RectF r, Paint p) { return 0; }
  public void translate(float x, float y) {} public void scale(float x, float y) {} public void scale(float x, float y, float px, float py) {} public void rotate(float d) {} public void concat(Matrix m) {}
  public void drawRect(float l, float t, float r, float b, Paint p) {} public void drawRect(RectF r, Paint p) {}
  public void drawRoundRect(RectF r, float rx, float ry, Paint p) {} public void drawRoundRect(float l, float t, float r, float b, float rx, float ry, Paint p) {}
  public void drawCircle(float cx, float cy, float r, Paint p) {} public void drawLine(float a, float b, float c, float d, Paint p) {}
  public void drawPath(Path path, Paint p) {} public void drawBitmap(Bitmap b, float l, float t, Paint p) {} public void drawBitmap(Bitmap b, Rect s, RectF d, Paint p) {} public void drawBitmap(Bitmap b, Matrix m, Paint p) {}
  public void drawColor(int c) {} public void drawColor(int c, PorterDuff.Mode m) {} public void drawText(String t, float x, float y, Paint p) {}
  public boolean clipPath(Path p) { return true; } public boolean clipRect(RectF r) { return true; } public boolean clipOutPath(Path p) { return true; }
  public int getWidth() { return 0; } public int getHeight() { return 0; }
}
