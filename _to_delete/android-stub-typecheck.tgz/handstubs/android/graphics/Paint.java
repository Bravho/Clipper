package android.graphics;
public class Paint {
  public static final int ANTI_ALIAS_FLAG = 1; public static final int FILTER_BITMAP_FLAG = 2;
  public enum Style { FILL, STROKE, FILL_AND_STROKE } public enum Cap { BUTT, ROUND, SQUARE } public enum Join { MITER, ROUND, BEVEL } public enum Align { LEFT, CENTER, RIGHT }
  public Paint() {} public Paint(int flags) {} public Paint(Paint p) {}
  public void set(Paint p) {} public void setColor(int c) {} public int getColor() { return 0; } public void setAlpha(int a) {} public int getAlpha() { return 0; }
  public void setStyle(Style s) {} public Style getStyle() { return null; } public void setStrokeWidth(float w) {} public float getStrokeWidth() { return 0; }
  public void setStrokeCap(Cap c) {} public void setStrokeJoin(Join j) {} public void setAntiAlias(boolean a) {}
  public Shader setShader(Shader s) { return s; } public Xfermode setXfermode(Xfermode x) { return x; } public MaskFilter setMaskFilter(MaskFilter m) { return m; }
  public void setShadowLayer(float r, float dx, float dy, int c) {} public void clearShadowLayer() {}
  public Typeface setTypeface(Typeface t) { return t; } public Typeface getTypeface() { return null; } public void setTextSize(float s) {} public float getTextSize() { return 0; }
  public void setTextAlign(Align a) {} public float measureText(String s) { return 0; } public void setFakeBoldText(boolean b) {} public void setLetterSpacing(float s) {}
  public FontMetrics getFontMetrics() { return null; }
  public static class FontMetrics { public float top, ascent, descent, bottom, leading; }
}
