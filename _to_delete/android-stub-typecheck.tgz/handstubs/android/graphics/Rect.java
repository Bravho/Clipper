package android.graphics;
public final class Rect { public int left, top, right, bottom; public Rect() {} public Rect(int l, int t, int r, int b) {} public final int width() { return 0; } public final int height() { return 0; } }
