package android.graphics;
public class Shader { public Shader() {} public enum TileMode { CLAMP, REPEAT, MIRROR, DECAL } }
