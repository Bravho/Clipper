package android.graphics;
public class RadialGradient extends Shader { public RadialGradient(float cx, float cy, float r, int c0, int c1, Shader.TileMode t) {} }
