package android.util;
public class Pair<F, S> { public final F first = null; public final S second = null; public Pair(F f, S s) {} }
