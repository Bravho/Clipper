package android.util;
public class Base64 { public static final int DEFAULT = 0; public static final int NO_WRAP = 2; public static byte[] decode(String s, int f) { return null; } public static String encodeToString(byte[] b, int f) { return null; } }
