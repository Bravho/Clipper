package androidx.media3.common;
public interface VideoCompositorSettings {
  VideoCompositorSettings DEFAULT = null;
  androidx.media3.common.util.Size getOutputSize(java.util.List<androidx.media3.common.util.Size> inputSizes);
  OverlaySettings getOverlaySettings(int inputId, long presentationTimeUs);
}
