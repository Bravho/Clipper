#!/bin/bash
cd /home/claude/dex
rm -rf out2; mkdir out2
javac -nowarn -proc:none -implicit:none -encoding UTF-8 -sourcepath handstubs:stubs -d out2 "$@" 2>&1
