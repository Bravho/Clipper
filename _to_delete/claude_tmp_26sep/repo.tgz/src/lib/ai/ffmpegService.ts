import { execFile } from "child_process";
import { promisify } from "util";
import * as fs from "fs/promises";
import { existsSync } from "fs";
import * as path from "path";
import * as os from "os";
import { AI_CONFIG } from "@/config/aiTools";
import { spacesClient, spacesPublicUrl, spacesUpload } from "@/lib/spaces";
import { buildFinalClipKey } from "@/lib/spacesKeys";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import { ImageCoordinates } from "./geminiSubtitlesService";

const execFileAsync = promisify(execFile);

/**
 * Summarise a child_process/execFile rejection for logging. A process killed by
 * a signal (SIGKILL from the OOM killer, SIGTERM from a memory cap, etc.) dies
 * with EMPTY stderr, so the raw error is useless — `signal`/`code`/`killed` are
 * the only clues to why it died. Surfacing them turns "stderr: ''" into an
 * actionable diagnosis (e.g. "signal=SIGKILL" ⇒ out of memory).
 */
function describeExecError(err: unknown): string {
  const e = err as {
    message?: string;
    code?: number | string;
    signal?: string;
    killed?: boolean;
    stderr?: string;
  };
  const parts = [
    e?.signal ? `signal=${e.signal}` : null,
    e?.code != null ? `code=${e.code}` : null,
    e?.killed ? "killed=true" : null,
    e?.signal === "SIGKILL"
      ? "(process was killed — almost always out of memory; move this render to a machine with more RAM)"
      : null,
  ].filter(Boolean);
  const tail = (e?.stderr ?? "").trim().split("\n").slice(-4).join(" | ");
  return `${e?.message ?? String(err)}${parts.length ? " [" + parts.join(" ") + "]" : ""}${
    tail ? " stderr: " + tail : " stderr: <empty — see signal above>"
  }`;
}

export type VideoRatio = "9:16" | "16:9" | "1:1" | "4:5";

export function getRequiredRatiosForPlatforms(platforms: string[]): VideoRatio[] {
  const ratios = new Set<VideoRatio>();
  for (const p of platforms) {
    if (p === "tiktok" || p === "travy_app") {
      ratios.add("9:16");
    } else if (p === "youtube" || p === "facebook" || p === "cdn") {
      ratios.add("16:9");
    } else if (p === "instagram") {
      ratios.add("4:5");
    }
  }
  if (ratios.size === 0) {
    ratios.add("9:16");
  }
  return Array.from(ratios);
}


export interface ComposeVideoParams {
  videoStorageKey: string;
  audioStorageKey: string;
  scriptThai: string;
  scriptEnglish: string;
  hookThai: string;
  userId: string;
  requestId: string;
  musicTrackId?: string;
  coordinates?: ImageCoordinates;
  targetRatios?: VideoRatio[];
  assSubtitlesContent?: string;
  /**
   * When set, also render a dedicated export for the Travy App using this
   * (always English + Chinese) subtitle content, separate from the general
   * export's `assSubtitlesContent`. Result is returned under the "travy" key
   * in `exports`. The export uses `travyRatio` (the primary channel's ratio).
   */
  assSubtitlesContentTravy?: string;
  /**
   * Aspect ratio for the dedicated Travy App export — the primary channel's
   * ratio (so Travy matches the primary, not a forced 9:16). Defaults to "9:16".
   */
  travyRatio?: VideoRatio;
  /**
   * Phase 4 — Remotion-rendered transparent overlay clip (captions +
   * motion graphics) per ratio, keyed by `VideoRatio`. When present for a
   * given ratio, that ratio's export composites this overlay on top of the
   * cropped/scaled base video via FFmpeg's `overlay` filter, and the
   * ASS/SRT subtitle burn-in is SKIPPED for that ratio (the overlay's
   * `CaptionOverlay` already covers `subtitleLanguages`).
   */
  overlayStorageKeys?: Partial<Record<VideoRatio, string>>;
  /**
   * Set when `overlayStorageKeys["9:16"]`'s captions were rendered with
   * exactly English + Chinese (matching the Travy App's fixed subtitle
   * requirement). If true, the Travy export reuses that 9:16 overlay
   * instead of burning `assSubtitlesContentTravy` via ASS.
   */
  overlayCoversTravySubtitles?: boolean;
}

export interface ComposeVideoResult {
  exports: Record<string, { storageKey: string; storageUrl: string }>;
}

/**
 * Run an S3/Spaces operation with bounded exponential-backoff retries and a
 * DETAILED final error. DO Spaces intermittently throttles or resets concurrent
 * requests (the compose step uploads every ratio in parallel), and the AWS SDK
 * surfaces these as an anonymous "UnknownError" whose `String(err)` hides the
 * HTTP status and cause. Retrying absorbs the transient case; on genuine failure
 * we throw an error naming the operation, key, HTTP status, and SDK metadata so
 * the worker log actually identifies what went wrong.
 */
async function spacesWithRetry<T>(
  label: string,
  fn: () => Promise<T>,
  attempts = 4
): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const e = err as { name?: string; $metadata?: { httpStatusCode?: number } };
      console.error(
        `[spaces] ${label} attempt ${i + 1}/${attempts} failed: ${e?.name ?? String(err)} (http ${e?.$metadata?.httpStatusCode ?? "?"})`
      );
      if (i < attempts - 1) await new Promise((r) => setTimeout(r, 500 * 2 ** i));
    }
  }
  const e = lastErr as { name?: string; message?: string; $metadata?: unknown };
  throw new Error(
    `Spaces ${label} failed after ${attempts} attempts: ${e?.name ?? ""} ${e?.message ?? String(lastErr)} metadata=${JSON.stringify(e?.$metadata ?? {})}`
  );
}

async function downloadFromSpaces(storageKey: string, destPath: string): Promise<void> {
  const bucket = process.env.DO_SPACES_BUCKET!;
  await spacesWithRetry(`download ${storageKey}`, async () => {
    const res = await spacesClient.send(new GetObjectCommand({ Bucket: bucket, Key: storageKey }));
    const chunks: Uint8Array[] = [];
    for await (const chunk of res.Body as AsyncIterable<Uint8Array>) {
      chunks.push(chunk);
    }
    await fs.writeFile(destPath, Buffer.concat(chunks));
  });
}

async function uploadToSpaces(
  filePath: string,
  storageKey: string
): Promise<void> {
  const buffer = await fs.readFile(filePath);
  // Multipart: a single PutObject of a large export times out (~50s window) and
  // DO Spaces returns an opaque 400. spacesUpload splits it into small parts.
  await spacesUpload({ key: storageKey, body: buffer, contentType: "video/mp4" });
}

/** Fallback compose duration when the voice track can't be probed. */
export const DEFAULT_COMPOSE_DURATION_SECONDS = 15;
/** Background-music bed level (pre-ducking), 0..1. */
export const MUSIC_BED_VOLUME = 0.3;
/**
 * Sidechain compression ratio for ducking the music under the voiceover.
 * Higher = music drops further while speech plays. Affects ONLY the speaking
 * period — the music-only intro, sentence gaps and ending stay at
 * {@link MUSIC_BED_VOLUME}. Lower this to make the bed louder under speech.
 */
export const MUSIC_DUCK_RATIO = 2.5;
/**
 * Short music-only lead-in before the voiceover starts, so the clip opens with
 * the background track for a beat before narration. The voice is delayed by
 * this amount and the export duration is extended to match (no voice clipped).
 */
export const MUSIC_LEAD_IN_SECONDS = 0.6;

/**
 * Clamp a probed audio/video duration to a sane positive value, falling back
 * to {@link DEFAULT_COMPOSE_DURATION_SECONDS} when the probe failed (<= 0 / NaN).
 */
export function resolveComposeDuration(probedSeconds: number | undefined): number {
  return probedSeconds !== undefined && Number.isFinite(probedSeconds) && probedSeconds > 0
    ? probedSeconds
    : DEFAULT_COMPOSE_DURATION_SECONDS;
}

/**
 * Build the `filter_complex` audio chain that mixes a looping background-music
 * bed under the voiceover with sidechain ducking, so the music drops under
 * speech and recovers in the gaps.
 *
 * `totalDurationSeconds` is the WHOLE CLIP length (the full base-video length —
 * voice + music intro + trailing ending), NOT just the voice length. The music
 * is looped then trimmed to cover the entire clip, so the background track keeps
 * playing under the music-only intro AND the ending after narration stops — the
 * voice itself can be (and usually is) shorter than the clip. Returns the filter
 * strings to be joined into `filter_complex`; the final mix is exposed as `[aout]`.
 */
export function buildMusicMixFilters(params: {
  voiceInputIdx?: number;
  musicInputIdx: number;
  totalDurationSeconds: number;
  musicVolume?: number;
  leadInSeconds?: number;
}): string[] {
  const voiceIdx = params.voiceInputIdx ?? 1;
  const leadIn = params.leadInSeconds ?? MUSIC_LEAD_IN_SECONDS;
  // The music covers the ENTIRE clip (intro + narration + trailing ending), so
  // it is looped then trimmed to the full clip length.
  const totalDur = resolveComposeDuration(params.totalDurationSeconds).toFixed(3);
  const leadMs = Math.round(leadIn * 1000);
  const vol = params.musicVolume ?? MUSIC_BED_VOLUME;
  return [
    // Delay the (loudness-normalised) voice by the lead-in so the clip opens on
    // music alone; the delayed copy also keys the sidechain, so ducking only
    // kicks in once the voice actually starts. Pad the voice with trailing
    // silence to the full clip length BEFORE the split so (a) the sidechain key
    // runs the whole clip — otherwise `sidechaincompress` ends with the voice and
    // the music (and thus the mix) would be truncated to the narration, cutting
    // off the music-only ending — and (b) once the voice stops, its silent tail
    // lets the music recover to full level under the ending.
    `[${voiceIdx}:a]loudnorm=I=-16:LRA=11:TP=-1.5,adelay=${leadMs}:all=1,apad=whole_dur=${totalDur},asplit=2[sc][voice]`,
    `[${params.musicInputIdx}:a]aloop=-1:size=2147483647,atrim=0:${totalDur},asetpts=PTS-STARTPTS,volume=${vol}[music]`,
    // Gentle, quick-recover ducking (Phase 6): a fast attack drops the music
    // promptly when speech starts and a fast release (300ms) lets it return
    // between sentences. The ratio sets how FAR the bed drops under speech —
    // ratio=2.5 (was 4, before that 8) keeps the music clearly present while
    // narration plays, instead of nearly disappearing. Only the ducked (speech)
    // level changes; the music-only intro/gaps/ending stay at MUSIC_BED_VOLUME.
    `[music][sc]sidechaincompress=threshold=0.03:ratio=${MUSIC_DUCK_RATIO}:attack=20:release=300[music_ducked]`,
    `[voice][music_ducked]amix=inputs=2:normalize=0,alimiter=limit=0.95:level=false[aout]`,
  ];
}

/** Canonical output pixel dimensions per export ratio. */
const RATIO_OUTPUT_DIMENSIONS: Record<VideoRatio, { w: number; h: number }> = {
  "9:16": { w: 1080, h: 1920 },
  "16:9": { w: 1920, h: 1080 },
  "1:1": { w: 1080, h: 1080 },
  "4:5": { w: 1080, h: 1350 },
};

/**
 * Build a resolution-INDEPENDENT crop+scale filter for one export ratio.
 *
 * The montage base video is rendered directly at the PRIMARY channel's aspect
 * ratio (e.g. 1080x1920 for a 9:16 primary) — it is NOT a 1920x1080 widescreen
 * master. The old implementation hardcoded a 1920x1080 source, so it re-cropped
 * an already-correctly-framed portrait base as if it were landscape, producing
 * the wrong proportions / a visibly mis-cropped merged preview.
 *
 * Instead we express the crop against the ACTUAL input dimensions (`iw`/`ih`):
 * center-crop the largest region matching the target aspect ratio, then scale to
 * the ratio's canonical size. When the input already matches the target ratio
 * (the common case — primary ratio === base ratio) the crop is the full frame
 * (a no-op), so the merged preview keeps the exact framing the requester saw in
 * the base video. Only genuinely different target ratios are cropped.
 *
 * `coords` (optional, 0..1000 normalized product box) steers the horizontal crop
 * position toward the subject; without it the crop is centered.
 */
function getSmartCropFilter(ratio: VideoRatio, coords?: ImageCoordinates): string {
  const { w: OW, h: OH } = RATIO_OUTPUT_DIMENSIONS[ratio];

  // Largest sub-rectangle of the input matching the target aspect ratio.
  const cropW = `min(iw,ih*${OW}/${OH})`;
  const cropH = `min(ih,iw*${OH}/${OW})`;

  // Horizontal position: centered, or steered toward the detected subject.
  let xExpr = "(iw-ow)/2";
  if (coords && coords.xmin != null && coords.xmax != null) {
    const cx = ((coords.xmin + coords.xmax) / 2) / 1000; // 0..1
    xExpr = `max(0,min(iw-ow,iw*${cx.toFixed(4)}-ow/2))`;
  }

  // Single-quote each expression so the commas inside min()/max() are treated as
  // literals by FFmpeg's filtergraph parser (not option separators).
  return (
    `crop=w='${cropW}':h='${cropH}':x='${xExpr}':y='(ih-oh)/2',` +
    `scale=${OW}:${OH},setsar=1`
  );
}

/**
 * Run FFmpeg to compose video + audio (+ optional background music with
 * ducking, + optional Phase 4 Remotion overlay clip) and export to one
 * ratio.
 *
 * When `overlayPath` is provided, the ASS/SRT subtitle burn-in (`subsPath`)
 * is skipped — the Remotion overlay's `CaptionOverlay` already covers
 * `subtitleLanguages` for that ratio (see `ComposeVideoParams.overlayStorageKeys`).
 */
async function composeSingleRatio(params: {
  videoPath: string;
  audioPath: string;
  subsPath?: string;
  isAss?: boolean;
  ratio: VideoRatio;
  outputPath: string;
  musicPath?: string;
  coordinates?: ImageCoordinates;
  overlayPath?: string;
  /** Measured length of the voiceover track (seconds). */
  voiceDurationSeconds?: number;
  /** Measured length of the base montage video (seconds). */
  videoDurationSeconds?: number;
}): Promise<void> {
  const { videoPath, audioPath, subsPath, isAss, ratio, outputPath, musicPath, coordinates, overlayPath } = params;
  const ffmpeg = AI_CONFIG.ffmpeg.path;
  const voiceDuration = resolveComposeDuration(params.voiceDurationSeconds);
  const videoDuration = resolveComposeDuration(params.videoDurationSeconds);

  const cropAndScaleFilter = getSmartCropFilter(ratio, coordinates);

  // Format subtitle filter parameter (ASS formatting uses font style defined
  // inside the .ass file). Skipped entirely when a Remotion overlay (which
  // already burns captions) is supplied.
  const subtitleFilter =
    !overlayPath && subsPath
      ? "," +
        (isAss
          ? `subtitles=${subsPath.replace(/\\/g, "/")}`
          : `subtitles=${subsPath.replace(/\\/g, "/")}:force_style='Fontsize=18,PrimaryColour=&HFFFFFF,OutlineColour=&H000000,Outline=2,Alignment=2'`)
      : "";

  const args: string[] = ["-y", "-i", videoPath, "-i", audioPath];
  let nextInput = 2;
  let overlayInputIdx = -1;
  let musicInputIdx = -1;

  if (overlayPath) {
    args.push("-i", overlayPath);
    overlayInputIdx = nextInput++;
  }
  if (musicPath) {
    args.push("-i", musicPath);
    musicInputIdx = nextInput++;
  }

  // With music we add a short music-only lead-in (the voice is delayed by it).
  const hasMusic = musicInputIdx >= 0;
  const leadIn = hasMusic ? MUSIC_LEAD_IN_SECONDS : 0;

  // The merged clip runs for the FULL base-video length (the montage is sized to
  // cover the voiceover plus its intro + trailing ending). The voiceover — which
  // is normally SHORTER than the video — plays over it (delayed by the lead-in)
  // and the background music fills the whole clip, so the opening and the ending
  // keep their music-only beats and narration is never clipped. We still guard
  // against a base that is somehow shorter than the delayed voice by taking the
  // max, so the voice tail is never cut.
  const outputDuration = Math.max(videoDuration, voiceDuration + leadIn);

  const filters: string[] = [];
  // How much longer the audio (voice + music intro) runs than the picture. When
  // the montage can't fully cover the voiceover, this leftover period has no
  // picture to show.
  const pictureDeficit = Math.max(0, outputDuration - videoDuration);
  // Previously the base's final frame was FROZEN (cloned) to fill the leftover,
  // which looked like the video had stalled. Instead: pad the genuine
  // picture-less leftover with BLACK frames (audio keeps playing over black), and
  // only clone a tiny 0.5s to absorb frame-rounding when the picture already
  // covers the voice. `-t` trims any surplus to exactly `outputDuration`.
  const videoTail =
    pictureDeficit > 0.05
      ? `,tpad=stop_mode=add:color=black:stop_duration=${(pictureDeficit + 0.5).toFixed(3)}`
      : `,tpad=stop_mode=clone:stop_duration=0.5`;
  // Burn subtitles AFTER the black tail is appended so captions timed into the
  // picture-less leftover render over the black too (the voiceover keeps playing
  // there). Mid-montage black frames are already part of [0:v], so they get
  // captions regardless of order.
  filters.push(`[0:v]${cropAndScaleFilter}${videoTail}${subtitleFilter}[base]`);
  let videoOut = "[base]";

  if (overlayInputIdx >= 0) {
    filters.push(`[${overlayInputIdx}:v]format=yuva420p[ovl]`);
    filters.push(`[base][ovl]overlay=0:0:format=auto,format=yuv420p[vout]`);
    videoOut = "[vout]";
  }

  let audioOut = "1:a";
  if (musicInputIdx >= 0) {
    filters.push(
      ...buildMusicMixFilters({
        musicInputIdx,
        totalDurationSeconds: outputDuration,
        leadInSeconds: leadIn,
      })
    );
    audioOut = "[aout]";
  } else {
    // No music: pad the (shorter) voiceover with trailing silence so it spans the
    // whole clip — otherwise the video would run to `outputDuration` with the
    // audio stream ending early.
    filters.push(`[1:a]apad=whole_dur=${outputDuration.toFixed(3)}[aout]`);
    audioOut = "[aout]";
  }

  args.push("-filter_complex", filters.join(";"));
  args.push("-map", videoOut);
  args.push("-map", audioOut);
  args.push(
    "-c:v", "libx264",
    "-c:a", "aac",
    "-ar", "48000",
    // Run for the full base-video length (NOT the voice length). No `-shortest`:
    // the video + padded/looped audio are both sized to `outputDuration`, and
    // `-t` bounds the (otherwise frozen/looped) tails to exactly that length.
    "-t", outputDuration.toFixed(3),
    outputPath
  );

  const startedAt = Date.now();
  console.log(
    `[compose:${ratio}] ffmpeg start (duration=${outputDuration.toFixed(2)}s, music=${hasMusic}, overlay=${overlayInputIdx >= 0}, subs=${!!subtitleFilter})`
  );
  try {
    await execFileAsync(ffmpeg, args);
  } catch (err) {
    const detail = describeExecError(err);
    console.error(`[compose:${ratio}] ffmpeg FAILED after ${((Date.now() - startedAt) / 1000).toFixed(1)}s:`, detail);
    throw new Error(`compose ${ratio} ffmpeg failed: ${detail}`);
  }
  const { size } = await fs.stat(outputPath).catch(() => ({ size: -1 }));
  console.log(
    `[compose:${ratio}] ffmpeg done in ${((Date.now() - startedAt) / 1000).toFixed(1)}s → ${size} bytes`
  );
}

/**
 * Composites a Remotion alpha-channel overlay clip onto a base video,
 * cropped/scaled to `ratio`, with no audio re-encoding concerns — used to
 * build the single-ratio "representative preview" shown at
 * `AwaitingAnimationApproval` (`animatedVideoAssetId`). The full per-ratio
 * final exports go through `composeSingleRatio` (with `overlayPath`)
 * instead, which also handles audio/music.
 */
export async function renderOverlayPreview(params: {
  videoStorageKey: string;
  overlayStorageKey: string;
  ratio: VideoRatio;
  outputStorageKey: string;
  coordinates?: ImageCoordinates;
}): Promise<void> {
  const { videoStorageKey, overlayStorageKey, ratio, outputStorageKey, coordinates } = params;
  const ffmpeg = AI_CONFIG.ffmpeg.path;

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-overlay-preview-"));
  try {
    const videoPath = path.join(tmpDir, "base.mp4");
    const overlayPath = path.join(tmpDir, "overlay.webm");
    await Promise.all([
      downloadFromSpaces(videoStorageKey, videoPath),
      downloadFromSpaces(overlayStorageKey, overlayPath),
    ]);

    const outPath = path.join(tmpDir, "preview.mp4");
    const cropAndScaleFilter = getSmartCropFilter(ratio, coordinates);

    await execFileAsync(ffmpeg, [
      "-y",
      "-i", videoPath,
      "-i", overlayPath,
      "-filter_complex",
      `[0:v]${cropAndScaleFilter}[base];[1:v]format=yuva420p[ovl];[base][ovl]overlay=0:0:format=auto,format=yuv420p[vout]`,
      "-map", "[vout]",
      "-map", "0:a?",
      "-c:v", "libx264",
      "-c:a", "aac",
      "-t", "15",
      outPath,
    ]);

    await uploadToSpaces(outPath, outputStorageKey);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Concatenate multiple video clips (in order) into a single video file using
 * ffmpeg's concat demuxer. Downloads each input from DO Spaces, concatenates
 * with `-c copy` (fast, no re-encode — assumes all clips share the same
 * codec/resolution, which holds for same-model Veo outputs), and uploads
 * the result to `outputStorageKey`.
 *
 * If `-c copy` fails (e.g. mismatched codecs/timestamps across clips), falls
 * back to re-encoding with libx264/aac.
 *
 * If only one storage key is provided, the clip is simply re-uploaded under
 * `outputStorageKey` (no ffmpeg concat needed) so callers can treat the
 * single-scene case uniformly.
 */
export async function concatVideos(
  inputStorageKeys: string[],
  outputStorageKey: string
): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  if (inputStorageKeys.length === 0) {
    throw new Error("concatVideos: at least one input storage key is required");
  }

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-concat-"));
  try {
    if (inputStorageKeys.length === 1) {
      const single = path.join(tmpDir, "single.mp4");
      await downloadFromSpaces(inputStorageKeys[0], single);
      await uploadToSpaces(single, outputStorageKey);
      const { size } = await fs.stat(single);
      return {
        storageKey: outputStorageKey,
        storageUrl: spacesPublicUrl(outputStorageKey),
        fileSizeBytes: size,
      };
    }

    const ffmpeg = AI_CONFIG.ffmpeg.path;
    const inputPaths: string[] = [];
    for (let i = 0; i < inputStorageKeys.length; i++) {
      const dest = path.join(tmpDir, `in-${i}.mp4`);
      await downloadFromSpaces(inputStorageKeys[i], dest);
      inputPaths.push(dest);
    }

    const listFile = path.join(tmpDir, "concat.txt");
    const listContent = inputPaths
      .map((p) => `file '${p.replace(/\\/g, "/").replace(/'/g, "'\\''")}'`)
      .join("\n");
    await fs.writeFile(listFile, listContent, "utf-8");

    const outPath = path.join(tmpDir, "concat-out.mp4");

    try {
      await execFileAsync(ffmpeg, [
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", listFile,
        "-c", "copy",
        outPath,
      ]);
    } catch (err) {
      // Fall back to re-encode if stream copy fails (mismatched codecs/params).
      console.error("[ffmpeg] concat -c copy failed, falling back to re-encode:", describeExecError(err));
      try {
        await execFileAsync(ffmpeg, [
          "-y",
          "-f", "concat",
          "-safe", "0",
          "-i", listFile,
          "-c:v", "libx264",
          "-c:a", "aac",
          outPath,
        ]);
      } catch (err2) {
        const detail = describeExecError(err2);
        console.error("[ffmpeg] concat re-encode failed:", detail);
        throw new Error(`ffmpeg concat re-encode failed: ${detail}`);
      }
    }

    await uploadToSpaces(outPath, outputStorageKey);
    const { size } = await fs.stat(outPath);
    return {
      storageKey: outputStorageKey,
      storageUrl: spacesPublicUrl(outputStorageKey),
      fileSizeBytes: size,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Probe a media source's duration in seconds via ffprobe. Accepts a local file
 * path OR a remote URL (ffprobe reads the container header only, so this is cheap
 * even for a large clip on DO Spaces). Returns 0 on any failure so callers can
 * fall back gracefully. Exported for the montage render, which pins every clip's
 * footage window so the renderer can black out (instead of freeze) once a clip
 * runs out of footage.
 */
export async function probeMediaDurationSeconds(input: string): Promise<number> {
  return probeDurationSeconds(input);
}

/**
 * What a rendered file actually IS, as ffprobe sees it.
 *
 * The device render path needs this: an export that a phone uploads has to be
 * checked before it becomes a `FinalClip`, and the checks that matter are
 * exactly the ones a human would make by opening the file — is there a picture,
 * is there sound, is it the right shape, is it about the right length. The
 * single most valuable field is `hasAudio`: a silent export is the specific
 * failure the draft phone renderer kept producing, and it is invisible in a
 * thumbnail.
 *
 * Accepts a local path or a remote URL (ffprobe reads the header only). Never
 * throws — a probe that fails returns zeros/nulls so the caller decides what an
 * unreadable file means, rather than a 500 escaping from an inspection.
 */
export interface MediaSummary {
  durationSeconds: number;
  hasVideo: boolean;
  hasAudio: boolean;
  videoCodec: string | null;
  audioCodec: string | null;
  /** The frame size as STORED (coded). */
  width: number | null;
  height: number | null;
  /**
   * The rotation the file asks players to apply (0, 90, 180 or 270). Phone
   * encoders often store a portrait video as landscape frames plus a 90°
   * rotation tag — every player shows it upright, but the stored size is
   * sideways.
   */
  rotation: number;
  /** The frame size as SHOWN, i.e. after that rotation. */
  displayWidth: number | null;
  displayHeight: number | null;
}

/** Normalise ffprobe's rotation (a `rotate` tag, or display-matrix side data) to 0/90/180/270. */
export function normaliseRotation(raw: unknown): number {
  const value = typeof raw === "string" ? parseFloat(raw) : typeof raw === "number" ? raw : NaN;
  if (!Number.isFinite(value)) return 0;
  const quarter = Math.round(value / 90) * 90;
  return ((quarter % 360) + 360) % 360;
}

export async function probeMediaSummary(input: string): Promise<MediaSummary> {
  const empty: MediaSummary = {
    durationSeconds: 0,
    hasVideo: false,
    hasAudio: false,
    videoCodec: null,
    audioCodec: null,
    width: null,
    height: null,
    rotation: 0,
    displayWidth: null,
    displayHeight: null,
  };

  const ffmpeg = AI_CONFIG.ffmpeg.path ?? "ffmpeg";
  const ffprobe = ffmpeg.replace(/ffmpeg(\.exe)?$/i, (m) =>
    m.toLowerCase().endsWith(".exe") ? "ffprobe.exe" : "ffprobe"
  );

  try {
    const { stdout } = await execFileAsync(ffprobe, [
      "-v", "error",
      "-show_entries",
      "format=duration:stream=codec_type,codec_name,width,height:stream_tags=rotate:stream_side_data=rotation",
      "-of", "json",
      input,
    ]);
    const parsed = JSON.parse(stdout) as {
      format?: { duration?: string };
      streams?: {
        codec_type?: string;
        codec_name?: string;
        width?: number;
        height?: number;
        tags?: { rotate?: string };
        side_data_list?: { rotation?: number | string }[];
      }[];
    };

    const duration = parseFloat(parsed.format?.duration ?? "");
    const video = (parsed.streams ?? []).find((s) => s.codec_type === "video");
    const audio = (parsed.streams ?? []).find((s) => s.codec_type === "audio");

    const sideRotation = video?.side_data_list?.find((entry) => entry.rotation != null)?.rotation;
    const rotation = normaliseRotation(sideRotation ?? video?.tags?.rotate);
    const width = video?.width ?? null;
    const height = video?.height ?? null;
    const sideways = rotation === 90 || rotation === 270;

    return {
      durationSeconds: Number.isFinite(duration) && duration > 0 ? duration : 0,
      hasVideo: Boolean(video),
      hasAudio: Boolean(audio),
      videoCodec: video?.codec_name ?? null,
      audioCodec: audio?.codec_name ?? null,
      width,
      height,
      rotation,
      displayWidth: sideways ? height : width,
      displayHeight: sideways ? width : height,
    };
  } catch (err) {
    console.error("[probe] could not inspect media:", describeExecError(err));
    return empty;
  }
}

/** Probe a local media file's duration (seconds) via ffprobe. 0 on failure. */
async function probeDurationSeconds(filePath: string): Promise<number> {
  const ffmpeg = AI_CONFIG.ffmpeg.path ?? "ffmpeg";
  const ffprobe = ffmpeg.replace(/ffmpeg(\.exe)?$/i, (m) =>
    m.toLowerCase().endsWith(".exe") ? "ffprobe.exe" : "ffprobe"
  );
  try {
    const { stdout } = await execFileAsync(ffprobe, [
      "-v", "error",
      "-show_entries", "format=duration",
      "-of", "default=noprint_wrappers=1:nokey=1",
      filePath,
    ]);
    const d = parseFloat(stdout.trim());
    return Number.isFinite(d) && d > 0 ? d : 0;
  } catch {
    return 0;
  }
}

/**
 * Phase 7 — composite a transparent subtitle/motion-graphic overlay ON TOP of an
 * already-finished master clip (the merged voice+music export for one ratio),
 * WITHOUT re-cropping or re-mixing. The master's video is the base layer and its
 * audio is stream-copied through untouched (`-c:a copy`), so what ships is the
 * exact master the requester approved, plus the captions/graphics on top.
 *
 * The overlay (`overlayStorageKey`) is the alpha-channel `.webm` produced by
 * `remotionService.renderOverlay` at the SAME ratio's dimensions; `scale2ref`
 * defensively matches it to the master frame in case of any off-by-pixel drift.
 *
 * Returns the stored captioned clip (a NEW key — the master is left intact).
 */
export async function overlayOnMaster(params: {
  masterStorageKey: string;
  overlayStorageKey: string;
  outputStorageKey: string;
}): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  const { masterStorageKey, overlayStorageKey, outputStorageKey } = params;
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-overlay-"));
  try {
    const ffmpeg = AI_CONFIG.ffmpeg.path;
    const masterPath = path.join(tmpDir, "master.mp4");
    const overlayPath = path.join(tmpDir, "overlay.webm");
    const outPath = path.join(tmpDir, "out.mp4");

    await Promise.all([
      downloadFromSpaces(masterStorageKey, masterPath),
      downloadFromSpaces(overlayStorageKey, overlayPath),
    ]);

    await execFileAsync(ffmpeg, [
      "-y",
      "-i", masterPath,
      "-i", overlayPath,
      // Alpha-composite the transparent overlay onto the master. The overlay is
      // rendered at the SAME ratio dimensions as the master, so no scaling is
      // needed — we drop the old `scale2ref` hop (it was stripping the alpha
      // plane, which made the overlay opaque and blacked out the video). We
      // force the overlay into a packed-alpha format first so `overlay` honors
      // its transparency.
      "-filter_complex",
      "[1:v]format=yuva420p[ov];[0:v][ov]overlay=format=auto:shortest=1[v]",
      "-map", "[v]",
      // Copy the master's audio (voice + ducked music) through untouched.
      "-map", "0:a?",
      "-c:v", "libx264",
      "-pix_fmt", "yuv420p",
      "-preset", "veryfast",
      "-c:a", "copy",
      "-movflags", "+faststart",
      outPath,
    ]);

    await uploadToSpaces(outPath, outputStorageKey);
    const { size } = await fs.stat(outPath);
    return {
      storageKey: outputStorageKey,
      storageUrl: spacesPublicUrl(outputStorageKey),
      fileSizeBytes: size,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/** Default watermark text stamped across locked-download previews. */
export const WATERMARK_TEXT = "RClipper";

/**
 * Build the `-vf` value for a tiled, diagonally-staggered semi-transparent
 * watermark that covers the WHOLE frame, so it can't be cleanly cropped out of
 * a ripped preview. FFmpeg's `drawtext` can't rotate or auto-tile, so we stamp a
 * grid of `drawtext` instances whose positions are expressed against the input
 * dimensions (`w`/`h`) — making the result resolution-independent across every
 * export ratio. Odd rows are shifted horizontally to give the grid a diagonal,
 * repeated-watermark feel.
 */
export function buildTiledWatermarkFilter(
  text = WATERMARK_TEXT,
  fontFilePath: string = AI_CONFIG.ffmpeg.fontFile
): string {
  // Escape the (possibly Windows) font path exactly as animationService does:
  // backslashes → forward slashes, and ':' escaped for the filtergraph parser.
  // NOTE: `[` `]` `,` `'` `;` are STRUCTURAL in a filtergraph and cannot be
  // escaped reliably inside a single-quoted option value — a font path
  // containing them (e.g. a variable font `NotoSansThai[wdth,wght].ttf`) breaks
  // the whole `-vf` parse. Callers should pass a path free of those characters;
  // `stageFiltergraphSafeFont` copies such fonts to a plain name first.
  const fontFile = fontFilePath.replace(/\\/g, "/").replace(/:/g, "\\:");
  // Escape characters special to drawtext's text option.
  const safeText = text.replace(/\\/g, "\\\\").replace(/:/g, "\\:").replace(/'/g, "’");

  const rows = 6;
  const cols = 3;
  const stamps: string[] = [];
  for (let r = 0; r < rows; r++) {
    // Diagonal stagger: each row shifts right by a fraction of a column width,
    // wrapping within the frame via mod so stamps stay on-screen.
    const rowShift = ((r % cols) / cols) * (1 / cols); // 0 .. <1/cols
    for (let c = 0; c < cols; c++) {
      // Keep the horizontal fraction on-screen (< 1) directly, so the x
      // expression needs no mod()/comma — commas inside a single-quoted filter
      // option value are otherwise mis-parsed. Reserve ~15% right margin so the
      // stamp's own width never spills past the frame edge.
      const xFrac = Math.min(0.85, c / cols + rowShift + 0.04);
      const yFrac = (r + 0.5) / rows;
      const xExpr = `w*${xFrac.toFixed(4)}`;
      const yExpr = `h*${yFrac.toFixed(4)}-text_h/2`;
      stamps.push(
        `drawtext=fontfile='${fontFile}':text='${safeText}':` +
          `fontcolor=white@0.28:fontsize=h/22:` +
          `shadowcolor=black@0.30:shadowx=2:shadowy=2:` +
          `x='${xExpr}':y='${yExpr}'`
      );
    }
  }
  return stamps.join(",");
}

/**
 * Pre-render a watermarked ("RClipper" tiled overlay) copy of a finished master
 * clip. Downloads `sourceStorageKey`, burns the tiled watermark over the video,
 * stream-copies the audio through untouched (`-c:a copy` — no re-mix), and
 * uploads the result to `outputStorageKey`.
 *
 * This is the paywall's teeth: the watermarked copy is the only variant shown to
 * a requester whose download is still locked, so even a ripped preview carries
 * the mark. It runs on the Mac render worker (invoked from the overlay/finalize
 * step, which is already dispatched there), keeping the extra encode off the web
 * droplet.
 */
/**
 * ffmpeg's drawtext `fontfile=` value lives inside a filtergraph where `[` `]`
 * `,` `'` `;` are structural characters. A variable-font path like
 * `.../NotoSansThai[wdth,wght].ttf` therefore breaks the `-vf` parse (fails in
 * ~0.1s). Escaping across ffmpeg's multiple quoting levels is fragile, so if the
 * configured font path contains any such character, copy the file once into
 * `destDir` under a plain name and use that instead. Returns the safe path (or
 * the original if it is already safe / the copy fails — best-effort).
 */
async function stageFiltergraphSafeFont(destDir: string): Promise<string> {
  const configured = AI_CONFIG.ffmpeg.fontFile;
  if (!/[[\],';]/.test(configured)) return configured;
  try {
    const ext = path.extname(configured) || ".ttf";
    const safe = path.join(destDir, `font${ext}`);
    await fs.copyFile(configured, safe);
    return safe;
  } catch (err) {
    console.error("[watermark] could not stage a filtergraph-safe font, using configured path:", err);
    return configured;
  }
}

export async function applyTiledWatermark(params: {
  sourceStorageKey: string;
  outputStorageKey: string;
  text?: string;
}): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  const { sourceStorageKey, outputStorageKey, text } = params;
  const ffmpeg = AI_CONFIG.ffmpeg.path;
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-watermark-"));
  try {
    const srcPath = path.join(tmpDir, "clean.mp4");
    const outPath = path.join(tmpDir, "watermarked.mp4");
    await downloadFromSpaces(sourceStorageKey, srcPath);
    // Copy the font to a filtergraph-safe path if its configured path contains
    // characters that break drawtext (e.g. a variable font's `[wdth,wght]`).
    const fontFilePath = await stageFiltergraphSafeFont(tmpDir);

    const startedAt = Date.now();
    try {
      await execFileAsync(ffmpeg, [
        "-y",
        "-i", srcPath,
        "-vf", buildTiledWatermarkFilter(text, fontFilePath),
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-preset", "veryfast",
        // Copy the master's audio (voice + ducked music) through untouched.
        "-c:a", "copy",
        "-movflags", "+faststart",
        outPath,
      ]);
    } catch (err) {
      const detail = describeExecError(err);
      console.error(`[watermark] ffmpeg FAILED after ${((Date.now() - startedAt) / 1000).toFixed(1)}s:`, detail);
      throw new Error(`watermark ffmpeg failed: ${detail}`);
    }

    await uploadToSpaces(outPath, outputStorageKey);
    const { size } = await fs.stat(outPath);
    console.log(
      `[watermark] done in ${((Date.now() - startedAt) / 1000).toFixed(1)}s → ${outputStorageKey} (${size} bytes)`
    );
    return {
      storageKey: outputStorageKey,
      storageUrl: spacesPublicUrl(outputStorageKey),
      fileSizeBytes: size,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Concatenate per-scene montage segments with a short cross-dissolve at each
 * scene join (ffmpeg `xfade`), so scene boundaries dissolve like the within-scene
 * cuts instead of hard-switching.
 *
 * `xfade` overlaps each join by `fadeSeconds`, which shortens the result by
 * `fadeSeconds*(n-1)`. The downstream compose step muxes the voiceover with
 * `-shortest`, and the animation/overlay duration is keyed off the measured
 * voice length (NOT this base), so we freeze the final frame for a short pad to
 * guarantee the base outlasts the voice — the voice is never clipped, and only
 * the frozen frames beyond the voice (which compose drops) are added.
 *
 * Falls back to a hard-cut concat (`concatVideos`) if probing or the xfade
 * filtergraph fails, so the pipeline always produces a base video.
 */
/**
 * The crossfade filtergraph itself, over segments ALREADY on disk.
 *
 * Extracted so the stored-key path and the local-segment path share one
 * implementation — the pairwise xfade offsets and the tpad length correction
 * are subtle enough that a second copy would drift.
 */
async function crossfadeConcatLocal(
  inputPaths: string[],
  outPath: string,
  fadeSeconds: number
): Promise<void> {
  const ffmpeg = AI_CONFIG.ffmpeg.path;

  const durations = await Promise.all(inputPaths.map((p) => probeDurationSeconds(p)));
  if (durations.some((d) => d <= 0)) {
    throw new Error("xfade concat: could not probe one or more segment durations");
  }

  // Never dissolve longer than half of the shortest segment.
  const fade = Math.max(0.05, Math.min(fadeSeconds, ...durations.map((d) => d / 2)));

  const inputArgs: string[] = [];
  inputPaths.forEach((p) => inputArgs.push("-i", p));

  // Chain xfade pairwise. offset for join k = (running accumulated duration) - fade.
  const filters: string[] = [];
  let prevLabel = "0:v";
  let accDuration = durations[0];
  for (let i = 1; i < inputPaths.length; i++) {
    const offset = Math.max(0, accDuration - fade);
    const outLabel = i === inputPaths.length - 1 ? "vxf" : `vx${i}`;
    filters.push(
      `[${prevLabel}][${i}:v]xfade=transition=fade:duration=${fade.toFixed(3)}:offset=${offset.toFixed(3)}[${outLabel}]`
    );
    prevLabel = outLabel;
    accDuration = accDuration + durations[i] - fade;
  }
  // Restore only the length the xfade overlaps removed (`fade*(n-1)`) plus a
  // tiny safety margin — NOT a full extra second. Over-padding here froze the
  // last scene's final frame for ~1s+; keeping the base at its true montage
  // length lets the compose step cover any voice-vs-picture shortfall with a
  // black tail (audio continues) instead of a long frozen frame.
  const padSeconds = fade * (inputPaths.length - 1) + 0.2;
  filters.push(
    `[${prevLabel}]tpad=stop_mode=clone:stop_duration=${padSeconds.toFixed(3)},format=yuv420p,fps=30[vout]`
  );

  await execFileAsync(ffmpeg, [
    "-y",
    ...inputArgs,
    "-filter_complex", filters.join(";"),
    "-map", "[vout]",
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-r", "30",
    "-an",
    outPath,
  ]);
}

/**
 * Hard-cut concat over segments already on disk: stream copy, re-encoding only
 * if the copy fails on mismatched codecs/params. The local mirror of
 * {@link concatVideos}' ffmpeg half.
 */
async function hardCutConcatLocal(
  inputPaths: string[],
  outPath: string,
  workDir: string
): Promise<void> {
  const ffmpeg = AI_CONFIG.ffmpeg.path;
  const listFile = path.join(workDir, "concat-local.txt");
  const listContent = inputPaths
    .map((p) => `file '${p.replace(/\\/g, "/").replace(/'/g, "'\\''")}'`)
    .join("\n");
  await fs.writeFile(listFile, listContent, "utf-8");

  try {
    await execFileAsync(ffmpeg, [
      "-y", "-f", "concat", "-safe", "0", "-i", listFile, "-c", "copy", outPath,
    ]);
  } catch (err) {
    console.error("[ffmpeg] local concat -c copy failed, falling back to re-encode:", describeExecError(err));
    try {
      await execFileAsync(ffmpeg, [
        "-y", "-f", "concat", "-safe", "0", "-i", listFile,
        "-c:v", "libx264", "-c:a", "aac", outPath,
      ]);
    } catch (err2) {
      const detail = describeExecError(err2);
      console.error("[ffmpeg] local concat re-encode failed:", detail);
      throw new Error(`ffmpeg local concat re-encode failed: ${detail}`);
    }
  }
}

export async function concatVideosWithCrossfade(
  inputStorageKeys: string[],
  outputStorageKey: string,
  fadeSeconds = 0.2
): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  if (inputStorageKeys.length <= 1) {
    return concatVideos(inputStorageKeys, outputStorageKey);
  }

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-xfade-"));
  try {
    const inputPaths: string[] = [];
    for (let i = 0; i < inputStorageKeys.length; i++) {
      const dest = path.join(tmpDir, `in-${i}.mp4`);
      await downloadFromSpaces(inputStorageKeys[i], dest);
      inputPaths.push(dest);
    }

    const outPath = path.join(tmpDir, "xfade-out.mp4");
    await crossfadeConcatLocal(inputPaths, outPath, fadeSeconds);

    await uploadToSpaces(outPath, outputStorageKey);
    const { size } = await fs.stat(outPath);
    return {
      storageKey: outputStorageKey,
      storageUrl: spacesPublicUrl(outputStorageKey),
      fileSizeBytes: size,
    };
  } catch (err) {
    console.error("[ffmpeg] crossfade concat failed, falling back to hard-cut concat:", describeExecError(err));
    return concatVideos(inputStorageKeys, outputStorageKey);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Crossfade-concat segments that are ALREADY on this machine and upload only
 * the finished video.
 *
 * The non-primary aspect ratios render their scene segments purely as
 * intermediates. Routing them through {@link concatVideosWithCrossfade} meant
 * uploading every segment to Spaces and downloading all of them straight back —
 * two full transfers of the whole video, per ratio, for files nobody ever sees.
 * The caller owns `inputPaths` and deletes them.
 */
export async function concatLocalVideosWithCrossfade(
  inputPaths: string[],
  outputStorageKey: string,
  fadeSeconds = 0.2
): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  if (inputPaths.length === 0) {
    throw new Error("concatLocalVideosWithCrossfade: at least one input path is required");
  }

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-xfade-local-"));
  try {
    const outPath = path.join(tmpDir, "xfade-out.mp4");

    if (inputPaths.length === 1) {
      // One scene needs no join — but it still has to be uploaded under the
      // output key, so copy rather than special-casing the caller.
      await fs.copyFile(inputPaths[0], outPath);
    } else {
      try {
        await crossfadeConcatLocal(inputPaths, outPath, fadeSeconds);
      } catch (err) {
        // Same degradation as the stored-key path: a failed dissolve must not
        // lose the render, so fall back to a hard cut.
        console.error(
          "[ffmpeg] local crossfade concat failed, falling back to hard-cut concat:",
          describeExecError(err)
        );
        await hardCutConcatLocal(inputPaths, outPath, tmpDir);
      }
    }

    await uploadToSpaces(outPath, outputStorageKey);
    const { size } = await fs.stat(outPath);
    return {
      storageKey: outputStorageKey,
      storageUrl: spacesPublicUrl(outputStorageKey),
      fileSizeBytes: size,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Compose final video with audio and bilingual subtitles, then export
 * in selected platform ratios. Returns DO Spaces keys per ratio.
 */
export async function composeAndExport(
  params: ComposeVideoParams
): Promise<ComposeVideoResult> {
  const tmpDir = path.join(os.tmpdir(), `clipper-${params.requestId}`);
  await fs.mkdir(tmpDir, { recursive: true });

  try {
    const videoPath = path.join(tmpDir, "base.mp4");
    const audioPath = path.join(tmpDir, "voice.wav");

    const musicPath = params.musicTrackId
      ? path.join(process.cwd(), "public", "music", `${params.musicTrackId}.mp3`)
      : undefined;

    console.log(
      `[compose] request ${params.requestId} start: ratios=${(params.targetRatios ?? ["9:16","16:9","1:1","4:5"]).join(",")} music=${params.musicTrackId ?? "none"}`
    );

    await Promise.all([
      downloadFromSpaces(params.videoStorageKey, videoPath),
      downloadFromSpaces(params.audioStorageKey, audioPath),
    ]);
    const [baseStat, voiceStat] = await Promise.all([
      fs.stat(videoPath).catch(() => ({ size: -1 })),
      fs.stat(audioPath).catch(() => ({ size: -1 })),
    ]);
    console.log(`[compose] downloaded base=${baseStat.size}B voice=${voiceStat.size}B`);

    if (musicPath && !existsSync(musicPath)) {
      throw new Error(`compose: music track file not found on this host: ${musicPath}`);
    }

    // Probe the real voice length AND the base video length. The export runs for
    // the full base-video length (the montage covers the voiceover + intro +
    // ending); the voiceover is usually shorter and plays over it.
    const [voiceDuration, videoDuration] = await Promise.all([
      probeDurationSeconds(audioPath),
      probeDurationSeconds(videoPath),
    ]);
    console.log(`[compose] probed durations: voice=${voiceDuration}s video=${videoDuration}s`);

    // Burned-in subtitles are deferred to Phase 7 (accurate timestamp/timeline
    // alignment). For now we only burn captions if the caller explicitly passes
    // ASS content; otherwise no subtitles are rendered.
    let subsPath: string | undefined;
    if (params.assSubtitlesContent) {
      subsPath = path.join(tmpDir, "subs.ass");
      await fs.writeFile(subsPath, params.assSubtitlesContent, "utf-8");
    }

    const targetRatios = params.targetRatios ?? ["9:16", "16:9", "1:1", "4:5"];
    const results: ComposeVideoResult["exports"] = {};

    // Phase 4: download any Remotion overlay clips up front, keyed by ratio.
    const overlayPaths: Partial<Record<VideoRatio, string>> = {};
    if (params.overlayStorageKeys) {
      await Promise.all(
        Object.entries(params.overlayStorageKeys).map(async ([ratio, key]) => {
          if (!key) return;
          const overlayPath = path.join(tmpDir, `overlay-${ratio.replace(":", "-")}.webm`);
          await downloadFromSpaces(key, overlayPath);
          overlayPaths[ratio as VideoRatio] = overlayPath;
        })
      );
    }

    await Promise.all(
      targetRatios.map(async (ratio) => {
        const outPath = path.join(tmpDir, `out-${ratio.replace(":", "-")}.mp4`);
        await composeSingleRatio({
          videoPath,
          audioPath,
          subsPath,
          isAss: !!params.assSubtitlesContent,
          ratio,
          outputPath: outPath,
          musicPath,
          coordinates: params.coordinates,
          overlayPath: overlayPaths[ratio],
          voiceDurationSeconds: voiceDuration,
          videoDurationSeconds: videoDuration,
        });

        const storageKey = buildFinalClipKey(params.userId, params.requestId, ratio);
        await uploadToSpaces(outPath, storageKey);
        console.log(`[compose:${ratio}] uploaded → ${storageKey}`);
        results[ratio] = { storageKey, storageUrl: spacesPublicUrl(storageKey) };
      })
    );
    console.log(`[compose] request ${params.requestId}: all ${targetRatios.length} ratio master(s) composed + uploaded`);

    // Dedicated Travy App export at the PRIMARY channel's ratio. If that ratio's
    // Remotion overlay already covers Travy's fixed English+Chinese subtitle
    // requirement (`overlayCoversTravySubtitles`), reuse that overlay instead of
    // burning `assSubtitlesContentTravy` via ASS. Otherwise, only run an extra
    // ASS-based pass when its subtitle content actually differs from the general
    // export — avoids a redundant FFmpeg pass when the requester also chose EN+ZH.
    const travyRatio: VideoRatio = params.travyRatio ?? "9:16";
    if (overlayPaths[travyRatio] && params.overlayCoversTravySubtitles) {
      const outPath = path.join(tmpDir, "out-travy.mp4");
      await composeSingleRatio({
        videoPath,
        audioPath,
        ratio: travyRatio,
        outputPath: outPath,
        musicPath,
        coordinates: params.coordinates,
        overlayPath: overlayPaths[travyRatio],
        voiceDurationSeconds: voiceDuration,
        videoDurationSeconds: videoDuration,
      });

      const storageKey = buildFinalClipKey(params.userId, params.requestId, "travy");
      await uploadToSpaces(outPath, storageKey);
      results["travy"] = { storageKey, storageUrl: spacesPublicUrl(storageKey) };
    } else if (
      params.assSubtitlesContentTravy &&
      params.assSubtitlesContentTravy !== params.assSubtitlesContent
    ) {
      const travySubsPath = path.join(tmpDir, "subs-travy.ass");
      await fs.writeFile(travySubsPath, params.assSubtitlesContentTravy, "utf-8");

      const outPath = path.join(tmpDir, "out-travy.mp4");
      await composeSingleRatio({
        videoPath,
        audioPath,
        subsPath: travySubsPath,
        isAss: true,
        ratio: travyRatio,
        outputPath: outPath,
        musicPath,
        coordinates: params.coordinates,
        voiceDurationSeconds: voiceDuration,
        videoDurationSeconds: videoDuration,
        // Don't reuse the general overlay here — its captions may not be EN+ZH,
        // and burning both ASS + overlay captions would duplicate text.
      });

      const storageKey = buildFinalClipKey(params.userId, params.requestId, "travy");
      await uploadToSpaces(outPath, storageKey);
      results["travy"] = { storageKey, storageUrl: spacesPublicUrl(storageKey) };
    }

    return { exports: results };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}
