import * as fs from "fs/promises";
import * as path from "path";
import * as os from "os";
import { execFile } from "child_process";
import { promisify } from "util";
import { spacesPublicUrl, spacesUpload } from "@/lib/spaces";
import { AI_CONFIG } from "@/config/aiTools";
import type { TimedSegment } from "@/lib/ai/geminiSubtitlesService";
import type { AnimationSpec } from "@/lib/ai/animationService";
import type { ScenePlan } from "@/domain/models/VideoGenerationJob";
import type { VideoRatio } from "@/lib/ai/ffmpegService";
import type { Palette } from "@/lib/ai/paletteService";
import { getRemotionBundle } from "@/lib/ai/remotionBundle";
import { RENDER_TUNING } from "@/config/renderTuning";
import { withLocalMediaUrl } from "@/lib/ai/localMediaServer";
import type { HeadlessBrowser } from "@remotion/renderer";

/**
 * Phase 4 — Remotion-based motion-graphics/caption overlay rendering.
 *
 * Renders one transparent (alpha-channel, VP8/yuva420p WebM) overlay clip
 * per required aspect ratio, using the `remotion/` project at the repo
 * root (composition id "Overlay" — see `remotion/Root.tsx`). The overlay
 * contains kinetic captions (from `voiceTimestamps`/`subtitleTimeline`) and
 * scene motion-graphics (from `animationSpecs`, produced by
 * `animationService.generateAnimationSpec`).
 *
 * `_runAnimationGeneration` (VideoGenerationService) calls `renderOverlay`
 * once per ratio returned by `ffmpegService.getRequiredRatiosForPlatforms`
 * and stores the resulting asset IDs on `job.animatedOverlayAssetIds`.
 * `_runFFmpegComposition` later composites each overlay onto the
 * corresponding cropped/scaled base video via `ffmpegService.overlayVideo`
 * / `composeSingleRatio`.
 *
 * Render failures should be treated like other AI-step failures: caught by
 * the caller, recorded via `failedAtStep = GeneratingAnimations`, and
 * retryable via `retryPipeline()` / `regenerateAnimationByRequester()`.
 */

const RENDER_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes per ratio — generous for headless Chromium cold starts

const execFileAsync = promisify(execFile);

/**
 * Remux an MP4 in place so the `moov` atom sits at the FRONT (`+faststart`).
 * Without this the browser cannot read the clip's total duration until it has
 * buffered the whole file, so the player shows no total time / a stuck scrubber
 * on first load. Stream-copy only (no re-encode). Best-effort: on any failure the
 * original file is left untouched.
 */
async function faststartRemux(mp4Path: string): Promise<void> {
  const ffmpeg = AI_CONFIG.ffmpeg.path ?? "ffmpeg";
  const tmpOut = `${mp4Path}.faststart.mp4`;
  try {
    await execFileAsync(ffmpeg, [
      "-y",
      "-i", mp4Path,
      "-c", "copy",
      "-movflags", "+faststart",
      tmpOut,
    ]);
    await fs.rename(tmpOut, mp4Path);
  } catch (err) {
    console.error("[remotion] faststart remux failed, using original output:", err);
    await fs.rm(tmpOut, { force: true }).catch(() => {});
  }
}

export interface RenderOverlayParams {
  ratio: VideoRatio;
  /** Real voice/video duration in seconds (from `job.voiceDurationSeconds`). */
  durationSeconds: number;
  /** Per-sentence timing for kinetic captions (`job.voiceTimestamps`/`subtitleTimeline`, parsed). */
  subtitleTimeline: TimedSegment[];
  /** Languages to render as burned-in captions on this overlay. */
  subtitleLanguages: ("th" | "en" | "zh")[];
  /** Approved scene plan — passed through for future scene-transition templates. */
  scenePlan: ScenePlan[];
  /** Motion-graphics overlay specs from `animationService.generateAnimationSpec`. */
  animationSpecs: AnimationSpec[];
  /** Brand/content palette for the decorative shape layer. */
  palette: Palette;
  /** DO Spaces key the rendered `.webm` overlay clip will be uploaded to. */
  outputStorageKey: string;
}

/**
 * Renders one transparent overlay clip and uploads it to DO Spaces.
 * Returns the asset's public URL (caller is responsible for creating the
 * corresponding `UploadedAsset` record).
 */
export async function renderOverlay(params: RenderOverlayParams): Promise<string> {
  const {
    ratio,
    durationSeconds,
    subtitleTimeline,
    subtitleLanguages,
    scenePlan,
    animationSpecs,
    palette,
    outputStorageKey,
  } = params;

  const inputProps = {
    ratio,
    durationSeconds,
    subtitleTimeline,
    subtitleLanguages,
    scenePlan: scenePlan.map((s) => ({
      sceneNumber: s.sceneNumber,
      durationSeconds: s.durationSeconds,
      visualDescriptionThai: s.visualDescriptionThai,
      imageIndexes: s.imageIndexes,
    })),
    animationSpecs,
    palette,
  };

  const { selectComposition, renderMedia } = await import("@remotion/renderer");
  const serveUrl = await getRemotionBundle();

  const composition = await selectComposition({
    serveUrl,
    id: "Overlay",
    inputProps,
  });

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-remotion-"));
  const outputPath = path.join(tmpDir, "overlay.webm");

  try {
    await renderMedia({
      composition,
      serveUrl,
      // VP9 (not VP8) for the alpha WebM: FFmpeg decodes VP9 `yuva420p` alpha
      // reliably, whereas the VP8 alpha plane was being dropped to black at
      // composite time (the "black video behind the captions" bug).
      codec: "vp9",
      pixelFormat: "yuva420p",
      // Use the whole machine for frame capture (Remotion defaults to about
      // half the cores). No x264/hardware options here: this output is VP9,
      // and both of those are H.264-only.
      concurrency: RENDER_TUNING.concurrency,
      // Transparent (alpha) output requires PNG frames — the default JPEG image
      // format cannot carry an alpha channel and Remotion rejects the combo.
      imageFormat: "png",
      outputLocation: outputPath,
      inputProps,
      timeoutInMilliseconds: RENDER_TIMEOUT_MS,
    });

    const data = await fs.readFile(outputPath);
    // Multipart: a large overlay clip times out on a single PutObject (~50s
    // window) and DO Spaces returns an opaque 400. Split into small parts.
    await spacesUpload({ key: outputStorageKey, body: data, contentType: "video/webm" });
    return spacesPublicUrl(outputStorageKey);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}

export interface RenderTemplatedVideoParams {
  /** Public URL of the merged (voice+music) master for this ratio. */
  masterUrl: string;
  /**
   * Optional path to the master ALREADY on this machine's disk. When set, the
   * render reads it over loopback instead of pulling `masterUrl` from DO
   * Spaces, which is otherwise a full download of the master per ratio.
   * The caller owns the file and deletes it; this function only reads it.
   */
  masterFilePath?: string;
  ratio: VideoRatio;
  durationSeconds: number;
  templateId: string;
  palette: Palette;
  subtitleTimeline: TimedSegment[];
  subtitleLanguages: ("th" | "en" | "zh")[];
  /** DO Spaces key the rendered `.mp4` will be uploaded to. */
  outputStorageKey: string;
  /**
   * Optional render-progress callback (0..1), forwarded from Remotion's
   * `renderMedia` overall progress. Used for the requester-facing % bar.
   */
  onProgress?: (fraction: number) => void;
  /** Optional shared Chromium (see `@/lib/ai/remotionBrowser`). */
  browser?: HeadlessBrowser;
}

/**
 * Phase 7 (template redesign) — render the final styled/captioned video in a
 * SINGLE Remotion pass: the master plays inside the composition (audio carried
 * through OffthreadVideo) with the template frame/decor + subtitles on top,
 * output as an opaque H.264 MP4. No alpha compositing (this is what fixes the
 * black-video bug). Returns the stored clip.
 */
export async function renderTemplatedVideo(
  params: RenderTemplatedVideoParams
): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  // When the caller already has the master on disk, serve it over loopback for
  // the duration of the render rather than making Remotion fetch it from DO
  // Spaces. `withLocalMediaUrl` always tears the server down, including when
  // the render throws.
  if (params.masterFilePath && RENDER_TUNING.localMasterEnabled) {
    return withLocalMediaUrl(params.masterFilePath, "video/mp4", (localUrl) =>
      renderTemplatedVideoFrom(params, localUrl)
    );
  }
  return renderTemplatedVideoFrom(params, params.masterUrl);
}

/** The render itself, against whichever master URL the caller resolved. */
async function renderTemplatedVideoFrom(
  params: RenderTemplatedVideoParams,
  masterUrl: string
): Promise<{ storageKey: string; storageUrl: string; fileSizeBytes: number }> {
  const inputProps = {
    masterUrl,
    ratio: params.ratio,
    durationSeconds: params.durationSeconds,
    templateId: params.templateId,
    palette: params.palette,
    subtitleTimeline: params.subtitleTimeline,
    subtitleLanguages: params.subtitleLanguages,
  };

  const { selectComposition, renderMedia } = await import("@remotion/renderer");
  const serveUrl = await getRemotionBundle();

  const composition = await selectComposition({
    serveUrl,
    id: "TemplatedVideo",
    inputProps,
    puppeteerInstance: params.browser,
  });

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "clipper-templated-"));
  const outputPath = path.join(tmpDir, "styled.mp4");

  try {
    await renderMedia({
      composition,
      serveUrl,
      codec: "h264",
      pixelFormat: "yuv420p",
      // Performance settings — see `@/config/renderTuning` for what each does
      // and which environment variable reverts it.
      concurrency: RENDER_TUNING.concurrency,
      x264Preset: RENDER_TUNING.x264Preset,
      hardwareAcceleration: RENDER_TUNING.hardwareAcceleration,
      puppeteerInstance: params.browser,
      outputLocation: outputPath,
      inputProps,
      timeoutInMilliseconds: RENDER_TIMEOUT_MS,
      onProgress: ({ progress }) => params.onProgress?.(progress),
    });

    // Move the moov atom to the front so the player shows the total duration on
    // first load (matching the montage/base-video card behavior).
    await faststartRemux(outputPath);

    const data = await fs.readFile(outputPath);
    // Multipart upload: a single PutObject of the styled clip can't finish
    // inside DO Spaces' ~50s request window and is cut with an opaque 400 — this
    // is what stalled the `overlay_composition` step ("generating_overlay").
    // spacesUpload splits it into small parts. Log the size for visibility.
    console.log(
      `[overlay] uploading styled ${params.ratio} mp4: ${(data.length / 1048576).toFixed(1)} MB → ${params.outputStorageKey}`
    );
    await spacesUpload({ key: params.outputStorageKey, body: data, contentType: "video/mp4" });
    return {
      storageKey: params.outputStorageKey,
      storageUrl: spacesPublicUrl(params.outputStorageKey),
      fileSizeBytes: data.length,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true });
  }
}
