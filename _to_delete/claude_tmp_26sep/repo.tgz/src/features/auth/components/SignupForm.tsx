"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { signupSchema, SignupInput } from "@/features/auth/validation/signupSchema";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { SocialSignInButtons } from "./SocialSignInButtons";
import { ROUTES } from "@/config/routes";
import { fetchWithTimeout, RequestTimeoutError } from "@/lib/fetchWithTimeout";

export function SignupForm() {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignupInput>({
    resolver: zodResolver(signupSchema),
  });

  const onSubmit = async (data: SignupInput) => {
    setServerError(null);

    try {
      const response = await fetchWithTimeout("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        if (response.status === 409) {
          if (result.data?.existingAccountVerified === true) {
            router.push(
              `${ROUTES.LOGIN}?message=${encodeURIComponent(
                "อีเมลนี้มีบัญชีที่ยืนยันแล้ว กรุณาเข้าสู่ระบบ"
              )}`
            );
            return;
          }

          // A previous attempt may have created the account successfully before
          // verification-email delivery failed. Preserve that account/password
          // and take the user to the resend flow instead of leaving them stuck.
          router.push(
            `${ROUTES.VERIFY_EMAIL}?email=${encodeURIComponent(data.email)}&existing=1`
          );
          return;
        }

        if (result.fieldErrors && typeof result.fieldErrors === "object") {
          for (const [field, messages] of Object.entries(result.fieldErrors)) {
            if (
              (field === "name" ||
                field === "email" ||
                field === "password" ||
                field === "confirmPassword") &&
              Array.isArray(messages) &&
              typeof messages[0] === "string"
            ) {
              setError(field, { type: "server", message: messages[0] });
            }
          }
        }
        setServerError(result.error ?? "การสมัครสมาชิกล้มเหลว กรุณาลองอีกครั้ง");
        return;
      }

      // Account created — redirect to verify-email page
      const deliveryFailed =
        result.data?.verificationEmailSent === false ? "&delivery=failed" : "";
      router.push(
        `${ROUTES.VERIFY_EMAIL}?email=${encodeURIComponent(data.email)}${deliveryFailed}`
      );
    } catch (error) {
      // A timeout is reported distinctly: the account may well have been created
      // before the server stalled, so telling the user to retry blindly would
      // walk them into a duplicate-email error on the next attempt.
      setServerError(
        error instanceof RequestTimeoutError
          ? "เซิร์ฟเวอร์ใช้เวลานานเกินไป บัญชีของคุณอาจถูกสร้างแล้ว กรุณาลองเข้าสู่ระบบ หรือลองสมัครใหม่อีกครั้ง"
          : "เกิดข้อผิดพลาด กรุณาลองอีกครั้ง"
      );
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
      {serverError && (
        <div
          className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
          role="alert"
        >
          {serverError}
        </div>
      )}

      <SocialSignInButtons
        callbackUrl={ROUTES.DASHBOARD}
        dividerLabel="หรือสมัครด้วยอีเมล"
        dividerPlacement="after"
        googleLabel="สมัครด้วย Google"
        appleLabel="สมัครด้วย Apple"
      />

      <Input
        label="ชื่อ-นามสกุล"
        type="text"
        autoComplete="name"
        placeholder="สมชาย ใจดี"
        error={errors.name?.message}
        {...register("name")}
      />

      <Input
        label="อีเมล"
        type="email"
        autoComplete="email"
        placeholder="you@example.com"
        error={errors.email?.message}
        {...register("email")}
      />

      <Input
        label="รหัสผ่าน"
        type="password"
        autoComplete="new-password"
        placeholder="••••••••"
        hint="อย่างน้อย 8 ตัวอักษร ต้องมีตัวพิมพ์ใหญ่ พิมพ์เล็ก และตัวเลข"
        error={errors.password?.message}
        {...register("password")}
      />

      <Input
        label="ยืนยันรหัสผ่าน"
        type="password"
        autoComplete="new-password"
        placeholder="••••••••"
        error={errors.confirmPassword?.message}
        {...register("confirmPassword")}
      />

      <Button type="submit" fullWidth loading={isSubmitting} size="lg">
        สร้างบัญชี
      </Button>

      <p className="text-center text-xs text-slate-500 leading-relaxed">
        การคลิก &ldquo;สร้างบัญชี&rdquo; หรือ &ldquo;สมัครด้วย Google&rdquo; ถือว่าคุณยอมรับ{" "}
        <Link href={ROUTES.TERMS} className="underline hover:text-slate-700">
          ข้อกำหนดการใช้งาน
        </Link>{" "}
        และ{" "}
        <Link href={ROUTES.PRIVACY} className="underline hover:text-slate-700">
          นโยบายความเป็นส่วนตัว
        </Link>{" "}
        และ{" "}
        <Link href={ROUTES.OWNERSHIP} className="underline hover:text-slate-700">
          นโยบายสิทธิ์ในเนื้อหาและการเผยแพร่
        </Link>
        ซึ่งอธิบายการคัดเลือกวิดีโอบางรายการเพื่อเผยแพร่ผ่านช่องทางของ RClipper
        รวมถึงแอป Travy เว็บไซต์ Travy.buzz และบัญชีโซเชียลมีเดียอย่างเป็นทางการ
      </p>

      <div className="border-t border-slate-100 pt-2">
        <p className="text-center text-sm text-slate-500">
          มีบัญชีอยู่แล้ว?{" "}
          <Link
            href={ROUTES.LOGIN}
            className="text-blue-700 font-medium hover:underline"
          >
            เข้าสู่ระบบ
          </Link>
        </p>
      </div>
    </form>
  );
}
