import type { Metadata } from "next";
import Link from "next/link";
import { requireRole } from "@/lib/auth/helpers";
import { Role } from "@/domain/enums/Role";
import { ROUTES, requestDetailPath } from "@/config/routes";
import { requesterDashboardService } from "@/services/RequesterDashboardService";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { RequestStatusBadge } from "@/features/requests/components/RequestStatusBadge";
import { DueDateDisplay } from "@/features/requests/components/DueDateDisplay";
import { CancelRequestButton } from "@/features/requests/components/CancelRequestButton";
import { RequestStatus } from "@/domain/enums/RequestStatus";
import {
  quotaNotice,
  quotaCopyVars,
  QUOTA_TONE_STYLES,
} from "@/features/requests/quotaCopy";
import { getServerI18n } from "@/i18n/server";

export const metadata: Metadata = { title: "แดชบอร์ด — RClipper" };

export default async function DashboardPage() {
  const { locale, t } = getServerI18n();
  const user = await requireRole(Role.Requester);
  const summary = await requesterDashboardService.getDashboardSummary(user.id);

  // Access is a monthly quota, not a per-request charge: a 0-credit user with
  // free allowance left can still submit, and a subscriber with a live package
  // submits regardless of balance.
  const quota = summary.quota;
  const canSubmit = quota.canSubmit;
  const notice = quotaNotice(t, quota, locale);
  const tone = QUOTA_TONE_STYLES[notice.tone];

  return (
    <div className="mx-auto w-full min-w-0 max-w-5xl px-4 py-6 sm:px-6 sm:py-10">
      {/* Header — stacks on phones so the CTAs never overflow the viewport. */}
      <div className="mb-6 flex flex-col gap-4 sm:mb-8 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h1 className="break-words text-xl font-bold text-slate-900 sm:text-2xl">
            {t("dashboard.welcome", { name: user.name.split(" ")[0] })}
          </h1>
          <p className="mt-1 text-sm text-slate-500 sm:text-base">
            {t("dashboard.subtitle")}
          </p>
        </div>
        {/* ONE call to action. There used to be a green "make a free video"
            button beside this one, but both linked to the same route: under the
            monthly quota model there is no separate free path to start — the
            tier is resolved server-side at submission from the user's remaining
            allowance. Two buttons doing the identical thing only made the user
            wonder which one was correct. When the allowance is spent this button
            disables and the quota banner below carries the link to pricing. */}
        <div className="flex flex-wrap items-center gap-2 sm:flex-shrink-0">
          <Link href={ROUTES.REQUESTS_NEW} className="min-w-0 flex-1 sm:flex-none">
            <Button
              fullWidth
              variant={canSubmit ? "outline" : undefined}
              disabled={!canSubmit}
              className="sm:w-auto"
            >
              {t("dashboard.newRequest")}
            </Button>
          </Link>
        </div>
      </div>

      {/* Credits + Stats */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:mb-8 sm:grid-cols-2 lg:grid-cols-3">
        <div className="flex items-center gap-4 rounded-xl border border-blue-200 bg-blue-50 p-4 sm:col-span-2 sm:p-5 lg:col-span-1">
          {/* Pill rather than a fixed circle: large balances (e.g. 25,204)
              would otherwise spill outside a 48px round badge. */}
          <div className="flex h-12 min-w-[3rem] flex-shrink-0 items-center justify-center rounded-full bg-blue-700 px-3 text-base font-bold tabular-nums text-white">
            {summary.creditBalance}
          </div>
          <div className="min-w-0">
            <p className="break-words font-semibold text-blue-900">
              {t("dashboard.credits", { count: summary.creditBalance })}
            </p>
            <Link href={ROUTES.CREDITS}>
              <p className="text-sm text-blue-700 hover:underline cursor-pointer">
                {t("dashboard.creditHistory")}
              </p>
            </Link>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-3xl font-bold text-slate-900">
            {summary.activeRequestCount}
          </p>
          <p className="mt-1 text-sm text-slate-500">{t("dashboard.activeCount")}</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-3xl font-bold text-slate-900">
            {summary.draftCount}
          </p>
          <p className="mt-1 text-sm text-slate-500">
            {t("dashboard.draftCount")}
          </p>
          {summary.draftCount > 0 && (
            <Link href={ROUTES.REQUESTS}>
              <p className="mt-1 text-xs text-blue-600 hover:underline cursor-pointer">
                {t("dashboard.continue")}
              </p>
            </Link>
          )}
        </div>
      </div>

      {/* Quota banner — how many videos are left this period and what happens
          when they run out. Shown in every state: once the allowance is spent it
          becomes the upgrade prompt, which is the answer to "why can't I submit?". */}
      <div className={`mb-6 rounded-xl border p-4 ${tone.container}`}>
        <p className={`text-sm font-medium ${tone.title}`}>{notice.title}</p>
        <p className={`mt-1 text-sm ${tone.body}`}>{notice.body}</p>
        {!canSubmit && (
          <Link href={ROUTES.PRICING}>
            <p className={`mt-2 text-sm font-medium underline ${tone.title}`}>
              {t("quota.viewPricing")}
            </p>
          </Link>
        )}
      </div>

      {/* Active Requests */}
      <div className="mb-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">{t("dashboard.active")}</h2>
          <Link href={ROUTES.REQUESTS} className="text-sm text-blue-600 hover:underline">
            {t("dashboard.viewAll")}
          </Link>
        </div>

        {summary.activeRequests.length === 0 ? (
          <Card>
            <div className="text-center py-6">
              <p className="text-slate-500 text-sm">{t("dashboard.noActive")}</p>
              {canSubmit ? (
                <Link href={ROUTES.REQUESTS_NEW}>
                  <Button className="mt-4" variant="outline" size="sm">
                    {t("dashboard.firstFree")}
                  </Button>
                </Link>
              ) : null}
            </div>
          </Card>
        ) : (
          <div className="flex flex-col gap-3">
            {summary.activeRequests.map((req) => {
              const cancellable =
                req.status === RequestStatus.Draft ||
                req.status === RequestStatus.Submitted;
              return (
                <Link
                  key={req.id}
                  href={requestDetailPath(req.id)}
                  className="block min-w-0"
                >
                  <Card
                    padding="sm"
                    className="cursor-pointer transition-shadow hover:shadow-md sm:p-6"
                  >
                    <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                      <div className="min-w-0 flex-1">
                        <p className="break-words font-medium leading-6 text-slate-900 sm:truncate">
                          {req.title}
                        </p>
                        <p className="mt-1 break-words text-xs leading-5 text-slate-400">
                          {req.statusPresentation.description}
                        </p>
                        {req.queueDisplay.show && (
                          <p className="mt-1 break-words text-xs leading-5 text-slate-500">
                            {req.queueDisplay.message}
                          </p>
                        )}
                      </div>
                      <div className="flex min-w-0 flex-col items-start gap-2 border-t border-slate-100 pt-3 sm:flex-shrink-0 sm:items-end sm:border-0 sm:pt-0">
                        <RequestStatusBadge status={req.status} />
                        <DueDateDisplay
                          display={req.dueDateDisplay}
                          className="max-w-full break-words sm:max-w-64 sm:text-right"
                        />
                        {cancellable && (
                          <CancelRequestButton requestId={req.id} status={req.status} />
                        )}
                      </div>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Recently Delivered */}
      {summary.recentlyDelivered.length > 0 && (
        <div className="mb-8">
          <h2 className="mb-4 text-base font-semibold text-slate-900">
            {t("dashboard.recent")}
          </h2>
          <div className="flex flex-col gap-3">
            {summary.recentlyDelivered.map((row) => (
              <Link key={row.id} href={requestDetailPath(row.id)}>
                <Card padding="sm" className="cursor-pointer transition-shadow hover:shadow-md sm:p-6">
                  <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
                    <div className="min-w-0">
                      <p className="break-words font-medium text-slate-900">{row.title}</p>
                      <p className="text-xs text-slate-400">
                        {t("dashboard.deliveredOn", { date: row.deliveredAt.toLocaleDateString(
                          locale === "th" ? "th-TH" : locale === "vi" ? "vi-VN" : "en-GB", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        }) })}
                      </p>
                    </div>
                    <div className="flex flex-shrink-0 items-center gap-2">
                      <Badge variant="green">{t("dashboard.delivered")}</Badge>
                      <span className="text-xs text-slate-500">
                        {t("dashboard.links", { count: row.linkCount })}
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader padding="none">
            <CardTitle className="text-sm">{t("dashboard.pricing")}</CardTitle>
            <CardDescription>
              {t("dashboard.pricingBody", quotaCopyVars(quota, locale))}
            </CardDescription>
          </CardHeader>
          <Link href={ROUTES.CREDITS}>
            <p className="mt-3 text-xs text-blue-600 hover:underline cursor-pointer">
              {t("dashboard.creditHistory")}
            </p>
          </Link>
        </Card>

        <Card>
          <CardHeader padding="none">
            <CardTitle className="text-sm">{t("dashboard.ownership")}</CardTitle>
            <CardDescription>
              {t("dashboard.ownershipBody")}
            </CardDescription>
          </CardHeader>
          <Link href={ROUTES.LEGAL}>
            <p className="mt-3 text-xs text-blue-600 hover:underline cursor-pointer">
              {t("dashboard.readPolicy")}
            </p>
          </Link>
        </Card>
      </div>
    </div>
  );
}
