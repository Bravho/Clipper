import type { Metadata } from "next";
import dynamicImport from "next/dynamic";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { headers } from "next/headers";
import { isAppUserAgent } from "@/lib/mobile/appUserAgent";
import { requireRole } from "@/lib/auth/helpers";
import { Role } from "@/domain/enums/Role";
import { ROUTES, studioPath } from "@/config/routes";
import { clipRequestService } from "@/services/ClipRequestService";
import { videoGenerationService } from "@/services/VideoGenerationService";
import { requestPresentationService } from "@/services/RequestPresentationService";
import {
  uploadedAssetRepository,
  publishingLinkRepository,
  requestStatusHistoryRepository,
  videoGenerationJobRepository,
  renderTaskRepository,
} from "@/repositories";
import { RequestStatus } from "@/domain/enums/RequestStatus";
import { Platform, PLATFORM_ASPECT_RATIOS, PLATFORM_LABELS } from "@/domain/enums/Platform";
import { getRequiredRatiosForPlatforms } from "@/lib/ai/ffmpegService";
import { isJobStalled } from "@/config/stallThresholds";
import { isAutoApprovedGate } from "@/config/pipelinePresentation";
import { Card } from "@/components/ui/Card";
import { RequestStatusBadge } from "@/features/requests/components/RequestStatusBadge";
import { DueDateDisplay } from "@/features/requests/components/DueDateDisplay";
import { DeliveryLinks } from "@/features/requests/components/DeliveryLinks";
import { RequestTimeline } from "@/features/requests/components/RequestTimeline";
import { RetentionNoteText } from "@/features/requests/components/RetentionNoteText";
import {
  finalClipAvailabilityNote,
  inactivityNote,
  uploadedMaterialsNote,
} from "@/lib/retentionNotes";
import { StoryboardView } from "@/features/requests/components/StoryboardView";
import { VideoGenerationStep } from "@/domain/enums/VideoGenerationStep";
import { AssetType, AssetUploadStatus } from "@/domain/enums/AssetType";
import { orderSourceAssets } from "@/lib/sourceAssets";
import { getServerLocale } from "@/i18n/server";
import type { ScenePlan, StoryboardScene } from "@/domain/models/VideoGenerationJob";
import { buildDistributionTransferView } from "@/features/management/server/buildDistributionTransferView";

// Split the interactive workflow steps so a request only downloads the browser
// code needed for its current pipeline state.
const AnalyzeButton = dynamicImport(() =>
  import("@/features/requests/components/AnalyzeButton").then((module) => module.AnalyzeButton)
);
const ContentApprovalPanel = dynamicImport(() =>
  import("@/features/requests/components/ContentApprovalPanel").then(
    (module) => module.ContentApprovalPanel
  )
);
const DistributionReviewPanel = dynamicImport(() =>
  import("@/features/requests/components/DistributionReviewPanel").then(
    (module) => module.DistributionReviewPanel
  )
);
const PipelineFailurePanel = dynamicImport(() =>
  import("@/features/requests/components/PipelineFailurePanel").then(
    (module) => module.PipelineFailurePanel
  )
);
// No `ssr: false` here: this page is a Server Component, where that option is
// rejected. The component is safe to render on the server anyway — it decides
// nothing until an effect has asked the native layer what this device can do,
// and renders nothing at all until that answer arrives.
const DeviceRenderRunner = dynamicImport(() =>
  import("@/features/requests/components/DeviceRenderRunner").then(
    (module) => module.DeviceRenderRunner
  )
);
const PipelineSection = dynamicImport(() =>
  import("@/features/requests/components/PipelineSection").then(
    (module) => module.PipelineSection
  )
);
const SceneDesignApprovalPanel = dynamicImport(() =>
  import("@/features/requests/components/SceneDesignApprovalPanel").then(
    (module) => module.SceneDesignApprovalPanel
  )
);
const SceneDesignGeneratingPanel = dynamicImport(() =>
  import("@/features/requests/components/SceneDesignApprovalPanel").then(
    (module) => module.SceneDesignGeneratingPanel
  )
);
const SceneScriptApprovalPanel = dynamicImport(() =>
  import("@/features/requests/components/SceneScriptApprovalPanel").then(
    (module) => module.SceneScriptApprovalPanel
  )
);
const VideoApprovalPanel = dynamicImport(() =>
  import("@/features/requests/components/VideoApprovalPanel").then(
    (module) => module.VideoApprovalPanel
  )
);

export const metadata: Metadata = { title: "Request Detail — RClipper" };
export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function RequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const pageStartedAt = performance.now();
  const timings: Record<string, number> = {};
  const timed = async <T,>(label: string, operation: () => Promise<T>): Promise<T> => {
    const startedAt = performance.now();
    try {
      return await operation();
    } finally {
      timings[label] = Math.round(performance.now() - startedAt);
    }
  };

  const { id } = await params;
  const user = await timed("auth", () => requireRole(Role.Requester));

  // Start all independent reads together. Ownership is still checked before
  // any result is rendered, but supporting reads no longer wait for it.
  const supportingDataPromise = Promise.all([
    timed("assets", () => uploadedAssetRepository.findByRequestId(id)),
    timed("publishingLinks", () => publishingLinkRepository.findByRequestId(id)),
    timed("statusHistory", () => requestStatusHistoryRepository.findByRequestId(id)),
    timed("pipelineJob", () => videoGenerationJobRepository.findByRequestId(id)),
  ]);

  let request;
  try {
    request = await timed("request", () => clipRequestService.getOwnedRequest(id, user.id));
  } catch {
    // Avoid leaving rejected supporting reads unobserved on a not-found path.
    await supportingDataPromise.catch(() => undefined);
    notFound();
  }

  // A studio request (rendered on the phone) is worked on in the studio: inside
  // the app, opening it from the list, a notification or a link goes straight
  // back to the studio at its step. In a browser this page still shows it.
  if (request.renderLocation === "device" && isAppUserAgent(headers().get("user-agent"))) {
    await supportingDataPromise.catch(() => undefined);
    redirect(studioPath(request.id));
  }

  const [assets, publishingLinks, statusHistory, rawPipelineJob] = await supportingDataPromise;

  // Reconcile a stuck-failed render (worker marked the claim failed but never
  // advanced the job step) so a page refresh reflects the failure immediately —
  // the status poller performs the same reconciliation on its interval. No-op
  // unless the render genuinely failed, so legitimate long renders still load.
  const pipelineJob = rawPipelineJob
    ? await timed("reconcileFailedRender", () =>
        videoGenerationService.reconcileFailedRender(rawPipelineJob)
      )
    : null;

  // Active render-task for the job (if its current heavy step is on the Mac
  // worker line). Fetched here — not inside the synchronous JSX IIFE below — so
  // isJobStalled can tell a live worker render from a genuinely stranded step.
  const activeRenderTask = pipelineJob
    ? await renderTaskRepository.findActiveByJob(pipelineJob.id)
    : null;

  // Status History shows both request-level milestones AND the AI pipeline
  // phases the job has passed through. The pipeline drives progress on the job
  // (not the request status), so without the step history the timeline would
  // only ever show Draft + Submitted.
  const stepHistory = pipelineJob
    ? await timed("stepHistory", () =>
        videoGenerationJobRepository.listStepHistory(pipelineJob.id)
      )
    : [];
  const timelineEntries = requestPresentationService.buildStatusTimeline(
    statusHistory,
    stepHistory,
    pipelineJob?.currentStep ?? null,
    pipelineJob?.stepStartedAt ?? pipelineJob?.updatedAt ?? null
  );

  if (process.env.REQUEST_DETAIL_PERF_LOG === "1") {
    console.info("[request-detail timing]", {
      ...timings,
      totalDataLoad: Math.round(performance.now() - pageStartedAt),
    });
  }

  const baseVideoAsset = pipelineJob?.baseVideoAssetId
    ? assets.find((a) => a.id === pipelineJob.baseVideoAssetId) ?? null
    : null;

  // All rendered per-scene segments, in scene order, for the combined review
  // (each scene video is shown + revised individually before "Approve all").
  const sceneVideos = (pipelineJob?.sceneVideoAssetIds ?? [])
    .map((assetId, index) => {
      if (!assetId) return null;
      const asset = assets.find((a) => a.id === assetId);
      if (!asset?.storageUrl) return null;
      return { sceneNumber: index + 1, sceneIndex: index, url: asset.storageUrl, assetId: asset.id };
    })
    .filter(
      (v): v is { sceneNumber: number; sceneIndex: number; url: string; assetId: string } =>
        v !== null
    );

  // Latest generated cumulative video, derived independently of the current
  // step. Prefer the most recent completed per-scene cumulative asset; fall
  // back to the active baseVideoAssetId. Used to show the previously approved
  // video on the next scene's script gate.
  const latestSceneVideoAssetId =
    pipelineJob?.sceneVideoAssetIds?.filter((id): id is string => Boolean(id)).pop() ?? null;
  const latestVideoAsset =
    (latestSceneVideoAssetId
      ? assets.find((a) => a.id === latestSceneVideoAssetId) ?? null
      : null) ?? baseVideoAsset;

  const voiceRecordingAsset = pipelineJob?.processedVoiceAssetId
    ? assets.find((a) => a.id === pipelineJob.processedVoiceAssetId) ?? null
    : null;

  const animatedVideoAsset = pipelineJob?.animatedVideoAssetId
    ? assets.find((a) => a.id === pipelineJob.animatedVideoAssetId) ?? null
    : null;

  // Only the CURRENT job's exports — not every FinalClip ever produced for this
  // request. Building from the job's finalExport_* ids (deduped) prevents stale
  // clips from earlier compose runs (wrong ratios / silent older renders) from
  // showing up in the review UI.
  const finalExportAssetIds = Array.from(
    new Set(
      [
        pipelineJob?.finalExport_9_16_assetId,
        pipelineJob?.finalExport_16_9_assetId,
        pipelineJob?.finalExport_1_1_assetId,
        pipelineJob?.finalExport_4_5_assetId,
        pipelineJob?.finalExport_travy_assetId,
      ].filter((id): id is string => !!id)
    )
  );
  const finalClips = finalExportAssetIds
    .map((id) => assets.find((a) => a.id === id))
    .filter(
      (a): a is NonNullable<typeof a> =>
        !!a &&
        a.assetType === AssetType.FinalClip &&
        a.uploadStatus === AssetUploadStatus.Uploaded
    );

  // The base + final review use the PRIMARY distribution channel's aspect ratio
  // (targetPlatforms[0]); the final review shows only this ratio (no selector).
  const primaryPlatform = (request.targetPlatforms?.[0] as Platform) ?? Platform.TravyApp;
  const primaryRatio = PLATFORM_ASPECT_RATIOS[primaryPlatform] ?? null;

  // Pay-to-download watermark gate: while the download is locked (unpaid), every
  // preview the requester can watch must be the pre-rendered WATERMARKED sibling,
  // never the clean master (which would otherwise be rippable straight from the
  // <video src>). `previewUrlFor` maps a clean captioned asset id to its
  // watermarked variant when locked, and returns the clean URL once unlocked. If
  // a watermark is (rarely) missing while locked, it returns null so the clean
  // file is withheld rather than leaked.
  // RETAINED, ALWAYS FALSE. Migration 033 unlocked every request and nothing
  // locks new ones, so `previewUrlFor` below is a pass-through. Kept wired so a
  // future watermarked tier is a configuration change rather than a rebuild.
  const downloadLocked = !request.downloadUnlocked;
  const watermarkedUrlBySource = new Map<string, string>();
  for (const a of assets) {
    if (
      a.assetType === AssetType.WatermarkedPreview &&
      a.sourceAssetId &&
      a.storageUrl
    ) {
      watermarkedUrlBySource.set(a.sourceAssetId, a.storageUrl);
    }
  }
  const previewUrlFor = (
    cleanAssetId: string | null | undefined,
    cleanUrl: string | null
  ): string | null => {
    if (!downloadLocked) return cleanUrl;
    if (!cleanAssetId) return null;
    return watermarkedUrlBySource.get(cleanAssetId) ?? null;
  };

  // Phase 7 — captioned primary-ratio preview (overlay review step) + Travy clip.
  const captionedPrimaryAssetId =
    primaryRatio === "9:16" ? pipelineJob?.captionedExport_9_16_assetId
    : primaryRatio === "16:9" ? pipelineJob?.captionedExport_16_9_assetId
    : primaryRatio === "1:1" ? pipelineJob?.captionedExport_1_1_assetId
    : primaryRatio === "4:5" ? pipelineJob?.captionedExport_4_5_assetId
    : null;
  const overlayPreviewUrl = previewUrlFor(
    captionedPrimaryAssetId,
    captionedPrimaryAssetId
      ? assets.find((a) => a.id === captionedPrimaryAssetId)?.storageUrl ?? null
      : null
  );
  const travyClipUrl = previewUrlFor(
    pipelineJob?.finalExport_travy_assetId,
    pipelineJob?.finalExport_travy_assetId
      ? assets.find((a) => a.id === pipelineJob.finalExport_travy_assetId)?.storageUrl ?? null
      : null
  );

  // Phase 8 — the captioned (subtitled) video actually delivered to each ratio,
  // so the distribution-review panel can show/download every generated channel
  // video (not just the primary). Keyed by ratio; each channel maps to its ratio.
  const captionedUrlByRatio: Record<string, string | null> = {
    "9:16": previewUrlFor(
      pipelineJob?.captionedExport_9_16_assetId,
      pipelineJob?.captionedExport_9_16_assetId
        ? assets.find((a) => a.id === pipelineJob.captionedExport_9_16_assetId)?.storageUrl ?? null
        : null
    ),
    "16:9": previewUrlFor(
      pipelineJob?.captionedExport_16_9_assetId,
      pipelineJob?.captionedExport_16_9_assetId
        ? assets.find((a) => a.id === pipelineJob.captionedExport_16_9_assetId)?.storageUrl ?? null
        : null
    ),
    "1:1": previewUrlFor(
      pipelineJob?.captionedExport_1_1_assetId,
      pipelineJob?.captionedExport_1_1_assetId
        ? assets.find((a) => a.id === pipelineJob.captionedExport_1_1_assetId)?.storageUrl ?? null
        : null
    ),
    "4:5": previewUrlFor(
      pipelineJob?.captionedExport_4_5_assetId,
      pipelineJob?.captionedExport_4_5_assetId
        ? assets.find((a) => a.id === pipelineJob.captionedExport_4_5_assetId)?.storageUrl ?? null
        : null
    ),
  };
  const captionedAssetIdByRatio: Record<string, string | null> = {
    "9:16": pipelineJob?.captionedExport_9_16_assetId ?? null,
    "16:9": pipelineJob?.captionedExport_16_9_assetId ?? null,
    "1:1": pipelineJob?.captionedExport_1_1_assetId ?? null,
    "4:5": pipelineJob?.captionedExport_4_5_assetId ?? null,
  };
  // Header UI language — drives the auto-generated per-channel post copy so it
  // follows the language shown in the header.
  const serverLocale = getServerLocale();

  // ── RClipper Management (optional add-on) ─────────────────────────────────
  // Per-video transfer state resolved on the SERVER: whether Management is on
  // for this user, and which of these videos are already in it. Transferring is
  // FREE and optional (payment appears later, in the composer), and when the
  // feature is off the panel renders no transfer controls at all, leaving the
  // download-only step completely unchanged.
  const managementTransfer = await timed("management", () =>
    buildDistributionTransferView(user, request.id)
  );
  const channelVideos = (request.targetPlatforms ?? [])
    .filter((p) => p !== Platform.TravyApp)
    .map((p) => {
      const ratio = PLATFORM_ASPECT_RATIOS[p as Platform] ?? null;
      return {
        platform: p as string,
        label: PLATFORM_LABELS[p as Platform] ?? (p as string),
        ratio,
        url: ratio ? captionedUrlByRatio[ratio] ?? null : null,
        assetId: ratio ? captionedAssetIdByRatio[ratio] ?? null : null,
      };
    });
  const sourceAssets = assets.filter(
    (a) =>
      a.uploadStatus === AssetUploadStatus.Uploaded &&
      (a.assetType === AssetType.Image || a.assetType === AssetType.Video)
  );
  // Canonical, index-stable ordering (images + clips) shared by the montage
  // scene panels and the renderer — index N is the same media everywhere.
  const orderedSourceAssets = orderSourceAssets(assets);
  const sourceImageOptions = sourceAssets
    .map((asset, sourceIndex) => ({ asset, sourceIndex }))
    .filter(({ asset }) => asset.assetType === AssetType.Image)
    .map(({ asset, sourceIndex }) => ({
      sourceIndex,
      id: asset.id,
      fileName: asset.fileName,
      thumbnailUrl: asset.thumbnailUrl,
      storageUrl: asset.storageUrl,
    }));

  // Canonical ordering for storyboard/montage thumbnails — an index here is the
  // same asset everywhere (storyboard, scene design, renderer).
  const storyboardAssets = orderSourceAssets(assets).map((a) => ({
    index: a.index,
    thumbnailUrl: a.thumbnailUrl,
    kind: a.kind,
    fileName: a.fileName,
    durationSeconds: a.durationSeconds ?? null,
  }));

  const view = requestPresentationService.buildRequestView(
    request,
    assets,
    publishingLinks,
    statusHistory,
    pipelineJob?.currentStep ?? null
  );

  const isDraft = request.status === RequestStatus.Draft;

  return (
    <div className="mx-auto w-full min-w-0 max-w-3xl px-4 py-6 sm:px-6 sm:py-10">
      {/* Breadcrumb */}
      <nav className="mb-6 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-slate-500">
        <Link href={ROUTES.DASHBOARD} className="hover:text-slate-700">
          Dashboard
        </Link>
        <span>/</span>
        <Link href={ROUTES.REQUESTS} className="hover:text-slate-700">
          My Requests
        </Link>
        <span>/</span>
        <span className="text-slate-700 font-medium truncate max-w-[200px]">
          {view.title}
        </span>
      </nav>

      {/* Title + Status */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
        <div className="min-w-0">
          <h1 className="break-words text-xl font-bold text-slate-900 sm:text-2xl">
            {view.title}
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            {view.submittedAt
              ? `Submitted ${view.submittedAt.toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}`
              : `Created ${view.createdAt.toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}`}
          </p>
        </div>
        <RequestStatusBadge status={view.status} />
      </div>

      {/* Status description */}
      <Card className="mb-6">
        <p className="text-sm font-medium text-slate-700">
          {pipelineJob?.currentStep === VideoGenerationStep.AwaitingContentApproval
            ? "AI วิเคราะห์เนื้อหาเสร็จแล้ว — ตรวจสอบและแก้ไขสคริปต์ด้านล่าง แล้วคลิกอนุมัติเพื่อเริ่มสร้างเสียงพากย์"
            : view.statusPresentation.description}
        </p>

        {/* Retention notes — inline text only (no email/popup) */}
        <RetentionNoteText
          note={finalClipAvailabilityNote(request)}
          className="mt-2 font-medium"
        />
        <RetentionNoteText note={inactivityNote(request)} className="mt-2" />

        {/* Queue info — hide while awaiting AI approval */}
        {view.queueDisplay.show && pipelineJob?.currentStep !== VideoGenerationStep.AwaitingContentApproval && (
          <p className="mt-2 text-sm text-slate-500">{view.queueDisplay.message}</p>
        )}

        {/* Pipeline progress — shown during production */}
        {view.pipelineProgress && (
          <div className="mt-3 rounded-lg border border-blue-100 bg-blue-50 px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
              <p className="text-sm font-semibold text-blue-800">{view.pipelineProgress.label}</p>
            </div>
            <p className="mt-1 text-xs text-blue-600">{view.pipelineProgress.description}</p>
          </div>
        )}

        {/* Due date */}
        <DueDateDisplay
          display={view.dueDateDisplay}
          className="mt-3"
        />

        {/* Hold reason */}
        {request.status === RequestStatus.OnHold && view.holdReason && (
          <div className="mt-4 rounded-lg border border-yellow-200 bg-yellow-50 p-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-yellow-700">
              On Hold — Reason
            </p>
            <p className="mt-1 text-sm text-yellow-800">{view.holdReason}</p>
          </div>
        )}

        {/* Rejection reason */}
        {request.status === RequestStatus.Rejected && view.rejectionReason && (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-red-700">
              Rejected — Reason
            </p>
            <p className="mt-1 text-sm text-red-800">{view.rejectionReason}</p>
          </div>
        )}
      </Card>

      {/*
        This request's originals never left the requester's phone, so its render
        steps are device_only and no worker will ever claim them. The renderer
        below is what makes them happen; it is inert on any other device, and
        absent entirely for the server-rendered requests that are still the
        default.
      */}
      {request.renderLocation === "device" &&
        pipelineJob &&
        pipelineJob.currentStep !== VideoGenerationStep.Complete && (
          <DeviceRenderRunner requestId={id} />
        )}

      {/* Re-analyze prompt — shown when request is submitted but no pipeline job exists yet */}
      {request.status === RequestStatus.Submitted && !pipelineJob && (
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <p className="text-sm font-semibold text-blue-800">
            สร้างสคริปต์วิดีโอด้วย AI
          </p>
          <p className="mt-1 text-sm text-blue-700">
            AI จะวิเคราะห์รูปภาพที่อัพโหลดและสร้างแผนฉาก บทพูด และแคปชั่นสำหรับวิดีโอ 15 วินาที
            จากนั้นคุณสามารถแก้ไขและอนุมัติก่อนเริ่มสร้างเสียงพากย์ได้
          </p>
          <div className="mt-4">
            <AnalyzeButton requestId={id} />
          </div>
        </Card>
      )}

      {/* Draft actions */}
      {isDraft && (
        <div className="mb-6 flex gap-3">
          <Link href={`${ROUTES.REQUESTS_NEW}?edit=${id}`}>
            <button className="rounded-md border border-blue-600 px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50">
              Continue Editing
            </button>
          </Link>
        </div>
      )}

      {/* Production pipeline — shown when an AI pipeline job exists */}
      {pipelineJob && (() => {
        const isAwaitingApproval =
          pipelineJob.currentStep === VideoGenerationStep.AwaitingContentApproval;
        const isFailed = pipelineJob.currentStep === VideoGenerationStep.Failed;
        // Audio-first reorder: voice generation now runs before video generation,
        // so a GeneratingVoice failure happens before any base video exists.
        // Handled by the generic PipelineFailurePanel retry flow below.
        const isAwaitingVoiceApproval =
          pipelineJob.currentStep === VideoGenerationStep.AwaitingVoiceApproval;
        const isGeneratingSceneDesign =
          pipelineJob.currentStep === VideoGenerationStep.GeneratingSceneDesign;
        const isAwaitingSceneDesignApproval =
          pipelineJob.currentStep === VideoGenerationStep.AwaitingSceneDesignApproval;
        const isAwaitingSceneScriptApproval =
          pipelineJob.currentStep === VideoGenerationStep.AwaitingSceneScriptApproval;
        // Phase 8 — distribution-review step (auto-filled per-channel publish form).
        const isAwaitingDistributionReview =
          pipelineJob.currentStep === VideoGenerationStep.AwaitingDistributionReview;
        // Express lane (scene-plan "approve everything from here"): the
        // remaining gates are cleared by the server, so the requester must see
        // progress — not approval buttons that vanish under their cursor mid-click.
        const autoApproveRemaining = pipelineJob.autoApproveRemaining === true;
        const autoAdvancingGate =
          autoApproveRemaining && isAutoApprovedGate(pipelineJob.currentStep);

        // Steps where an async background job is genuinely in progress — drives the
        // VideoApprovalPanel processing spinner (must NOT show at terminal/review
        // states like Complete/Delivered/AwaitingDistributionReview).
        const isProcessing =
          [
            VideoGenerationStep.GeneratingVoice,
            VideoGenerationStep.GeneratingBaseVideo,
            VideoGenerationStep.GeneratingAnimations,
            VideoGenerationStep.ComposingFinalVideo,
            VideoGenerationStep.GeneratingOverlay,
            VideoGenerationStep.GeneratingAdditionalRatios,
          ].includes(pipelineJob.currentStep) || autoAdvancingGate;
        const effectiveDurationSeconds = Math.round(
          pipelineJob.voiceDurationSeconds ?? request.durationSeconds
        );

        // Progressive per-ratio reveal: how many distribution-channel ratios the
        // compose step must produce, and how many have already landed. These drive
        // live polling during AwaitingFinalApproval so the remaining ratios appear
        // as they finish, without a manual reload.
        const requiredRatioCount = getRequiredRatiosForPlatforms(
          request.targetPlatforms
        ).length;
        const readyRatioCount = [
          pipelineJob.finalExport_9_16_assetId,
          pipelineJob.finalExport_16_9_assetId,
          pipelineJob.finalExport_1_1_assetId,
          pipelineJob.finalExport_4_5_assetId,
        ].filter(Boolean).length;

        // Progressive per-CHANNEL reveal (GeneratingAdditionalRatios): the step
        // must produce a CAPTIONED export per user ratio (primary included —
        // already rendered at the overlay step, so it counts as ready). While
        // ready < required, the poller refreshes as each channel's video lands.
        const nonTravyPlatforms = (request.targetPlatforms ?? []).filter(
          (p) => p !== Platform.TravyApp
        );
        const userRatios = getRequiredRatiosForPlatforms(
          nonTravyPlatforms.length > 0
            ? nonTravyPlatforms
            : request.targetPlatforms ?? []
        );
        const requiredCaptionedCount = userRatios.length;
        const readyCaptionedCount = userRatios.filter(
          (r) => captionedAssetIdByRatio[r]
        ).length;

        // Stranded on a processing step past its threshold → offer a manual retry
        // (never auto-fails; a legitimately long render just keeps loading). The
        // active render task (if any) tells isJobStalled a worker is progressing.
        const stalled = isJobStalled(pipelineJob, activeRenderTask);

        // Parse scene plan — prefer approved version; fall back to raw AI output
        let scenePlan: ScenePlan[] = [];
        const scenePlanSrc = pipelineJob.approvedScenePlan ?? pipelineJob.scenePlan;
        if (scenePlanSrc) {
          try { scenePlan = JSON.parse(scenePlanSrc); } catch { /* ignore */ }
        }

        // Parse the Stage-1 storyboard — prefer approved; fall back to generated.
        let storyboard: StoryboardScene[] = [];
        const storyboardSrc = pipelineJob.approvedStoryboard ?? pipelineJob.storyboard;
        if (storyboardSrc) {
          try { storyboard = JSON.parse(storyboardSrc); } catch { /* ignore */ }
        }
        const completedSceneVideoCount =
          pipelineJob.sceneVideoAssetIds?.filter((assetId) => Boolean(assetId)).length ?? 0;
        const activeSceneIndex = Math.min(
          Math.max(
            pipelineJob.currentStep === VideoGenerationStep.AwaitingSceneDesignApproval
              ? completedSceneVideoCount
              : Math.max(completedSceneVideoCount - 1, 0),
            0
          ),
          Math.max(scenePlan.length - 1, 0)
        );

        // Requester must approve before video generation starts — show editable script panel
        if (isAwaitingApproval) {
          return (
            <>
              <PipelineSection
                requestId={id}
                currentStep={pipelineJob.currentStep}
                failedAtStep={pipelineJob.failedAtStep}
                durationSeconds={effectiveDurationSeconds}
                totalChannels={request.targetPlatforms.length}
              />
              <ContentApprovalPanel
                requestId={id}
                initialScriptThai={pipelineJob.scriptThai}
                initialScriptEnglish={pipelineJob.scriptEnglish}
                initialCaptionThai={pipelineJob.captionThai}
                initialCaptionEnglish={pipelineJob.captionEnglish}
                initialCaptionChinese={pipelineJob.captionChinese}
                storyboard={storyboard}
                storyboardAssets={storyboardAssets}
              />
            </>
          );
        }

        if (isAwaitingSceneDesignApproval) {
          return (
            <>
              <PipelineSection
                requestId={id}
                currentStep={pipelineJob.currentStep}
                failedAtStep={pipelineJob.failedAtStep}
                durationSeconds={effectiveDurationSeconds}
                totalChannels={request.targetPlatforms.length}
              />
              <SceneDesignApprovalPanel
                requestId={id}
                jobId={pipelineJob.id}
                initialScenes={scenePlan}
                scriptThai={pipelineJob.approvedScriptThai ?? pipelineJob.scriptThai}
                initialDurationSeconds={effectiveDurationSeconds}
                voiceDurationSeconds={pipelineJob.voiceDurationSeconds}
                voiceRecordingUrl={voiceRecordingAsset?.storageUrl ?? null}
                voiceRecordingAssetId={voiceRecordingAsset?.id ?? null}
                totalChannels={request.targetPlatforms.length}
                primaryAspectRatio={primaryRatio}
                sourceAssets={sourceAssets}
                orderedAssets={orderedSourceAssets}
                activeSceneIndex={activeSceneIndex}
                savedMusicTrack={pipelineJob.selectedMusicTrack ?? null}
                savedSubtitleLanguages={pipelineJob.subtitleLanguages}
                savedTemplate={pipelineJob.selectedMotionTemplate ?? "none"}
              />
            </>
          );
        }

        if (isAwaitingSceneScriptApproval) {
          return (
            <>
              <PipelineSection
                requestId={id}
                currentStep={pipelineJob.currentStep}
                failedAtStep={pipelineJob.failedAtStep}
                durationSeconds={effectiveDurationSeconds}
                totalChannels={request.targetPlatforms.length}
              />
              <SceneScriptApprovalPanel
                requestId={id}
                jobId={pipelineJob.id}
                initialScenes={scenePlan}
                scriptThai={pipelineJob.approvedScriptThai ?? pipelineJob.scriptThai}
                hookThai={pipelineJob.approvedHookThai ?? pipelineJob.hookThai}
                captionThai={pipelineJob.approvedCaptionThai ?? pipelineJob.captionThai}
                activeSceneIndex={pipelineJob.currentSceneIndex ?? 0}
                voiceRecordingUrl={voiceRecordingAsset?.storageUrl ?? null}
                voiceRecordingAssetId={voiceRecordingAsset?.id ?? null}
                latestVideoUrl={latestVideoAsset?.storageUrl ?? null}
                latestVideoAssetId={latestVideoAsset?.id ?? null}
                sourceAssets={sourceAssets}
                orderedAssets={orderedSourceAssets}
              />
            </>
          );
        }

        return (
          <>
            <PipelineSection
              requestId={id}
              currentStep={pipelineJob.currentStep}
              failedAtStep={pipelineJob.failedAtStep}
              durationSeconds={effectiveDurationSeconds}
              totalChannels={request.targetPlatforms.length}
              travyVideoStatus={pipelineJob.travyVideoStatus ?? null}
              requiredRatioCount={requiredRatioCount}
              readyRatioCount={readyRatioCount}
              requiredCaptionedCount={requiredCaptionedCount}
              readyCaptionedCount={readyCaptionedCount}
              initialRenderProgress={pipelineJob.renderProgress ?? null}
              initialRenderProgressDetail={pipelineJob.renderProgressDetail ?? null}
              stalled={stalled}
              autoApproveRemaining={autoApproveRemaining}
            />

            {!isFailed && isGeneratingSceneDesign && (
              <SceneDesignGeneratingPanel voiceDurationSeconds={pipelineJob.voiceDurationSeconds} />
            )}

            {/* Voice approval + script — shown once voice generation completes,
                before the base video exists (audio-first reorder). The approved
                storyboard is shown read-only so the requester can picture the
                story while judging the voiceover. */}
            {!isFailed && isAwaitingVoiceApproval && storyboard.length > 0 && (
              <div className="mb-6">
                <StoryboardView
                  scenes={storyboard}
                  assets={storyboardAssets}
                  subtitle="ภาพรวมฉากที่อนุมัติแล้ว — ใช้จินตนาการเรื่องราวขณะฟังเสียงพากย์"
                />
              </div>
            )}
            {!isFailed && isAwaitingVoiceApproval && (
              <VideoApprovalPanel
                requestId={id}
                jobId={pipelineJob.id}
                videoUrl={baseVideoAsset?.storageUrl ?? null}
                isAwaitingApproval={false}
                isAwaitingVoiceApproval
                isAwaitingAnimationApproval={false}
                isPipelineFailed={isFailed}
                isGeneratingVoice={false}
                animatedVideoUrl={animatedVideoAsset?.storageUrl ?? null}
                savedMusicTrack={pipelineJob.selectedMusicTrack ?? null}
                isAwaitingFinalApproval={false}
                voiceRecordingUrl={voiceRecordingAsset?.storageUrl ?? null}
                voiceRecordingAssetId={voiceRecordingAsset?.id ?? null}
                selectedVoiceId={pipelineJob.rvcVoiceModel}
                finalClips={finalClips}
                scenes={scenePlan}
                storyboard={storyboard}
                hookThai={pipelineJob.approvedHookThai ?? pipelineJob.hookThai}
                hookEnglish={pipelineJob.approvedHookEnglish ?? pipelineJob.hookEnglish}
                scriptThai={pipelineJob.approvedScriptThai ?? pipelineJob.scriptThai}
                scriptEnglish={pipelineJob.approvedScriptEnglish ?? pipelineJob.scriptEnglish}
                captionThai={pipelineJob.approvedCaptionThai ?? pipelineJob.captionThai}
                captionEnglish={pipelineJob.approvedCaptionEnglish ?? pipelineJob.captionEnglish}
                captionChinese={pipelineJob.approvedCaptionChinese ?? pipelineJob.captionChinese}
                sourceAssets={sourceAssets}
                orderedAssets={orderedSourceAssets}
                activeSceneIndex={activeSceneIndex}
              />
            )}

            {/* Phase 8 — distribution review: auto-filled per-channel publish form */}
            {!isFailed && isAwaitingDistributionReview && (
              <DistributionReviewPanel
                requestId={id}
                jobId={pipelineJob.id}
                placeName={request.placeName}
                initialDrafts={pipelineJob.publishingDrafts ?? []}
                channelVideos={channelVideos}
                locale={serverLocale}
                travyVideoStatus={pipelineJob.travyVideoStatus ?? null}
                travyVideoError={pipelineJob.travyVideoError ?? null}
                travyClipUrl={travyClipUrl}
                travyAssetId={pipelineJob.finalExport_travy_assetId ?? null}
                downloadLocked={downloadLocked}
                mediaExpired={finalClipAvailabilityNote(request)?.tone === "expired"}
                managementEnabled={managementTransfer.enabled}
                transferredByAssetId={managementTransfer.transferredByAssetId}
              />
            )}

            {/* Generated base video + script — shown once video generation completes.
                On an express-lane job every review gate below (scene clips /
                merge-and-music / final / overlay / additional-ratios) is passed
                `false`: the server
                approves them itself, so the requester gets the processing spinner
                instead of buttons that vanish under their cursor. */}
            {!isFailed && !isAwaitingVoiceApproval && !isAwaitingDistributionReview && baseVideoAsset?.storageUrl && (
              <VideoApprovalPanel
                requestId={id}
                jobId={pipelineJob.id}
                videoUrl={baseVideoAsset.storageUrl}
                sceneVideos={sceneVideos}
                isProcessing={isProcessing}
                isAutoAdvancing={autoAdvancingGate}
                isAwaitingApproval={
                  !autoApproveRemaining &&
                  pipelineJob.currentStep === VideoGenerationStep.AwaitingVideoApproval
                }
                isAwaitingVoiceApproval={false}
                isAwaitingAnimationApproval={
                  !autoApproveRemaining &&
                  pipelineJob.currentStep === VideoGenerationStep.AwaitingAnimationApproval
                }
                isPipelineFailed={isFailed}
                isGeneratingVoice={false}
                animatedVideoUrl={animatedVideoAsset?.storageUrl ?? null}
                savedMusicTrack={pipelineJob.selectedMusicTrack ?? null}
                primaryRatio={primaryRatio}
                isAwaitingFinalApproval={
                  !autoApproveRemaining &&
                  pipelineJob.currentStep === VideoGenerationStep.AwaitingFinalApproval
                }
                isAwaitingOverlayApproval={
                  !autoApproveRemaining &&
                  pipelineJob.currentStep === VideoGenerationStep.AwaitingOverlayApproval
                }
                isGeneratingOverlay={
                  pipelineJob.currentStep === VideoGenerationStep.GeneratingOverlay
                }
                isAwaitingAdditionalRatios={
                  !autoApproveRemaining &&
                  pipelineJob.currentStep === VideoGenerationStep.AwaitingAdditionalRatios
                }
                isGeneratingAdditionalRatios={
                  pipelineJob.currentStep === VideoGenerationStep.GeneratingAdditionalRatios
                }
                channelVideos={channelVideos}
                overlayPreviewUrl={overlayPreviewUrl}
                savedSubtitleLanguages={pipelineJob.subtitleLanguages}
                savedTemplate={pipelineJob.selectedMotionTemplate ?? "none"}
                travyVideoStatus={pipelineJob.travyVideoStatus ?? null}
                travyVideoError={pipelineJob.travyVideoError ?? null}
                travyClipUrl={travyClipUrl}
                voiceRecordingUrl={voiceRecordingAsset?.storageUrl ?? null}
                voiceRecordingAssetId={voiceRecordingAsset?.id ?? null}
                finalClips={finalClips}
                scenes={scenePlan}
                storyboard={storyboard}
                hookThai={pipelineJob.approvedHookThai ?? pipelineJob.hookThai}
                hookEnglish={pipelineJob.approvedHookEnglish ?? pipelineJob.hookEnglish}
                scriptThai={pipelineJob.approvedScriptThai ?? pipelineJob.scriptThai}
                scriptEnglish={pipelineJob.approvedScriptEnglish ?? pipelineJob.scriptEnglish}
                captionThai={pipelineJob.approvedCaptionThai ?? pipelineJob.captionThai}
                captionEnglish={pipelineJob.approvedCaptionEnglish ?? pipelineJob.captionEnglish}
                captionChinese={pipelineJob.approvedCaptionChinese ?? pipelineJob.captionChinese}
                sourceAssets={sourceAssets}
                orderedAssets={orderedSourceAssets}
                activeSceneIndex={activeSceneIndex}
              />
            )}

            {/* Error recovery — shown when the pipeline has failed */}
            {isFailed && (
              <PipelineFailurePanel
                requestId={id}
                jobId={pipelineJob.id}
                failedAtStep={pipelineJob.failedAtStep}
                scenePlan={scenePlan}
                sourceImages={sourceImageOptions}
                voiceRecordingUrl={voiceRecordingAsset?.storageUrl ?? null}
                scriptThai={pipelineJob.approvedScriptThai}
                hookThai={pipelineJob.approvedHookThai}
              />
            )}
          </>
        );
      })()}

      {/* Published links — only shown if this clip has been featured on an
          RClipper channel (a staff/admin curation action). RClipper does not
          auto-publish the requester's clip to their channels. */}
      {publishingLinks.length > 0 && (
        <Card className="mb-6">
          <h2 className="mb-4 text-base font-semibold text-slate-900">
            Featured On
          </h2>
          <DeliveryLinks links={publishingLinks} />
          <p className="mt-4 text-xs text-slate-400">
            The final edited clip remains the property of RClipper.
          </p>
        </Card>
      )}

      {/* Brief details */}
      <Card className="mb-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">
          Request Brief
        </h2>
        <dl className="flex flex-col gap-4">
          <BriefRow label="ชื่อสถานที่" value={view.placeName} />
          {view.latitude !== null && view.longitude !== null && (
            <div>
              <dt className="text-xs font-medium uppercase tracking-wide text-slate-400">
                ตำแหน่ง
              </dt>
              <dd className="mt-1">
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${view.latitude},${view.longitude}`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm tabular-nums text-blue-600 hover:underline"
                >
                  {view.latitude.toFixed(6)}, {view.longitude.toFixed(6)}
                </a>
              </dd>
            </div>
          )}
          <BriefRow label="Description" value={view.description} />
          <BriefRow label="Target audience" value={view.targetAudience} />
          <BriefRow
            label="Target platforms"
            value={view.targetPlatforms.join(", ")}
          />
          <BriefRow label="Preferred style" value={view.preferredStyle} />
        </dl>
        <div className="mt-4 border-t border-slate-100 pt-4 text-xs text-slate-400">
          Credits used: {view.creditsCost} · Request ID: {view.id}
        </div>
      </Card>

      {/* Source files */}
      <Card className="mb-6">
        <h2 className="mb-2 text-base font-semibold text-slate-900">
          Source Files
        </h2>
        <p className="mb-4 text-xs text-slate-500">
          {uploadedMaterialsNote().text}
        </p>
        {/* Only CONFIRMED uploads are source files. This used to show everything
            that wasn't Deleted, which meant every Pending record — one per
            abandoned upload attempt — appeared here as a file that looked
            half-uploaded and could never finish. A Pending row is an attempt,
            not a file; the upload UI is where in-flight progress belongs. */}
        {sourceAssets.length === 0 ? (
          <p className="text-sm text-slate-400">No source files attached.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {sourceAssets.map((asset) => {
                const thumbSrc = asset.thumbnailUrl || (asset.assetType === AssetType.Image ? asset.storageUrl : "");
                return (
                  <li
                    key={asset.id}
                    className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3 py-2"
                  >
                    <div className="flex items-center gap-3">
                      {thumbSrc ? (
                        // Cloud-stored poster (images, and videos uploaded after
                        // thumbnail support). Prefer this whenever present.
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={thumbSrc}
                          alt={asset.fileName}
                          className="h-12 w-12 flex-shrink-0 rounded-md border border-slate-200 object-cover"
                        />
                      ) : asset.assetType === AssetType.Video ? (
                        // No stored poster (e.g. clips uploaded before thumbnail
                        // support, or when extraction was unavailable): let the
                        // browser render a real frame from the clip itself. The
                        // `#t=0.5` media fragment seeks ~0.5s in to avoid a black
                        // first frame; preload="metadata" keeps it cheap.
                        <video
                          src={`${asset.storageUrl}#t=0.5`}
                          preload="metadata"
                          muted
                          playsInline
                          className="h-12 w-12 flex-shrink-0 rounded-md border border-slate-200 object-cover bg-black"
                        />
                      ) : (
                        <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-md border border-slate-200 bg-slate-100 text-slate-400">
                          <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5">
                            <path d="M4 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4zm0 2h16v8.59l-3.3-3.3a1 1 0 0 0-1.4 0L11 17.59l-2.3-2.3a1 1 0 0 0-1.4 0L4 18.59V6z" />
                          </svg>
                        </div>
                      )}
                      <div>
                        <p className="text-sm text-slate-800">{asset.fileName}</p>
                        <p className="text-xs text-slate-400">
                          {asset.assetType} ·{" "}
                          {(asset.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB · Deletion
                          scheduled{" "}
                          {asset.scheduledDeletionAt.toLocaleDateString("en-GB", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs capitalize text-slate-500">
                      {asset.uploadStatus}
                    </span>
                  </li>
                );
              })}
          </ul>
        )}
      </Card>

      {/* Status timeline */}
      <Card className="mb-6">
        <h2 className="mb-4 text-base font-semibold text-slate-900">
          Status History
        </h2>
        <RequestTimeline entries={timelineEntries} />
      </Card>

      {/* Legal reminder */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-500">
        <p>
          <strong>Ownership reminder:</strong> The final edited clip produced for this
          request is the property of RClipper. You are free to repost and share the
          delivered clip on your own channels. Uploaded source materials are retained
          for production purposes only and will be deleted per our 90-day storage
          policy.{" "}
          <Link href={ROUTES.LEGAL} className="text-blue-600 hover:underline">
            View full policy →
          </Link>
        </p>
      </div>
    </div>
  );
}

function BriefRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">
        {label}
      </dt>
      <dd className="mt-0.5 text-sm text-slate-800">{value}</dd>
    </div>
  );
}
