import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/authOptions";
import { Role } from "@/domain/enums/Role";
import { uploadService } from "@/services/UploadService";
import { clipRequestService } from "@/services/ClipRequestService";
import { MAX_UPLOAD_COUNT } from "@/domain/enums/AssetType";

/**
 * POST /api/uploads/[requestId]/multipart
 *
 * Chunked (multipart) sibling of the single-PUT presign flow. Large files —
 * notably videos over ~5 MB — cannot go up as one PUT because an HTTPS-inspecting
 * network intermediary rejects any single request body over ~8–15 MB (see
 * lib/spaces.ts); the browser sees the intermediary's non-CORS error as the
 * opaque "Failed to fetch". Splitting the upload into ≤5 MB parts keeps every
 * request under that cap.
 *
 * One route, four actions (dispatched on body.action):
 *   initiate → { assetId, key, uploadId, partSize }   (creates tmp/ MPU + Pending asset)
 *   resume   → { uploadedParts: [{ PartNumber, ETag }], expired? } (parts already stored)
 *   sign     → { parts: [{ partNumber, url }] }        (presigned UploadPart URLs)
 *   complete → { ok: true }                            (assembles the object; then call /confirm)
 *   abort    → { ok: true }                            (best-effort cleanup)
 *
 * RESUME lets a dropped upload (common on mobile) continue: the client asks which
 * parts already landed (`resume`), then `sign`s only the missing part numbers.
 *
 * After `complete`, the object sits at the tmp/ key exactly as a single PUT would
 * leave it, so the client finishes with the existing POST /confirm.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ requestId: string }> }
) {
  const { requestId } = await params;
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }
  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const userId = session.user.id;

  // Ownership: the request must belong to this user.
  try {
    await clipRequestService.getOwnedRequest(requestId, userId);
  } catch {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const action = body.action;

  // Any action operating on an existing key must prove that key belongs to this
  // user AND this request, so a signed part URL can't be minted for someone
  // else's object. tmp key shape: tmp/{userId}/{date}/{requestId}/{uuid}-{name}.
  const keyBelongsToCaller = (key: unknown): key is string =>
    typeof key === "string" &&
    key.startsWith(`tmp/${userId}/`) &&
    key.includes(`/${requestId}/`);

  try {
    if (action === "initiate") {
      const { fileName, fileSizeBytes, mimeType } = body as {
        fileName?: unknown;
        fileSizeBytes?: unknown;
        mimeType?: unknown;
      };
      if (
        typeof fileName !== "string" ||
        typeof fileSizeBytes !== "number" ||
        typeof mimeType !== "string"
      ) {
        return NextResponse.json(
          { error: "Missing fields: fileName (string), fileSizeBytes (number), mimeType (string)." },
          { status: 400 }
        );
      }
      if (fileSizeBytes <= 0) {
        return NextResponse.json({ error: "Invalid file size." }, { status: 400 });
      }

      // Same guards as the single-PUT presign route: file count, type, per-file
      // and per-request total size.
      const currentCount = await uploadService.countAssets(requestId);
      if (currentCount >= MAX_UPLOAD_COUNT) {
        // As in the single-PUT route: a silent 422 left no server-side record of
        // a file the server itself refused, so "this clip will not upload" had
        // nothing in the logs to explain it.
        console.warn(
          `[upload:422] request=${requestId} reason=count currentCount=${currentCount}/${MAX_UPLOAD_COUNT}`
        );
        return NextResponse.json(
          { error: `Maximum ${MAX_UPLOAD_COUNT} files per request.` },
          { status: 422 }
        );
      }
      const existingBytes = await uploadService.sumUploadedBytes(requestId);
      const validation = uploadService.validateFile(
        { name: fileName, size: fileSizeBytes, type: mimeType },
        currentCount,
        existingBytes
      );
      if (!validation.valid) {
        console.warn(
          `[upload:422] request=${requestId} file="${fileName}" ` +
            `size=${fileSizeBytes}B type=${mimeType} existingBytes=${existingBytes}B ` +
            `reason=${validation.error}`
        );
        return NextResponse.json({ error: validation.error }, { status: 422 });
      }
      // Positive trace too: without it the log cannot distinguish "the client
      // never asked to upload this file" from "it asked and the PUTs failed",
      // which is exactly the gap that made the browser→Spaces leg invisible.
      console.info(
        `[upload:initiate] request=${requestId} file="${fileName}" size=${fileSizeBytes}B`
      );

      const result = await uploadService.createMultipartUpload({
        requestId,
        userId,
        fileName,
        fileSizeBytes,
        mimeType,
      });
      return NextResponse.json(result, { status: 201 });
    }

    if (action === "resume") {
      const { key, uploadId } = body as { key?: unknown; uploadId?: unknown };
      if (!keyBelongsToCaller(key) || typeof uploadId !== "string") {
        return NextResponse.json({ error: "Invalid key or uploadId." }, { status: 400 });
      }
      try {
        const uploadedParts = await uploadService.listUploadedParts({ key, uploadId });
        return NextResponse.json({ uploadedParts }, { status: 200 });
      } catch (err) {
        // Unknown/expired/aborted upload id → tell the client to start fresh
        // rather than surface a 500 for an ordinary "session gone" case.
        if (err instanceof Error && err.name === "NoSuchUpload") {
          return NextResponse.json({ uploadedParts: [], expired: true }, { status: 200 });
        }
        throw err;
      }
    }

    if (action === "sign") {
      const { key, uploadId, partCount, partNumbers } = body as {
        key?: unknown;
        uploadId?: unknown;
        partCount?: unknown;
        partNumbers?: unknown;
      };
      if (!keyBelongsToCaller(key) || typeof uploadId !== "string") {
        return NextResponse.json({ error: "Invalid key or uploadId." }, { status: 400 });
      }

      // RESUME path signs an explicit list of the still-missing part numbers; the
      // fresh path signs a contiguous 1..partCount range.
      if (Array.isArray(partNumbers)) {
        if (
          partNumbers.length === 0 ||
          partNumbers.length > 10_000 ||
          !partNumbers.every(
            (n) => typeof n === "number" && Number.isInteger(n) && n >= 1 && n <= 10_000
          )
        ) {
          return NextResponse.json({ error: "Invalid partNumbers (1–10000)." }, { status: 400 });
        }
        const parts = await uploadService.signUploadParts({
          key,
          uploadId,
          partNumbers: partNumbers as number[],
        });
        return NextResponse.json({ parts }, { status: 200 });
      }

      if (typeof partCount !== "number" || partCount < 1 || partCount > 10_000) {
        return NextResponse.json(
          { error: "Provide partCount (1–10000) or partNumbers[]." },
          { status: 400 }
        );
      }
      const parts = await uploadService.signUploadParts({ key, uploadId, partCount });
      return NextResponse.json({ parts }, { status: 200 });
    }

    if (action === "complete") {
      const { key, uploadId, parts } = body as {
        key?: unknown;
        uploadId?: unknown;
        parts?: unknown;
      };
      if (!keyBelongsToCaller(key) || typeof uploadId !== "string") {
        return NextResponse.json({ error: "Invalid key or uploadId." }, { status: 400 });
      }
      if (
        !Array.isArray(parts) ||
        parts.length === 0 ||
        !parts.every(
          (p) =>
            p &&
            typeof p.PartNumber === "number" &&
            typeof p.ETag === "string" &&
            p.ETag.length > 0
        )
      ) {
        return NextResponse.json({ error: "Invalid parts array." }, { status: 400 });
      }
      await uploadService.completeMultipartUpload({
        key,
        uploadId,
        parts: parts as { PartNumber: number; ETag: string }[],
      });
      return NextResponse.json({ ok: true }, { status: 200 });
    }

    if (action === "abort") {
      const { key, uploadId } = body as { key?: unknown; uploadId?: unknown };
      if (!keyBelongsToCaller(key) || typeof uploadId !== "string") {
        return NextResponse.json({ error: "Invalid key or uploadId." }, { status: 400 });
      }
      await uploadService.abortMultipartUpload({ key, uploadId });
      return NextResponse.json({ ok: true }, { status: 200 });
    }

    return NextResponse.json(
      { error: "Unknown action. Expected initiate | sign | complete | abort." },
      { status: 400 }
    );
  } catch (err) {
    console.error(`[POST /api/uploads/[requestId]/multipart] action=${String(action)}`, err);
    return NextResponse.json({ error: "Multipart upload operation failed." }, { status: 500 });
  }
}
