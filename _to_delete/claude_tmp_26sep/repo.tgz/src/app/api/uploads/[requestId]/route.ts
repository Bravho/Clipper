import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/authOptions";
import { Role } from "@/domain/enums/Role";
import { uploadService } from "@/services/UploadService";
import { clipRequestService } from "@/services/ClipRequestService";
import { MAX_UPLOAD_COUNT, AssetUploadStatus } from "@/domain/enums/AssetType";

/**
 * GET /api/uploads/[requestId]
 *
 * Reconciliation endpoint for the RESUME flow. Returns the request's current
 * status plus its non-deleted assets, so the client can — on re-entry after a
 * dropped connection or the app being backgrounded/killed on iOS/Android — show
 * which files already made it and re-upload only the rest.
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ requestId: string }> }
) {
  const { requestId } = await params;
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }
  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  let status: string;
  try {
    const req = await clipRequestService.getOwnedRequest(requestId, session.user.id);
    status = req.status;
  } catch {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  const assets = await uploadService.getAssets(requestId);
  return NextResponse.json({
    status,
    assets: assets
      .filter((a) => a.uploadStatus !== AssetUploadStatus.Deleted)
      .map((a) => ({
        id: a.id,
        fileName: a.fileName,
        fileSizeBytes: Number(a.fileSizeBytes) || 0,
        mimeType: a.mimeType,
        uploadStatus: a.uploadStatus,
        storageUrl: a.storageUrl,
        thumbnailUrl: a.thumbnailUrl,
      })),
  });
}

/**
 * POST /api/uploads/[requestId]
 *
 * Step 1 of the presigned URL upload flow.
 *
 * Accepts file metadata, validates the file and request ownership, then
 * generates a presigned PUT URL for the tmp/ folder in DO Spaces.
 * The client uses this URL to upload the file DIRECTLY to DO Spaces.
 *
 * Request body: { fileName, fileSizeBytes, mimeType }
 * Response:     { assetId, presignedUrl, storageKey }
 *
 * After the client completes the PUT, it must call
 * POST /api/uploads/[requestId]/confirm to move the file from tmp/ to
 * request_mat/ and mark the asset as Uploaded.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ requestId: string }> }
) {
  const { requestId } = await params;
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }

  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  // Verify the request belongs to this user
  try {
    await clipRequestService.getOwnedRequest(requestId, session.user.id);
  } catch {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  // Check existing upload count
  const currentCount = await uploadService.countAssets(requestId);
  if (currentCount >= MAX_UPLOAD_COUNT) {
    // Every 422 on this route is logged. A business rejection used to return
    // silently, so a file the server refused left NO trace in the server log at
    // all — the only record was a red bar on the user's phone. Debugging "this
    // file will not upload" then had nothing server-side to work from.
    console.warn(
      `[upload:422] request=${requestId} reason=count currentCount=${currentCount}/${MAX_UPLOAD_COUNT}`
    );
    return NextResponse.json(
      { error: `Maximum ${MAX_UPLOAD_COUNT} files per request.` },
      { status: 422 }
    );
  }

  let body: { fileName?: unknown; fileSizeBytes?: unknown; mimeType?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const { fileName, fileSizeBytes: fileSizeBytesRaw, mimeType } = body;

  if (
    typeof fileName !== "string" ||
    typeof fileSizeBytesRaw !== "number" ||
    typeof mimeType !== "string"
  ) {
    return NextResponse.json(
      { error: "Missing required fields: fileName (string), fileSizeBytes (number), mimeType (string)." },
      { status: 400 }
    );
  }

  if (fileSizeBytesRaw <= 0) {
    return NextResponse.json({ error: "Invalid file size." }, { status: 400 });
  }

  // Validate file type, per-file size, and per-request total upload size.
  const existingBytes = await uploadService.sumUploadedBytes(requestId);
  const validation = uploadService.validateFile(
    { name: fileName, size: fileSizeBytesRaw, type: mimeType },
    currentCount,
    existingBytes
  );
  if (!validation.valid) {
    console.warn(
      `[upload:422] request=${requestId} file="${fileName}" ` +
        `size=${fileSizeBytesRaw}B type=${mimeType} existingBytes=${existingBytes}B ` +
        `reason=${validation.error}`
    );
    return NextResponse.json({ error: validation.error }, { status: 422 });
  }

  try {
    const result = await uploadService.createPresignedUpload({
      requestId,
      userId: session.user.id,
      fileName,
      fileSizeBytes: fileSizeBytesRaw,
      mimeType,
    });

    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    console.error("[POST /api/uploads/[requestId]]", err);
    return NextResponse.json({ error: "Failed to create upload." }, { status: 500 });
  }
}
