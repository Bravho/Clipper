import { AssetType, AssetUploadStatus } from "@/domain/enums/AssetType";

/**
 * Metadata record for a file uploaded by a requester.
 *
 * Important policy rules:
 * - Uploaded source files are NOT a reusable asset library.
 * - Each asset is tied to exactly one clip request.
 * - Raw uploads are scheduled for deletion 90 days after upload (scheduledDeletionAt).
 * - Actual file bytes are stored externally (DigitalOcean Spaces).
 *   The `storageKey` is the DO Spaces object key.
 *   The `storageUrl` is a public or presigned URL for display/download.
 *
 * TODO: PostgreSQL — map to `uploaded_assets` table.
 *   Columns: id, request_id (FK), user_id, file_name, asset_type, file_size_bytes,
 *            mime_type, storage_key, storage_url, upload_status, scheduled_deletion_at,
 *            created_at, updated_at
 *
 * TODO: DigitalOcean Spaces — replace storageKey/storageUrl with real values from
 *   the presigned upload flow. The UploadService will generate presigned PUT URLs
 *   and set the storage key on confirmation.
 */
export interface UploadedAsset {
  id: string;
  requestId: string;
  userId: string;

  // File metadata
  fileName: string;
  assetType: AssetType;
  fileSizeBytes: number;
  mimeType: string;

  // Storage
  /** Object key in DigitalOcean Spaces. Set to the tmp/ key on creation; updated to request_mat/ key on confirmation. */
  storageKey: string;
  /** Public URL for the stored object. Empty string until upload is confirmed. */
  storageUrl: string;

  // Thumbnail (generated after upload confirmation)
  /** Storage key of the thumbnail image in DO Spaces (thumbnails/ folder). Empty string until generated. */
  thumbnailKey: string;
  /** Public URL of the thumbnail image. Empty string until generated. */
  thumbnailUrl: string;

  // Upload lifecycle
  uploadStatus: AssetUploadStatus;

  /**
   * Real playback duration in seconds — only meaningful for video clips. Probed
   * server-side with ffprobe at the upload-confirmation step (the same probe that
   * enforces MAX_CLIP_DURATION_SECONDS) and persisted here so downstream steps —
   * e.g. the storyboard/voice length estimate — use a clip's true length instead
   * of a flat per-asset guess. Null for images or when the probe was unavailable.
   */
  durationSeconds?: number | null;

  /**
   * Video aspect ratio — only set for FinalClip / WatermarkedPreview assets.
   * Null for all other asset types.
   */
  videoRatio?: "9:16" | "16:9" | "1:1" | "4:5" | null;

  /**
   * For a {@link AssetType.WatermarkedPreview}, the id of the clean FinalClip
   * asset it was derived from. This is the link the presentation layer uses to
   * swap a locked requester's preview to the watermarked variant. Null for every
   * other asset type.
   *
   * Persisted as `source_asset_id UUID NULLABLE` on `uploaded_assets`.
   */
  sourceAssetId?: string | null;

  /**
   * Opaque handle into the app's private storage on the requester's device.
   *
   * Non-null means the ORIGINAL BYTES WERE NEVER UPLOADED. `storageUrl` then
   * points at a small poster derivative — enough for Gemini, the scene
   * designer and every thumbnail — and any render that needs the real frames
   * has to run on the device that holds them.
   *
   * This is the field that makes "edit your own footage without uploading it"
   * possible, and the field every URL-resolving code path has to branch on. A
   * renderer that ignores it will happily animate the poster and produce a
   * still where a moving clip belongs, which is why `orderSourceAssets` carries
   * it through and the render manifest refuses to name both a URL and a handle.
   *
   * Null for everything uploaded the normal way, including every asset that
   * existed before migration 036 — so the Mac Mini path is untouched.
   */
  deviceLocalId?: string | null;

  /** Date when this raw upload will be deleted per the 90-day retention policy. */
  scheduledDeletionAt: Date;

  createdAt: Date;
  updatedAt: Date;
}

export type CreateUploadedAssetInput = Omit<
  UploadedAsset,
  "id" | "createdAt" | "updatedAt"
>;

export type UpdateUploadedAssetInput = Partial<
  Pick<UploadedAsset, "storageKey" | "storageUrl" | "thumbnailKey" | "thumbnailUrl" | "uploadStatus" | "videoRatio" | "durationSeconds">
>;
