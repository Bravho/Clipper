import { IRenderTaskRepository } from "@/repositories/interfaces/IRenderTaskRepository";
import {
  RenderTask,
  RenderTaskState,
  EnqueueRenderTaskInput,
} from "@/domain/models/RenderTask";
import { RenderStep } from "@/domain/enums/RenderStep";
import { compareRenderOrder } from "@/config/renderQueue";

// TODO: PostgreSQL — this mock mirrors PostgresRenderTaskRepository's SQL
// behaviour (priority + ageing claim order, stale reclaim, position count) for
// unit tests. Ordering goes through the shared `compareRenderOrder` so the mock
// and the SQL expression cannot drift apart.

declare global {
  // eslint-disable-next-line no-var
  var __mockRenderTaskStore: Map<string, RenderTask> | undefined;
}

function getStore(): Map<string, RenderTask> {
  if (!global.__mockRenderTaskStore) {
    global.__mockRenderTaskStore = new Map();
  }
  return global.__mockRenderTaskStore;
}

/** Active = still in the line (waiting or rendering). */
function isActive(t: RenderTask): boolean {
  return t.state === "queued" || t.state === "claimed";
}

export class MockRenderTaskRepository implements IRenderTaskRepository {
  private store: Map<string, RenderTask>;

  constructor(store?: Map<string, RenderTask>) {
    this.store = store ?? getStore();
  }

  private activeSorted(): RenderTask[] {
    return [...this.store.values()].filter(isActive).sort(compareRenderOrder);
  }

  async enqueue(input: EnqueueRenderTaskInput): Promise<RenderTask> {
    // Idempotent per job: replace any existing active task for this job so we
    // never stack two queued steps for the same job.
    for (const [id, t] of this.store) {
      if (t.jobId === input.jobId && isActive(t)) this.store.delete(id);
    }
    const now = new Date();
    const task: RenderTask = {
      id: crypto.randomUUID(),
      jobId: input.jobId,
      requestId: input.requestId,
      requesterId: input.requesterId ?? null,
      step: input.step,
      payload: input.payload ?? null,
      state: "queued",
      attempts: 0,
      priority: input.priority ?? 0,
      deviceOnly: input.deviceOnly ?? false,
      enqueuedAt: now,
      claimedBy: null,
      claimedAt: null,
      heartbeatAt: null,
      startedAt: null,
      finishedAt: null,
      durationMs: null,
      error: null,
      createdAt: now,
      updatedAt: now,
    };
    this.store.set(task.id, task);
    return { ...task };
  }

  async claimNext(
    workerId: string,
    staleClaimSeconds: number
  ): Promise<RenderTask | null> {
    const staleBefore = Date.now() - staleClaimSeconds * 1000;
    const candidates = [...this.store.values()]
      .filter((t) => {
        // The worker has no copy of a device-held request's footage, so a
        // claim here could only ever end in a failed step. Excluding it from
        // the CLAIM makes that impossible rather than merely handled.
        if (t.deviceOnly) return false;
        if (t.state === "queued") return true;
        if (t.state === "claimed") {
          const keepAlive = (t.heartbeatAt ?? t.claimedAt)?.getTime() ?? 0;
          return keepAlive < staleBefore;
        }
        return false;
      })
      // Highest effective priority first, oldest first within a priority.
      .sort(compareRenderOrder);

    const next = candidates[0];
    if (!next) return null;

    const now = new Date();
    const claimed: RenderTask = {
      ...next,
      state: "claimed",
      claimedBy: workerId,
      claimedAt: now,
      heartbeatAt: now,
      startedAt: next.startedAt ?? now,
      attempts: next.attempts + 1,
      updatedAt: now,
    };
    this.store.set(next.id, claimed);
    return { ...claimed };
  }

  async claimForDevice(
    taskId: string,
    requesterId: string,
    deviceClaimId: string,
    allowedSteps: RenderStep[]
  ): Promise<RenderTask | null> {
    const task = this.store.get(taskId);
    if (
      !task ||
      task.state !== "queued" ||
      task.requesterId !== requesterId ||
      // A device-only task exists BECAUSE its footage is on this requester's
      // phone and nowhere else, so the eligible-step list — which limits what a
      // phone may opportunistically take from the worker — does not apply.
      !(task.deviceOnly || allowedSteps.includes(task.step))
    ) {
      return null;
    }
    const now = new Date();
    const claimed: RenderTask = {
      ...task, state: "claimed", claimedBy: deviceClaimId,
      claimedAt: now, heartbeatAt: now, startedAt: task.startedAt ?? now,
      attempts: task.attempts + 1, updatedAt: now,
    };
    this.store.set(taskId, claimed);
    return { ...claimed };
  }

  async touchClaim(taskId: string, deviceClaimId: string): Promise<boolean> {
    const task = this.store.get(taskId);
    if (!task || task.state !== "claimed" || task.claimedBy !== deviceClaimId) return false;
    this.store.set(taskId, { ...task, heartbeatAt: new Date(), updatedAt: new Date() });
    return true;
  }

  async completeClaim(taskId: string, deviceClaimId: string): Promise<boolean> {
    const task = this.store.get(taskId);
    if (!task || task.state !== "claimed" || task.claimedBy !== deviceClaimId) return false;
    await this.complete(taskId, "done");
    return true;
  }

  async releaseClaim(taskId: string, deviceClaimId: string): Promise<boolean> {
    const task = this.store.get(taskId);
    if (!task || task.state !== "claimed" || task.claimedBy !== deviceClaimId) return false;
    await this.release(taskId);
    return true;
  }

  async touch(taskId: string): Promise<void> {
    const t = this.store.get(taskId);
    if (t && t.state === "claimed") {
      this.store.set(taskId, { ...t, heartbeatAt: new Date(), updatedAt: new Date() });
    }
  }

  async complete(
    taskId: string,
    state: Extract<RenderTaskState, "done" | "failed">,
    error?: string | null
  ): Promise<void> {
    const t = this.store.get(taskId);
    if (!t) return;
    const now = new Date();
    const durationMs =
      t.durationMs ?? (t.startedAt ? now.getTime() - t.startedAt.getTime() : null);
    this.store.set(taskId, {
      ...t,
      state,
      finishedAt: now,
      durationMs,
      error: error ?? t.error,
      updatedAt: now,
    });
  }

  async release(taskId: string): Promise<void> {
    const t = this.store.get(taskId);
    if (!t) return;
    this.store.set(taskId, {
      ...t,
      state: "queued",
      claimedBy: null,
      claimedAt: null,
      heartbeatAt: null,
      updatedAt: new Date(),
    });
  }

  async findActiveByJob(jobId: string): Promise<RenderTask | null> {
    for (const t of this.store.values()) {
      if (t.jobId === jobId && isActive(t)) return { ...t };
    }
    return null;
  }

  async findActiveByRequest(requestId: string): Promise<RenderTask | null> {
    for (const t of this.store.values()) {
      if (t.requestId === requestId && isActive(t)) return { ...t };
    }
    return null;
  }

  async countAhead(taskId: string): Promise<number | null> {
    const target = this.store.get(taskId);
    if (!target || !isActive(target)) return null;
    // Tasks that would be CLAIMED first — not merely enqueued earlier. With
    // priorities those differ, and the enqueue-time count would understate the
    // wait for a low-priority task sitting behind a stream of paid work.
    let ahead = 0;
    for (const t of this.store.values()) {
      if (t.id === taskId || !isActive(t)) continue;
      if (compareRenderOrder(t, target) < 0) ahead += 1;
    }
    return ahead;
  }

  async listActive(): Promise<RenderTask[]> {
    return this.activeSorted().map((t) => ({ ...t }));
  }

  async findLatestByJob(jobId: string): Promise<RenderTask | null> {
    const latest = [...this.store.values()]
      .filter((t) => t.jobId === jobId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
    return latest ? { ...latest } : null;
  }
}
