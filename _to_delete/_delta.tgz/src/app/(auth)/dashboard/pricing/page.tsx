import type { Metadata } from "next";
import Link from "next/link";
import { requireRole } from "@/lib/auth/helpers";
import { Role } from "@/domain/enums/Role";
import { ROUTES } from "@/config/routes";
import { Card } from "@/components/ui/Card";
import { creditService } from "@/services/CreditService";
import { videoQuotaService } from "@/services/VideoQuotaService";
import {
  managementProductRepository,
  videoAllowanceWindowRepository,
} from "@/repositories";
import { isManagementEnabledFor } from "@/config/management";
import {
  PackagePicker,
  type PackageOption,
} from "@/features/management/components/PackagePicker";
import { VideoPackagePicker } from "@/features/pricing/components/VideoPackagePicker";
import {
  FREE_REQUESTS_PER_WINDOW,
  FREE_WINDOW_DAYS,
  REQUESTS_PER_PAID_MONTH,
  VIDEO_PACKAGES,
} from "@/config/videoPackages";
import { getServerI18n } from "@/i18n/server";

export const metadata: Metadata = { title: "แพ็กเกจและราคา — RClipper" };
export const dynamic = "force-dynamic";

/**
 * Packages and pricing.
 *
 * ONE page for everything a requester can buy. A user who has just hit their
 * monthly limit needs a single place to go — splitting video packages, Channel
 * Management packages and bundles across three screens means they find none.
 *
 * The three sections are ordered video → publishing → bundle deliberately. By
 * the time the reader reaches a bundle they have already seen what its two
 * halves cost separately, so the saving reads as a real number rather than a
 * claim. That is also why the saving is computed here from the two catalogues
 * instead of being written into copy that could drift out of date.
 *
 * Everything is bought with credits: a wallet debit against a server-side
 * catalogue, never a client-supplied price. That is also what keeps the native
 * apps store-compliant, because real money only ever enters through a credit
 * top-up handled by the platform's own billing — and it is why a package costs
 * the same number of credits everywhere while a top-up's real price differs by
 * platform.
 */
export default async function PricingPage() {
  const { t, locale } = getServerI18n();
  const user = await requireRole(Role.Requester);

  const [balance, quota, windows] = await Promise.all([
    creditService.getBalance(user.id),
    videoQuotaService.getQuota(user.id),
    videoAllowanceWindowRepository.findByUserId(user.id),
  ]);

  const now = new Date();
  const dateFmt = new Intl.DateTimeFormat(locale === "th" ? "th-TH" : locale, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  const liveExpiries = windows
    .filter((w) => w.expiresAt.getTime() > now.getTime())
    .map((w) => w.expiresAt.getTime());
  const activeUntil =
    liveExpiries.length > 0 ? dateFmt.format(new Date(Math.max(...liveExpiries))) : null;

  const entryPrice = Math.min(...VIDEO_PACKAGES.map((p) => p.priceCredits));
  const ladderVars = {
    freeTotal: FREE_REQUESTS_PER_WINDOW,
    days: FREE_WINDOW_DAYS,
    paidTotal: REQUESTS_PER_PAID_MONTH,
    price: entryPrice,
  };

  const managementEnabled = isManagementEnabledFor({
    id: user.id,
    email: user.email,
    role: user.role,
  });
  const managementProducts = managementEnabled
    ? await managementProductRepository.listActive()
    : [];

  /**
   * What the same term would cost bought as two separate packages. Used only for
   * the saving badge; the price charged always comes from the catalogue row.
   */
  const separatePriceFor = (months: number | null): number | null => {
    const videoPkg = VIDEO_PACKAGES.find((v) => v.months === months);
    const pass = managementProducts.find(
      (m) => m.videoMonths == null && m.durationMonths === months
    );
    if (!videoPkg || !pass) return null;
    return videoPkg.priceCredits + pass.priceCredits;
  };

  const toOption = (p: (typeof managementProducts)[number]): PackageOption => ({
    code: p.code,
    name:
      p.productType === "single_video"
        ? `Starter Credit Pack (${p.uploadAllowance ?? 4} uploads)`
        : p.videoMonths
          ? p.durationMonths === 12
            ? "Complete — 1 Year"
            : `Complete — ${p.durationMonths} Month${p.durationMonths === 1 ? "" : "s"}`
          : p.durationMonths === 12
            ? "1-Year Publishing Access"
            : `${p.durationMonths}-Month Publishing Access`,
    description:
      p.productType === "single_video"
        ? `Publishing one video to one channel consumes one upload. Use all ${p.uploadAllowance ?? 4} uploads within ${p.accessWindowDays ?? 30} days.`
        : p.videoMonths
          ? `${REQUESTS_PER_PAID_MONTH} videos a month at priority rendering, plus unlimited publishing, for ${p.durationMonths} month${p.durationMonths === 1 ? "" : "s"}.`
          : `Activate unlimited publishing for ${p.durationMonths} month${p.durationMonths === 1 ? "" : "s"} using credits from your balance.`,
    productType: p.productType,
    durationMonths: p.durationMonths,
    uploadAllowance: p.uploadAllowance,
    accessWindowDays: p.accessWindowDays,
    videoMonths: p.videoMonths,
    badge: (() => {
      if (!p.videoMonths) return null;
      const separate = separatePriceFor(p.durationMonths);
      if (!separate || separate <= p.priceCredits) return null;
      return t("pricing.bundleSaving", { amount: separate - p.priceCredits });
    })(),
    priceCredits: p.priceCredits,
    fullPriceCredits: p.fullPriceCredits,
  });

  const bundleOptions = managementProducts
    .filter((p) => p.videoMonths != null)
    .map(toOption);
  const publishingOptions = managementProducts
    .filter((p) => p.videoMonths == null)
    .map(toOption);

  return (
    <div className="mx-auto w-full min-w-0 max-w-4xl px-4 py-8 sm:py-10">
      <header className="mb-6">
        <Link
          href={ROUTES.DASHBOARD}
          className="text-sm font-medium text-blue-600 hover:underline"
        >
          ← {t("nav.dashboard")}
        </Link>
        <h1 className="mt-2 text-2xl font-bold text-slate-900">{t("pricing.title")}</h1>
        <p className="mt-1 text-sm text-slate-500">{t("pricing.subtitle", ladderVars)}</p>
      </header>

      {/* Balance first: every package below is bought with credits, and the
          real-money price of a credit depends on where the user tops up. */}
      <Card className="mb-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-lg font-semibold text-slate-900">
              {t("pricing.balance", { balance: balance.toLocaleString() })}
            </p>
            <p className="mt-0.5 text-sm text-slate-500">{t("pricing.balanceHint")}</p>
          </div>
          <Link
            href={`${ROUTES.CREDITS}?returnTo=${encodeURIComponent(ROUTES.PRICING)}`}
          >
            <button className="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-800">
              {t("pricing.topUp")}
            </button>
          </Link>
        </div>

        <p className="mt-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-600">
          <span className="font-medium">
            {t("quota.remainingShort", {
              remaining: quota.remaining,
              total: quota.total,
            })}
          </span>{" "}
          · {t("quota.ladder", ladderVars)}
        </p>
      </Card>

      {/* 1. Video generation on its own. */}
      <div className="mb-10">
        <VideoPackagePicker balanceCredits={balance} activeUntil={activeUntil} />
      </div>

      {/* 2. Channel Management on its own. Hidden entirely for users it is not
          enabled for, rather than shown as something they cannot buy. */}
      {managementEnabled && publishingOptions.length > 0 && (
        <section className="mb-10">
          <h2 className="text-base font-semibold text-slate-900">
            {t("pricing.managementHeading")}
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {t("pricing.managementSubheading")}
          </p>
          <div className="mt-4">
            <PackagePicker
              balanceCredits={balance}
              returnTo={ROUTES.PRICING}
              chrome={false}
              products={publishingOptions}
            />
          </div>
        </section>
      )}

      {/* 3. Both together, last — by now the reader knows what the two halves
          cost separately, so the saving badge is checkable rather than a claim. */}
      {managementEnabled && bundleOptions.length > 0 && (
        <section>
          <h2 className="text-base font-semibold text-slate-900">
            {t("pricing.bundleHeading")}
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {t("pricing.bundleSubheading", { paidTotal: REQUESTS_PER_PAID_MONTH })}
          </p>
          <div className="mt-4">
            <PackagePicker
              balanceCredits={balance}
              returnTo={ROUTES.PRICING}
              chrome={false}
              products={bundleOptions}
            />
          </div>
          <p className="mt-3 text-xs text-slate-400">{t("pricing.bundleFootnote")}</p>
        </section>
      )}
    </div>
  );
}
