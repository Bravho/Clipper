"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CHROME, SERIES_ORDER } from "@/features/admin/charts/palette";
import { TOOLTIP_STYLE } from "@/features/admin/charts/TimeSeriesChart";
import type { SeriesSpec } from "@/features/admin/charts/TimeSeriesChart";

export interface CategoryRow {
  /** Category label shown on the axis. */
  category: string;
  [seriesKey: string]: string | number;
}

/**
 * Horizontal grouped bars — one group per category, one bar per series.
 *
 * Horizontal because the categories here are step names (`montage_scene_segment`,
 * `ffmpeg_composition`), which are far too long to sit under vertical bars
 * without rotating the labels.
 *
 * Bars carry a 2px surface gap (`barGap`) so adjacent fills never touch, and
 * radius is applied only to the data end so the bar stays anchored to the
 * baseline.
 */
export function GroupedBarChart({
  data,
  series,
  height,
  valueSuffix = "",
  formatValue,
}: {
  data: CategoryRow[];
  series: SeriesSpec[];
  height?: number;
  valueSuffix?: string;
  formatValue?: (value: number) => string;
}) {
  const showLegend = series.length > 1;
  // Give each category enough room that the label never collides with its neighbour.
  const computedHeight = height ?? Math.max(200, data.length * 34 + (showLegend ? 48 : 24));

  return (
    <ResponsiveContainer width="100%" height={computedHeight}>
      <BarChart
        data={data}
        layout="vertical"
        margin={{ top: 4, right: 16, bottom: 0, left: 8 }}
        barGap={2}
      >
        <CartesianGrid stroke={CHROME.grid} horizontal={false} />
        <XAxis
          type="number"
          tick={{ fill: CHROME.muted, fontSize: 11 }}
          tickLine={false}
          axisLine={{ stroke: CHROME.axis }}
          tickFormatter={(v: number) => (formatValue ? formatValue(v) : String(v))}
        />
        <YAxis
          type="category"
          dataKey="category"
          tick={{ fill: CHROME.secondary, fontSize: 11 }}
          tickLine={false}
          axisLine={false}
          width={160}
        />
        <Tooltip
          cursor={{ fill: "rgba(15,23,42,0.04)" }}
          contentStyle={TOOLTIP_STYLE}
          labelStyle={{ color: CHROME.secondary, fontSize: 11, marginBottom: 4 }}
          itemStyle={{ fontSize: 12 }}
          formatter={(value: number, name: string) => [
            formatValue ? formatValue(value) : `${value}${valueSuffix}`,
            name,
          ]}
        />
        {showLegend && (
          <Legend
            verticalAlign="top"
            align="left"
            height={28}
            wrapperStyle={{ fontSize: 12, color: CHROME.secondary }}
          />
        )}
        {series.map((s, i) => (
          <Bar
            key={s.key}
            dataKey={s.key}
            name={s.label}
            fill={SERIES_ORDER[i % SERIES_ORDER.length]}
            radius={[0, 4, 4, 0]}
            maxBarSize={14}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}
