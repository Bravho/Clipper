import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/authOptions";
import { Role } from "@/domain/enums/Role";
import { paymentService } from "@/services/PaymentService";
import { TOPUP_BUNDLES } from "@/config/credits";
import { appOrigin } from "@/lib/appOrigin";
import { z } from "zod";

const allowedAmounts = TOPUP_BUNDLES.map((b) => b.baht);

const bodySchema = z.object({
  amountBaht: z
    .number()
    .int()
    .positive()
    .refine((v) => allowedAmounts.includes(v as (typeof allowedAmounts)[number]), {
      message: "Amount must be one of the offered top-up bundles.",
    }),
  paymentMethod: z.enum(["promptpay", "card"]).default("promptpay"),
  returnPath: z.string().startsWith("/").optional(),
});

/**
 * POST /api/credits/topup
 * Creates a Stripe PromptPay QR for a top-up bundle and returns it for display.
 */
export async function POST(request: Request) {
  // Store-distributed native builds must use StoreKit / Google Play Billing for
  // these digital credits. Block Stripe server-side as well as hiding its UI.
  if (request.headers.get("user-agent")?.includes("RClipperNative/")) {
    return NextResponse.json(
      { error: "Native mobile purchases must use the device app store." },
      { status: 403 }
    );
  }
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }
  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "จำนวนเงินไม่ถูกต้อง", details: parsed.error.flatten() },
      { status: 422 }
    );
  }

  try {
    // Not `new URL(request.url).origin` — behind nginx that reads
    // http://localhost:3000, which would send the payer's browser to port 3000
    // on their own machine after paying.
    const origin = appOrigin(request);
    const safeReturnPath = parsed.data.returnPath ?? "/dashboard/credits";
    const bundle = TOPUP_BUNDLES.find(
      (candidate) => candidate.baht === parsed.data.amountBaht
    );
    if (!bundle) {
      return NextResponse.json(
        { error: "ไม่พบแพ็กเกจเครดิตที่เลือก" },
        { status: 422 }
      );
    }
    const result =
      parsed.data.paymentMethod === "card"
        ? await paymentService.createCardTopupIntent(
            session.user.id,
            parsed.data.amountBaht,
            `${origin}${safeReturnPath}`,
            bundle.credits
          )
        : await paymentService.createTopupIntent(
            session.user.id,
            parsed.data.amountBaht,
            session.user.email,
            bundle.credits
          );
    return NextResponse.json(result);
  } catch (err) {
    console.error("[POST /api/credits/topup]", err);
    const message = err instanceof Error ? err.message : "Unknown error.";
    if (message.includes("keys are not set")) {
      return NextResponse.json(
        { error: "ระบบชำระเงินยังไม่ได้ตั้งค่า กรุณาติดต่อผู้ดูแลระบบ" },
        { status: 503 }
      );
    }
    return NextResponse.json(
      { error: "ไม่สามารถสร้าง QR ชำระเงินได้ กรุณาลองใหม่" },
      { status: 500 }
    );
  }
}
