import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/authOptions";
import { Role } from "@/domain/enums/Role";
import { clipRequestRepository, videoGenerationJobRepository } from "@/repositories/index";
import { videoGenerationService } from "@/services/VideoGenerationService";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }
  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const clipRequest = await clipRequestRepository.findById(id);
  if (!clipRequest || clipRequest.userId !== session.user.id) {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const jobId = body?.jobId;
  if (!jobId) {
    return NextResponse.json({ error: "Missing jobId." }, { status: 400 });
  }

  const job = await videoGenerationJobRepository.findById(jobId);
  if (!job || job.requestId !== id) {
    return NextResponse.json({ error: "Job not found." }, { status: 404 });
  }

  const ALLOWED_LANGS = ["th", "en", "zh"] as const;
  const MAX_SUBTITLE_LANGS = 2; // at most two languages shown on screen at once
  const rawLangs = Array.isArray(body?.subtitleLanguages) ? body.subtitleLanguages : undefined;
  const subtitleLanguages = rawLangs
    ?.filter((l: unknown): l is "th" | "en" | "zh" =>
      ALLOWED_LANGS.includes(l as (typeof ALLOWED_LANGS)[number])
    )
    .slice(0, MAX_SUBTITLE_LANGS);

  const { isValidTemplateId } = await import("@/config/motionTemplates");
  const selectedMotionTemplate = isValidTemplateId(body?.selectedMotionTemplate)
    ? (body.selectedMotionTemplate as string)
    : undefined;

  try {
    const updated = await videoGenerationService.approveFinalVideoByRequester(
      jobId,
      session.user.id,
      subtitleLanguages && subtitleLanguages.length > 0 ? subtitleLanguages : undefined,
      selectedMotionTemplate
    );
    return NextResponse.json({ currentStep: updated.currentStep });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to approve final video.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
