/**
 * Types of credit wallet transactions.
 *
 * - SignupBonus:    30 free credits granted on new account creation
 * - RequestCharge: Credits deducted when a clip request is submitted (future)
 * - AdminCredit:   Manual credit grant by admin (future)
 * - AdminDebit:    Manual credit removal by admin (future)
 */
export enum TransactionType {
  SignupBonus = "signup_bonus",
  RequestCharge = "request_charge",
  RequestRefund = "request_refund",
  AdminCredit = "admin_credit",
  AdminDebit = "admin_debit",
  DiscountApplied = "discount_applied",
  /** Credits added by a confirmed PromptPay top-up via Stripe. */
  TopUp = "top_up",
  /** Credits spent on an RClipper Management package (bundle or access pass). */
  ManagementPurchase = "management_purchase",
  /** Credits returned when a Management purchase is refunded. */
  ManagementRefund = "management_refund",
}
