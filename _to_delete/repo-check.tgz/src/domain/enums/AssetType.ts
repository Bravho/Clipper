/**
 * Type of a requester-uploaded source asset.
 *
 * Requesters may upload up to 5 videos or images as source material
 * for their clip request. These are NOT a reusable asset library —
 * they are retained for the submitted request only and deleted after 90 days.
 *
 * TODO: PostgreSQL — store as TEXT with CHECK constraint on `uploaded_assets` table.
 */
export enum AssetType {
  Video = "video",
  Image = "image",
  /** Final edited clip uploaded by staff — stored in clips/ folder. */
  EditedClip = "edited_clip",

  // ── AI Pipeline asset types ─────────────────────────────────────────────────
  /** Raw video produced by the AI video generator (Veo) from requester images. */
  AIGeneratedBaseVideo = "ai_generated_base_video",
  /** RVC-converted voice audio uploaded by staff (conversion happens in browser before upload). */
  StaffVoiceRecording = "staff_voice_recording",
  /** Alias kept for DB compatibility — points to the same asset as StaffVoiceRecording. */
  ProcessedVoice = "processed_voice",
  /** FFmpeg-composed final clip (one record per exported ratio). */
  FinalClip = "final_clip",
  /** Base video with Claude-generated animation/graphic overlays applied by FFmpeg. */
  AnimatedVideo = "animated_video",
  /**
   * Watermarked ("RClipper" tiled overlay) sibling of a FinalClip, pre-rendered
   * during the pipeline. This is the ONLY variant shown to a requester whose
   * download is still locked (unpaid) — the clean FinalClip is never surfaced
   * until they pay. Linked back to its clean source via `sourceAssetId`.
   */
  WatermarkedPreview = "watermarked_preview",
}

/** Upload status of a single asset record. */
export enum AssetUploadStatus {
  Pending = "pending",     // Selected by requester, not yet sent
  Uploading = "uploading", // Upload in progress
  Uploaded = "uploaded",   // Successfully stored
  Failed = "failed",       // Upload error — retryable
  Deleted = "deleted",     // Removed per 90-day retention policy
}

/** Accepted MIME types for video uploads. MP4 only — the montage renderer and
 *  FFmpeg concat expect a consistent H.264/MP4 source, and browsers reliably
 *  decode MP4 for the in-form thumbnail + trim-bar preview. */
export const ACCEPTED_VIDEO_MIME_TYPES = ["video/mp4"] as const;

/** Accepted MIME types for image uploads. */
export const ACCEPTED_IMAGE_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
] as const;

export const ACCEPTED_MIME_TYPES = [
  ...ACCEPTED_VIDEO_MIME_TYPES,
  ...ACCEPTED_IMAGE_MIME_TYPES,
] as const;

/** Maximum number of files a requester may attach to a single request. */
export const MAX_UPLOAD_COUNT = 10;

/** Maximum file size for image uploads: 8 MB */
export const MAX_IMAGE_SIZE_BYTES = 8 * 1024 * 1024;

/** Maximum overall upload size accepted by the upload service: 500 MB */
export const MAX_UPLOAD_SIZE_BYTES = 500 * 1024 * 1024;

/**
 * Maximum file size for a single video upload: 300 MB. A requester may attach up
 * to MAX_UPLOAD_COUNT files, but the per-request total is still capped by
 * MAX_UPLOAD_SIZE_BYTES (500 MB) — so a single 300 MB clip leaves room for a few
 * more, but not several max-size videos at once. (Clip length is still bounded
 * by MAX_CLIP_DURATION_SECONDS.)
 */
export const MAX_VIDEO_SIZE_BYTES = 300 * 1024 * 1024;

/**
 * Maximum duration for a single uploaded video clip: 45 seconds.
 *
 * Enforced on the client (HTMLVideoElement metadata probe) for fast feedback
 * and authoritatively on the server at upload-confirm time (ffprobe). Clips
 * become source material for the real-media montage renderer, so over-long
 * clips are rejected before they enter the pipeline.
 */
export const MAX_CLIP_DURATION_SECONDS = 45;
