/**
 * Text-graphics LAYOUT — THE REFERENCE for every renderer.
 *
 * Turns one plan item into a small tree of boxes in frame pixels. The Android
 * painter and the iOS layer builder implement the same rules with their own
 * text measurement (same font files, so the same advances). All lengths below
 * are reference px at a 1080 short side, multiplied by `s`.
 *
 * PLACEMENT. Captions sit at the bottom of the frame, so text graphics use
 * the top: hook and labels at the top-left, the closing card centred at the
 * top. On a tall frame (h/w ≥ 1.5) the top 11% is left clear for the
 * TikTok/Reels/Shorts top bar.
 */
import type {
  TextGraphicAnim,
  TextGraphicIdle,
  TextGraphicStyleSpec,
} from "@/config/textGraphicStyles";
import type { TextGraphicItem } from "./plan";

export type Measure = (text: string, fontKey: string, sizePx: number) => number;

export interface FontMetrics {
  ascent: number;
  descent: number;
}

export type TgPaint =
  | { type: "none" }
  | { type: "box"; color: string; radius: number; shadowDx: number; shadowDy: number; shadow: string }
  | { type: "text"; text: string; font: string; size: number; color: string; ascent: number }
  | { type: "dot"; color: string }
  | { type: "pin"; color: string }
  | {
      type: "badge";
      shape: "circle" | "burst" | "tag";
      bg: string;
      ring: string;
      text: string;
      font: string;
      size: number;
      color: string;
      ascent: number;
      descent: number;
    };

export interface TgNode {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  /** Scale/rotation origin. */
  anchor: "left" | "center" | "top";
  anim: TextGraphicAnim | null;
  idle?: TextGraphicIdle;
  /** Static rotation in degrees about the centre (badges). */
  rotate: number;
  paint: TgPaint;
  children: TgNode[];
}

export interface TgItemLayout {
  item: TextGraphicItem;
  /** The item's box, for its tilt and exit anchor. */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Tilt and exit scale pivot: top-left for hook and labels, centre for the CTA. */
  pivot: "topLeft" | "center";
  nodes: TgNode[];
}

/** The short-side scale, as captions use it. */
export function frameScale(width: number, height: number): number {
  return Math.min(width, height) / 1080;
}

export function safeTop(width: number, height: number): number {
  const s = frameScale(width, height);
  return height / width >= 1.5 ? 0.11 * height : Math.max(56 * s, 0.06 * height);
}

export const MARGIN_X = 64;

/** Resolve `"accent"` to the request's accent colour. */
export function resolveColor(value: string, accent: string): string {
  return value === "accent" ? accent : value;
}

function node(partial: Partial<TgNode> & Pick<TgNode, "id" | "x" | "y" | "w" | "h">): TgNode {
  return { anchor: "left", anim: null, rotate: 0, paint: { type: "none" }, children: [], ...partial };
}

function lineHeight(size: number, m: FontMetrics): number {
  return size * (m.ascent + m.descent);
}

export function layoutTextGraphicItem(input: {
  item: TextGraphicItem;
  style: TextGraphicStyleSpec;
  accent: string;
  width: number;
  height: number;
  measure: Measure;
  metrics: (fontKey: string) => FontMetrics;
}): TgItemLayout {
  const { item } = input;
  if (item.kind === "hook") return layoutHook(input);
  if (item.kind === "cta") return layoutCta(input);
  return layoutLabel(input);
}

type LayoutInput = Parameters<typeof layoutTextGraphicItem>[0];

function textNode(
  id: string,
  text: string,
  font: string,
  size: number,
  color: string,
  x: number,
  y: number,
  measure: Measure,
  m: FontMetrics,
  anim: TextGraphicAnim | null
): TgNode {
  return node({
    id,
    x,
    y,
    w: measure(text, font, size),
    h: lineHeight(size, m),
    anim,
    paint: { type: "text", text, font, size, color, ascent: m.ascent },
  });
}

/** Shrink a font size so `text` fits `maxWidth`, down to 60%. */
function fitSize(
  text: string,
  font: string,
  size: number,
  maxWidth: number,
  measure: Measure,
  minFactor = 0.6
): number {
  const w = measure(text, font, size);
  if (w <= maxWidth || w <= 0) return size;
  return Math.max(size * minFactor, (size * maxWidth) / w);
}

function layoutLabel({ item, style, accent, width, height, measure, metrics }: LayoutInput): TgItemLayout {
  const s = frameScale(width, height);
  const c = (v: string) => resolveColor(v, accent);
  const M = MARGIN_X * s;
  const top = safeTop(width, height);
  const hasBadge = Boolean(item.badge);
  const D = style.sizes.badgeDiameter * s;
  const barW = style.shape.barWidth * s;
  const barGap = barW > 0 ? 14 * s : 0;
  const padL = 26 * s;
  const padR = 30 * s;
  const padT = 16 * s;
  const padB = 20 * s;

  const maxText = width - 2 * M - barW - barGap - padL - padR - (hasBadge ? 0.9 * D : 0);
  const titleFont = style.fonts.title;
  const bodyFont = style.fonts.body;
  const titleSize = fitSize(item.title, titleFont, style.sizes.title * s, maxText, measure);
  const sub = style.shape.uppercaseSub ? item.sub.toUpperCase() : item.sub;
  const subSize = fitSize(sub, bodyFont, style.sizes.sub * s, maxText, measure);
  const numSize = style.sizes.num * s;
  const mt = metrics(titleFont);
  const mb = metrics(bodyFont);

  const cardX = M + barW + barGap;
  const innerX = cardX + padL;
  let y = top + padT;
  const children: TgNode[] = [];

  if (item.num) {
    const n = textNode("num", item.num, titleFont, numSize, c(style.colors.num), innerX, y, measure, mt, style.motion.num);
    children.push(n);
    y += n.h + 2 * s;
  }
  const title = textNode("title", item.title, titleFont, titleSize, c(style.colors.title), innerX, y, measure, mt, style.motion.title);
  children.push(title);
  y += title.h;
  if (style.shape.underline) {
    y += 4 * s;
    children.push(
      node({
        id: "underline",
        x: innerX,
        y,
        w: title.w,
        h: 6 * s,
        anim: style.motion.underline,
        paint: { type: "box", color: c(style.colors.underline), radius: 3 * s, shadowDx: 0, shadowDy: 0, shadow: "#00000000" },
      })
    );
    y += 6 * s + 8 * s;
  } else {
    y += 4 * s;
  }
  if (sub) {
    const subNode = textNode("sub", sub, bodyFont, subSize, c(style.colors.sub), innerX, y, measure, mb, style.motion.sub);
    children.push(subNode);
    y += subNode.h;
  }
  const contentW = Math.max(...children.map((ch) => ch.w), 0);
  const cardW = padL + contentW + padR;
  const cardH = y + padB - top;

  const nodes: TgNode[] = [];
  if (barW > 0) {
    nodes.push(
      node({
        id: "bar",
        x: M,
        y: top,
        w: barW,
        h: cardH,
        anchor: "top",
        anim: style.motion.bar,
        paint: { type: "box", color: c(style.colors.bar), radius: barW / 2, shadowDx: 0, shadowDy: 0, shadow: "#00000000" },
      })
    );
  }
  nodes.push(
    node({
      id: "card",
      x: cardX,
      y: top,
      w: cardW,
      h: cardH,
      anim: style.motion.card,
      paint: {
        type: "box",
        color: c(style.colors.cardBg),
        radius: style.shape.cardRadius * s,
        shadowDx: style.shape.shadowDx * s,
        shadowDy: style.shape.shadowDy * s,
        shadow: c(style.colors.shadow),
      },
      children,
    })
  );
  if (hasBadge) {
    const mBadge = metrics(style.fonts.badge);
    const bw = style.shape.badge === "tag" ? 1.4 * D : D;
    const bh = style.shape.badge === "tag" ? 0.6 * D : D;
    // The badge overlaps the card's top-right corner by a tenth of its height.
    const cx = cardX + cardW + bw / 2 - 0.1 * bh;
    const cy = top + 0.22 * D;
    const textMax = (style.shape.badge === "tag" ? 1.15 : 0.66) * D;
    const size = fitSize(item.badge, style.fonts.badge, style.sizes.badgeText * s, textMax, measure, 0.5);
    nodes.push(
      node({
        id: "badge",
        x: cx - bw / 2,
        y: cy - bh / 2,
        w: bw,
        h: bh,
        anchor: "center",
        anim: style.motion.badge,
        idle: style.motion.badgeIdle,
        rotate: style.shape.badgeRotate,
        paint: {
          type: "badge",
          shape: style.shape.badge,
          bg: c(style.colors.badgeBg),
          ring: c(style.colors.badgeRing),
          text: item.badge,
          font: style.fonts.badge,
          size,
          color: c(style.colors.badgeText),
          ascent: mBadge.ascent,
          descent: mBadge.descent,
        },
      })
    );
  }
  return { item, x: M, y: top, w: cardX + cardW - M, h: cardH, pivot: "topLeft", nodes };
}

function layoutHook({ item, style, accent, width, height, measure, metrics }: LayoutInput): TgItemLayout {
  const s = frameScale(width, height);
  const c = (v: string) => resolveColor(v, accent);
  const M = MARGIN_X * s;
  const top = safeTop(width, height);
  const padL = 22 * s;
  const padR = 30 * s;
  const padT = 16 * s;
  const padB = 20 * s;
  const dotD = style.shape.hookDot ? 44 * s : 0;
  const dotGap = style.shape.hookDot ? 18 * s : 0;
  const font = style.fonts.hook;
  const bodyFont = style.fonts.body;
  const mh = metrics(font);
  const mb = metrics(bodyFont);
  const maxText = width - 2 * M - padL - padR;

  const innerX = M + padL;
  let y = top + padT;
  const children: TgNode[] = [];

  if (item.kicker) {
    const kickerText = item.kicker.toUpperCase();
    const size = fitSize(kickerText, bodyFont, style.sizes.kicker * s, maxText - 28 * s, measure);
    const label = textNode("kickerText", kickerText, bodyFont, size, c(style.colors.kickerText), innerX + 14 * s, y + 6 * s, measure, mb, null);
    const chip = node({
      id: "kicker",
      x: innerX,
      y,
      w: label.w + 28 * s,
      h: label.h + 12 * s,
      anim: style.motion.kicker,
      paint: { type: "box", color: c(style.colors.kickerBg), radius: 6 * s, shadowDx: 0, shadowDy: 0, shadow: "#00000000" },
      children: [label],
    });
    children.push(chip);
    y += chip.h + 10 * s;
  }

  const titleSize = fitSize(item.title, font, style.sizes.hookTitle * s, maxText - dotD - dotGap, measure);
  const titleH = lineHeight(titleSize, mh);
  const rowH = Math.max(dotD, titleH);
  if (dotD > 0) {
    children.push(
      node({
        id: "dot",
        x: innerX,
        y: y + (rowH - dotD) / 2,
        w: dotD,
        h: dotD,
        anchor: "center",
        anim: style.motion.dot,
        paint: { type: "dot", color: c(style.colors.dot) },
      })
    );
  }
  children.push(
    textNode("hookTitle", item.title, font, titleSize, c(style.colors.hookTitle), innerX + dotD + dotGap, y + (rowH - titleH) / 2, measure, mh, style.motion.hookTitle)
  );
  y += rowH + 4 * s;

  if (item.sub) {
    const size = fitSize(item.sub, bodyFont, style.sizes.hookSub * s, maxText, measure);
    const sub = textNode("hookSub", item.sub, bodyFont, size, c(style.colors.hookSub), innerX, y, measure, mb, style.motion.hookSub);
    children.push(sub);
    y += sub.h;
  }

  const contentRight = Math.max(...children.map((ch) => ch.x + ch.w));
  const boxW = contentRight - M + padR;
  const boxH = y + padB - top;
  const box = node({
    id: "hookBox",
    x: M,
    y: top,
    w: boxW,
    h: boxH,
    anim: style.motion.hookBox,
    paint: {
      type: "box",
      color: c(style.colors.hookBg),
      radius: style.shape.cardRadius * s,
      shadowDx: style.shape.shadowDx * s,
      shadowDy: style.shape.shadowDy * s,
      shadow: c(style.colors.shadow),
    },
    children,
  });
  return { item, x: M, y: top, w: boxW, h: boxH, pivot: "topLeft", nodes: [box] };
}

function layoutCta(input: LayoutInput): TgItemLayout {
  const first = layoutCtaAt(input, 1);
  const s = frameScale(input.width, input.height);
  const maxW = input.width - 2 * MARGIN_X * s;
  if (first.w <= maxW) return first;
  return layoutCtaAt(input, Math.max(0.55, maxW / first.w));
}

function layoutCtaAt({ item, style, accent, width, height, measure, metrics }: LayoutInput, f: number): TgItemLayout {
  const s = frameScale(width, height) * f;
  const c = (v: string) => resolveColor(v, accent);
  const top = safeTop(width, height);
  const padX = 22 * s;
  const padY = 18 * s;
  const pinSize = 72 * s;
  const gap1 = 20 * s;
  const gap2 = 26 * s;
  const titleFont = style.fonts.title;
  const bodyFont = style.fonts.body;
  const mt = metrics(titleFont);
  const mb = metrics(bodyFont);

  const brandSize = style.sizes.ctaBrand * s;
  const placeSize = style.sizes.ctaPlace * s;
  const buttonSize = style.sizes.ctaButton * s;
  const brandW = item.brand ? measure(item.brand, titleFont, brandSize) : 0;
  const placeW = item.place ? measure(item.place, bodyFont, placeSize) : 0;
  const brandH = item.brand ? lineHeight(brandSize, mt) : 0;
  const placeH = item.place ? lineHeight(placeSize, mb) : 0;
  const colW = Math.max(brandW, placeW);
  const colH = brandH + placeH;
  const buttonTextW = item.title ? measure(item.title, titleFont, buttonSize) : 0;
  const buttonH = item.title ? lineHeight(buttonSize, mt) + 24 * s : 0;
  const buttonW = item.title ? buttonTextW + 60 * s : 0;

  const innerH = Math.max(pinSize, colH, buttonH);
  const contentW = pinSize + (colW > 0 ? gap1 + colW : 0) + (buttonW > 0 ? gap2 + buttonW : 0);
  const cardW = padX * 2 + contentW;
  const cardH = padY * 2 + innerH;
  const cardX = (width - cardW) / 2;
  const cardY = top;
  const midY = cardY + padY + innerH / 2;

  const children: TgNode[] = [];
  let x = cardX + padX;
  children.push(
    node({
      id: "pin",
      x,
      y: midY - pinSize / 2,
      w: pinSize,
      h: pinSize,
      anchor: "center",
      anim: style.motion.pin,
      paint: { type: "pin", color: c(style.colors.pin) },
    })
  );
  x += pinSize;
  if (colW > 0) {
    x += gap1;
    let y = midY - colH / 2;
    if (item.brand) {
      children.push(textNode("brand", item.brand, titleFont, brandSize, c(style.colors.ctaBrand), x, y, measure, mt, style.motion.ctaText));
      y += brandH;
    }
    if (item.place) {
      children.push(textNode("place", item.place, bodyFont, placeSize, c(style.colors.ctaPlace), x, y, measure, mb, style.motion.ctaText));
    }
    x += colW;
  }
  if (buttonW > 0) {
    x += gap2;
    const label = textNode("buttonText", item.title, titleFont, buttonSize, c(style.colors.buttonText), x + 30 * s, midY - buttonH / 2 + 12 * s, measure, mt, null);
    children.push(
      node({
        id: "button",
        x,
        y: midY - buttonH / 2,
        w: buttonW,
        h: buttonH,
        anchor: "center",
        anim: style.motion.button,
        idle: style.motion.buttonIdle,
        paint: { type: "box", color: c(style.colors.buttonBg), radius: buttonH / 2, shadowDx: 0, shadowDy: 0, shadow: "#00000000" },
        children: [label],
      })
    );
  }

  const card = node({
    id: "ctaCard",
    x: cardX,
    y: cardY,
    w: cardW,
    h: cardH,
    anchor: "center",
    anim: style.motion.ctaCard,
    paint: {
      type: "box",
      color: c(style.colors.ctaBg),
      radius: style.shape.ctaRadius * s,
      shadowDx: style.shape.shadowDx * s,
      shadowDy: style.shape.shadowDy * s,
      shadow: c(style.colors.shadow),
    },
    children,
  });
  return { item, x: cardX, y: cardY, w: cardW, h: cardH, pivot: "center", nodes: [card] };
}
