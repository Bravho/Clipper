/**
 * Text-graphic style packs.
 *
 * A style pack is the LOOK of the scene-matched text graphics — the hook title,
 * the per-scene labels with their badges, and the closing call-to-action card.
 * What the text SAYS and WHEN it shows comes from the per-request plan
 * (`src/lib/textGraphics/plan.ts`, written by Claude); the pack decides fonts,
 * colours, shapes and motion.
 *
 * A pack is pure data and travels in the render manifest as is. The phone
 * renderers (Android `TextGraphicsPainter`, iOS `TextGraphicsLayers`) and the
 * studio's canvas preview (`src/lib/textGraphics/canvasRenderer.ts`) all
 * interpret the same fields the same way, so a new pack — or a tweak to an
 * existing one — needs a server deploy but no app build.
 *
 * Sizes are reference pixels at a 1080-px short side, scaled by
 * `min(width, height) / 1080` exactly like the captions. Colours are
 * `#RRGGBB` or `#RRGGBBAA`, or the literal `"accent"` for the request's accent
 * colour (the pack's `accent` when set, else the template palette's accent).
 *
 * This is independent of the motion-graphic TEMPLATE (`motionTemplates.ts`):
 * the template is the frame and decoration, the text style is the words on top.
 */

export const TEXT_GRAPHIC_STYLE_IDS = ["premium", "street", "cafe"] as const;
export type TextGraphicStyleId = (typeof TEXT_GRAPHIC_STYLE_IDS)[number];

/** What the requester picks: a pack, "auto" (Claude picks), or "none". */
export const TEXT_GRAPHIC_CHOICES = ["auto", ...TEXT_GRAPHIC_STYLE_IDS, "none"] as const;
export type TextGraphicChoice = (typeof TEXT_GRAPHIC_CHOICES)[number];

/** New studio requests start on Auto; existing jobs (column default) stay "none". */
export const DEFAULT_TEXT_GRAPHIC_CHOICE: TextGraphicChoice = "auto";

export function isTextGraphicChoice(value: unknown): value is TextGraphicChoice {
  return typeof value === "string" && (TEXT_GRAPHIC_CHOICES as readonly string[]).includes(value);
}

export function isTextGraphicStyleId(value: unknown): value is TextGraphicStyleId {
  return typeof value === "string" && (TEXT_GRAPHIC_STYLE_IDS as readonly string[]).includes(value);
}

// ── Fonts ────────────────────────────────────────────────────────────────────

/**
 * Fonts the packs use. Served from the web app's `public/fonts/` and downloaded
 * by the phone at render time (a failed download falls back to the system bold
 * face, so the text still renders). `ascent`/`descent` are fixed fractions of
 * the font size used for LAYOUT on every platform, instead of each platform's
 * own idea of the font's line metrics, so the boxes come out the same size on
 * Android, iOS and in the browser.
 */
export interface TextGraphicFont {
  key: string;
  file: string;
  ascent: number;
  descent: number;
}

export const TEXT_GRAPHIC_FONTS: Record<string, TextGraphicFont> = {
  "kanit-500": { key: "kanit-500", file: "Kanit-Medium.ttf", ascent: 1.02, descent: 0.34 },
  "kanit-700": { key: "kanit-700", file: "Kanit-Bold.ttf", ascent: 1.02, descent: 0.34 },
  "kanit-800": { key: "kanit-800", file: "Kanit-ExtraBold.ttf", ascent: 1.02, descent: 0.34 },
  "itim-400": { key: "itim-400", file: "Itim-Regular.ttf", ascent: 0.92, descent: 0.28 },
};

// ── Motion ───────────────────────────────────────────────────────────────────

/**
 * How one part enters, as a function of its own progress p = (t - delay) / dur:
 *
 *   rise   the part slides up into view from below its own box, clipped to it
 *   wipe   revealed left-to-right (children included)
 *   pop    scales up from 0 with overshoot about its anchor
 *   fade   fades in while rising 16 px
 *   growX  scales its width from 0 at its left edge
 *   growY  scales its height from 0 at its top edge
 *   drop   falls 40 px into place with overshoot
 *
 * rise/wipe/fade/growX/growY ease out (cubic); pop/drop use the back curve.
 */
export type TextGraphicEnter = "rise" | "wipe" | "pop" | "fade" | "growX" | "growY" | "drop";

export interface TextGraphicAnim {
  kind: TextGraphicEnter;
  /** Seconds after the item's start. */
  delay: number;
  /** Seconds. */
  dur: number;
}

/** Loops once the item has been on screen 1 s. `amp` is degrees / ref px / scale fraction. */
export interface TextGraphicIdle {
  kind: "none" | "wobble" | "float" | "pulse";
  amp: number;
  period: number;
}

export interface TextGraphicExit {
  kind: "slideLeft" | "shrink" | "fade";
  dur: number;
}

export interface TextGraphicStyleSpec {
  id: TextGraphicStyleId;
  /** Fixed accent, or null for the template palette's accent. */
  accent: string | null;
  fonts: {
    title: string;
    body: string;
    badge: string;
    hook: string;
  };
  sizes: {
    title: number;
    sub: number;
    num: number;
    kicker: number;
    hookTitle: number;
    hookSub: number;
    badgeText: number;
    badgeDiameter: number;
    ctaBrand: number;
    ctaPlace: number;
    ctaButton: number;
  };
  colors: {
    cardBg: string;
    title: string;
    sub: string;
    num: string;
    bar: string;
    underline: string;
    hookBg: string;
    hookTitle: string;
    hookSub: string;
    kickerBg: string;
    kickerText: string;
    dot: string;
    badgeBg: string;
    badgeText: string;
    badgeRing: string;
    ctaBg: string;
    ctaBrand: string;
    ctaPlace: string;
    pin: string;
    buttonBg: string;
    buttonText: string;
    /** Hard (unblurred) offset shadow under cards; `shadowDx/Dy` 0 = none. */
    shadow: string;
  };
  shape: {
    cardRadius: number;
    /** Accent bar left of the label card; 0 = no bar. */
    barWidth: number;
    underline: boolean;
    badge: "circle" | "burst" | "tag";
    badgeRotate: number;
    /** Whole-item tilt in degrees (sticker look); 0 = straight. */
    tiltDeg: number;
    shadowDx: number;
    shadowDy: number;
    ctaRadius: number;
    hookDot: boolean;
    uppercaseSub: boolean;
  };
  motion: {
    bar: TextGraphicAnim;
    card: TextGraphicAnim;
    num: TextGraphicAnim;
    title: TextGraphicAnim;
    underline: TextGraphicAnim;
    sub: TextGraphicAnim;
    badge: TextGraphicAnim;
    hookBox: TextGraphicAnim;
    kicker: TextGraphicAnim;
    dot: TextGraphicAnim;
    hookTitle: TextGraphicAnim;
    hookSub: TextGraphicAnim;
    ctaCard: TextGraphicAnim;
    pin: TextGraphicAnim;
    ctaText: TextGraphicAnim;
    button: TextGraphicAnim;
    badgeIdle: TextGraphicIdle;
    buttonIdle: TextGraphicIdle;
    exit: TextGraphicExit;
  };
}

const a = (kind: TextGraphicEnter, delay: number, dur: number): TextGraphicAnim => ({
  kind,
  delay,
  dur,
});

/**
 * PREMIUM — clean and editorial: dark glass cards, an accent bar, a circular
 * stamp, masked slide-up text. Restaurants, hotels, spas, anything upmarket.
 */
const PREMIUM: TextGraphicStyleSpec = {
  id: "premium",
  accent: null,
  fonts: { title: "kanit-700", body: "kanit-500", badge: "kanit-800", hook: "kanit-800" },
  sizes: {
    title: 60,
    sub: 28,
    num: 28,
    kicker: 24,
    hookTitle: 70,
    hookSub: 34,
    badgeText: 32,
    badgeDiameter: 150,
    ctaBrand: 46,
    ctaPlace: 30,
    ctaButton: 42,
  },
  colors: {
    cardBg: "#0E0C0CC7",
    title: "#FFFFFF",
    sub: "#F3D9C9",
    num: "accent",
    bar: "accent",
    underline: "accent",
    hookBg: "#0A0808B3",
    hookTitle: "#FFFFFF",
    hookSub: "#FFFFFF",
    kickerBg: "accent",
    kickerText: "#FFFFFF",
    dot: "accent",
    badgeBg: "accent",
    badgeText: "#FFFFFF",
    badgeRing: "#FFFFFFC0",
    ctaBg: "#FFFFFF",
    ctaBrand: "#1A1414",
    ctaPlace: "#6B5A55",
    pin: "accent",
    buttonBg: "accent",
    buttonText: "#FFFFFF",
    shadow: "#00000000",
  },
  shape: {
    cardRadius: 22,
    barWidth: 12,
    underline: true,
    badge: "circle",
    badgeRotate: -14,
    tiltDeg: 0,
    shadowDx: 0,
    shadowDy: 0,
    ctaRadius: 30,
    hookDot: true,
    uppercaseSub: true,
  },
  motion: {
    bar: a("growY", 0, 0.25),
    card: a("wipe", 0.08, 0.4),
    num: a("rise", 0.12, 0.35),
    title: a("rise", 0.18, 0.45),
    underline: a("growX", 0.4, 0.5),
    sub: a("rise", 0.32, 0.4),
    badge: a("pop", 0.55, 0.45),
    hookBox: a("wipe", 0, 0.35),
    kicker: a("rise", 0.05, 0.35),
    dot: a("pop", 0.1, 0.45),
    hookTitle: a("rise", 0.18, 0.55),
    hookSub: a("rise", 0.45, 0.45),
    ctaCard: a("drop", 0, 0.45),
    pin: a("drop", 0.25, 0.5),
    ctaText: a("fade", 0.3, 0.4),
    button: a("pop", 0.45, 0.4),
    badgeIdle: { kind: "wobble", amp: 4, period: 1.4 },
    buttonIdle: { kind: "pulse", amp: 0.05, period: 1.1 },
    exit: { kind: "slideLeft", dur: 0.35 },
  },
};

/**
 * STREET FOOD — loud and fun: yellow sticker cards with a hard black shadow, a
 * slight tilt, starburst badges, everything bouncing in. Stalls, markets,
 * fast food, promotions.
 */
const STREET: TextGraphicStyleSpec = {
  id: "street",
  accent: "#E5262A",
  fonts: { title: "kanit-800", body: "kanit-700", badge: "kanit-800", hook: "kanit-800" },
  sizes: {
    title: 64,
    sub: 28,
    num: 30,
    kicker: 26,
    hookTitle: 76,
    hookSub: 34,
    badgeText: 34,
    badgeDiameter: 168,
    ctaBrand: 48,
    ctaPlace: 30,
    ctaButton: 44,
  },
  colors: {
    cardBg: "#FFD400",
    title: "#111111",
    sub: "#3A2E00",
    num: "accent",
    bar: "accent",
    underline: "#111111",
    hookBg: "#FFD400",
    hookTitle: "#111111",
    hookSub: "#3A2E00",
    kickerBg: "#111111",
    kickerText: "#FFD400",
    dot: "accent",
    badgeBg: "accent",
    badgeText: "#FFFFFF",
    badgeRing: "#00000000",
    ctaBg: "#FFD400",
    ctaBrand: "#111111",
    ctaPlace: "#3A2E00",
    pin: "accent",
    buttonBg: "accent",
    buttonText: "#FFFFFF",
    shadow: "#111111",
  },
  shape: {
    cardRadius: 10,
    barWidth: 0,
    underline: false,
    badge: "burst",
    badgeRotate: 10,
    tiltDeg: -2.5,
    shadowDx: 9,
    shadowDy: 9,
    ctaRadius: 14,
    hookDot: false,
    uppercaseSub: true,
  },
  motion: {
    bar: a("pop", 0, 0.3),
    card: a("pop", 0, 0.38),
    num: a("pop", 0.1, 0.3),
    title: a("pop", 0.12, 0.35),
    underline: a("growX", 0.3, 0.3),
    sub: a("pop", 0.22, 0.3),
    badge: a("pop", 0.32, 0.4),
    hookBox: a("pop", 0, 0.38),
    kicker: a("pop", 0.1, 0.3),
    dot: a("pop", 0.1, 0.3),
    hookTitle: a("pop", 0.16, 0.38),
    hookSub: a("pop", 0.28, 0.32),
    ctaCard: a("pop", 0, 0.4),
    pin: a("drop", 0.2, 0.45),
    ctaText: a("pop", 0.25, 0.35),
    button: a("pop", 0.35, 0.4),
    badgeIdle: { kind: "wobble", amp: 7, period: 0.9 },
    buttonIdle: { kind: "pulse", amp: 0.08, period: 0.7 },
    exit: { kind: "shrink", dur: 0.25 },
  },
};

/**
 * CAFÉ — soft and handmade: cream cards, a rounded handwritten-style Thai face,
 * tag-shaped badges, slow fades and a gentle float. Cafés, bakeries,
 * dessert shops, florists, anything cosy.
 */
const CAFE: TextGraphicStyleSpec = {
  id: "cafe",
  accent: "#C8754B",
  fonts: { title: "itim-400", body: "itim-400", badge: "itim-400", hook: "itim-400" },
  sizes: {
    title: 64,
    sub: 30,
    num: 30,
    kicker: 28,
    hookTitle: 76,
    hookSub: 36,
    badgeText: 34,
    badgeDiameter: 150,
    ctaBrand: 48,
    ctaPlace: 32,
    ctaButton: 42,
  },
  colors: {
    cardBg: "#FFF6E9F2",
    title: "#5B3A29",
    sub: "#9A6B4F",
    num: "accent",
    bar: "accent",
    underline: "accent",
    hookBg: "#FFF6E9F2",
    hookTitle: "#5B3A29",
    hookSub: "#9A6B4F",
    kickerBg: "accent",
    kickerText: "#FFFFFF",
    dot: "accent",
    badgeBg: "accent",
    badgeText: "#FFFFFF",
    badgeRing: "#FFFFFFB0",
    ctaBg: "#FFF6E9",
    ctaBrand: "#5B3A29",
    ctaPlace: "#9A6B4F",
    pin: "accent",
    buttonBg: "accent",
    buttonText: "#FFFFFF",
    shadow: "#00000000",
  },
  shape: {
    cardRadius: 40,
    barWidth: 0,
    underline: true,
    badge: "tag",
    badgeRotate: -8,
    tiltDeg: 0,
    shadowDx: 0,
    shadowDy: 0,
    ctaRadius: 44,
    hookDot: false,
    uppercaseSub: false,
  },
  motion: {
    bar: a("fade", 0, 0.5),
    card: a("fade", 0, 0.6),
    num: a("fade", 0.15, 0.6),
    title: a("fade", 0.2, 0.6),
    underline: a("growX", 0.5, 0.7),
    sub: a("fade", 0.35, 0.6),
    badge: a("fade", 0.6, 0.6),
    hookBox: a("fade", 0, 0.6),
    kicker: a("fade", 0.15, 0.6),
    dot: a("fade", 0.15, 0.6),
    hookTitle: a("fade", 0.25, 0.7),
    hookSub: a("fade", 0.45, 0.6),
    ctaCard: a("fade", 0, 0.6),
    pin: a("fade", 0.2, 0.6),
    ctaText: a("fade", 0.3, 0.6),
    button: a("fade", 0.45, 0.6),
    badgeIdle: { kind: "float", amp: 6, period: 2.4 },
    buttonIdle: { kind: "float", amp: 4, period: 2.4 },
    exit: { kind: "fade", dur: 0.5 },
  },
};

export const TEXT_GRAPHIC_STYLES: Record<TextGraphicStyleId, TextGraphicStyleSpec> = {
  premium: PREMIUM,
  street: STREET,
  cafe: CAFE,
};

export function getTextGraphicStyle(id: TextGraphicStyleId): TextGraphicStyleSpec {
  return TEXT_GRAPHIC_STYLES[id] ?? PREMIUM;
}

/** The font keys a pack draws with, deduplicated. */
export function fontsForStyle(style: TextGraphicStyleSpec): TextGraphicFont[] {
  const keys = new Set(Object.values(style.fonts));
  return [...keys].map((key) => TEXT_GRAPHIC_FONTS[key]).filter(Boolean);
}

/** Where the font files are served, relative to the app origin. */
export function textGraphicFontPath(font: TextGraphicFont): string {
  return `/fonts/${font.file}`;
}
