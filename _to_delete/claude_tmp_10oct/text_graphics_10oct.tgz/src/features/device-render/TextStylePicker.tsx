"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
  TEXT_GRAPHIC_CHOICES,
  TEXT_GRAPHIC_STYLE_IDS,
  getTextGraphicStyle,
  type TextGraphicChoice,
  type TextGraphicStyleId,
} from "@/config/textGraphicStyles";
import {
  drawTextGraphicsFrame,
  layoutItems,
  loadTextGraphicFonts,
} from "@/lib/textGraphics/canvasRenderer";
import {
  sanitizeTextGraphicItems,
  sceneWindows,
  type ManifestTextGraphics,
  type TextGraphicItem,
  type TextGraphicsPlan,
} from "@/lib/textGraphics/plan";
import type { TgItemLayout } from "@/lib/textGraphics/layout";
import { DEVICE_SCENE_CROSSFADE_SECONDS } from "@/lib/mobile/deviceRenderCaptions";
import { shotPlaySeconds, type EditorDocument } from "./editorState";
import { useStudioT, type StudioT } from "./studioI18n";

/**
 * Graphic → Text graphics: pick the style pack the scene titles are drawn in,
 * and preview them.
 *
 * Every option plays an animated example over this request's first picture
 * (sample words, the pack's own motion). "Preview with your video" then asks
 * the server for the real plan — the words Claude writes for THESE scenes —
 * and plays it over the scene pictures on the edit's own timeline. Both are
 * drawn by `canvasRenderer.ts`, the browser twin of the phone renderers.
 */

const FRAME: Record<string, { width: number; height: number }> = {
  "9:16": { width: 1080, height: 1920 },
  "16:9": { width: 1920, height: 1080 },
  "1:1": { width: 1080, height: 1080 },
  "4:5": { width: 1080, height: 1350 },
};

function frameFor(ratio: string) {
  return FRAME[ratio] ?? FRAME["9:16"];
}

const DEFAULT_ACCENT = "#D7262E";
const SAMPLE_LOOP = 9.8;

function loadImage(url: string | null): Promise<HTMLImageElement | null> {
  if (!url) return Promise.resolve(null);
  return new Promise((resolve) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => resolve(null);
    image.src = url;
  });
}

function drawCover(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement | null,
  width: number,
  height: number
) {
  if (!image) {
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, "#3a4455");
    gradient.addColorStop(1, "#141821");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    return;
  }
  const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
  const w = image.naturalWidth * scale;
  const h = image.naturalHeight * scale;
  ctx.drawImage(image, (width - w) / 2, (height - h) / 2, w, h);
}

/** Sample words for the examples, in the studio's language. */
function sampleItems(t: StudioT, brand: string): TextGraphicItem[] {
  const blank = { sub: "", kicker: "", num: "", badge: "", brand: "", place: "" };
  return sanitizeTextGraphicItems(
    [
      {
        ...blank,
        kind: "hook",
        start: 0.2,
        end: 3.0,
        title: brand || t("studio.text.sample.hook"),
        sub: t("studio.text.sample.hookSub"),
        kicker: t("studio.text.sample.kicker"),
      },
      {
        ...blank,
        kind: "label",
        start: 3.3,
        end: 6.3,
        title: t("studio.text.sample.label"),
        sub: t("studio.text.sample.labelSub"),
        badge: t("studio.text.sample.badge"),
      },
      {
        ...blank,
        kind: "cta",
        start: 6.6,
        end: 9.6,
        title: t("studio.text.sample.cta"),
        brand: brand || t("studio.text.sample.hook"),
        place: t("studio.text.sample.place"),
      },
    ],
    SAMPLE_LOOP
  );
}

/** Run `draw(t)` on animation frames while the canvas is on screen. */
function useCanvasLoop(
  canvas: React.RefObject<HTMLCanvasElement | null>,
  draw: (seconds: number) => void,
  running: boolean
) {
  const drawRef = useRef(draw);
  drawRef.current = draw;
  useEffect(() => {
    const element = canvas.current;
    if (!element || !running) return;
    let visible = true;
    let frame = 0;
    const started = performance.now();
    const observer =
      typeof IntersectionObserver !== "undefined"
        ? new IntersectionObserver((entries) => {
            visible = entries.some((entry) => entry.isIntersecting);
          })
        : null;
    observer?.observe(element);
    const tick = (now: number) => {
      if (visible && document.visibilityState === "visible") {
        drawRef.current((now - started) / 1000);
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
    };
  }, [canvas, running]);
}

/** Size the canvas backing store for the device pixel ratio; returns the 2D context. */
function prepareCanvas(
  element: HTMLCanvasElement,
  cssWidth: number,
  cssHeight: number,
  frame: { width: number; height: number }
): CanvasRenderingContext2D | null {
  const dpr = Math.min(2, typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1);
  const pw = Math.round(cssWidth * dpr);
  const ph = Math.round(cssHeight * dpr);
  if (element.width !== pw || element.height !== ph) {
    element.width = pw;
    element.height = ph;
  }
  const ctx = element.getContext("2d");
  if (!ctx) return null;
  ctx.setTransform(pw / frame.width, 0, 0, ph / frame.height, 0, 0);
  return ctx;
}

function TextStyleExample({
  choice,
  pictureUrl,
  ratio,
  height,
  brand,
  alt,
}: {
  choice: TextGraphicChoice;
  pictureUrl: string | null;
  ratio: string;
  height: number;
  brand: string;
  alt: string;
}) {
  const t = useStudioT();
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const frame = frameFor(ratio);
  const cssHeight = height;
  const cssWidth = Math.round((height * frame.width) / frame.height);
  const [picture, setPicture] = useState<HTMLImageElement | null>(null);
  const [fontsReady, setFontsReady] = useState(false);
  const layouts = useRef<Map<string, TgItemLayout[]>>(new Map());

  useEffect(() => {
    let live = true;
    void loadImage(pictureUrl).then((image) => live && setPicture(image));
    return () => {
      live = false;
    };
  }, [pictureUrl]);

  useEffect(() => {
    let live = true;
    void loadTextGraphicFonts().then(() => {
      if (!live) return;
      layouts.current.clear();
      setFontsReady(true);
    });
    return () => {
      live = false;
    };
  }, []);

  const items = useMemo(() => sampleItems(t, brand), [t, brand]);
  useEffect(() => layouts.current.clear(), [items, ratio]);

  const draw = useCallback(
    (seconds: number) => {
      const element = canvas.current;
      if (!element) return;
      const ctx = prepareCanvas(element, cssWidth, cssHeight, frame);
      if (!ctx) return;
      drawCover(ctx, picture, frame.width, frame.height);
      if (choice === "none") return;
      const loop = Math.floor(seconds / SAMPLE_LOOP);
      const styleId: TextGraphicStyleId =
        choice === "auto" ? TEXT_GRAPHIC_STYLE_IDS[loop % TEXT_GRAPHIC_STYLE_IDS.length] : choice;
      const style = getTextGraphicStyle(styleId);
      let layout = layouts.current.get(styleId);
      if (!layout) {
        layout = layoutItems(ctx, items, style, style.accent ?? DEFAULT_ACCENT, frame.width, frame.height);
        layouts.current.set(styleId, layout);
      }
      drawTextGraphicsFrame(ctx, layout, style, frame.width, frame.height, seconds % SAMPLE_LOOP);
    },
    [choice, cssHeight, cssWidth, frame, items, picture]
  );

  useCanvasLoop(canvas, draw, fontsReady);

  return (
    <canvas
      ref={canvas}
      className="studio-look-frame"
      style={{ width: cssWidth, height: cssHeight }}
      role="img"
      aria-label={alt}
    />
  );
}

export interface TextGraphicsPreviewResult {
  plan: TextGraphicsPlan | null;
  textGraphics: ManifestTextGraphics | null;
}

/** The edit's shots on the picture timeline, for the preview player. */
function shotTimeline(document: EditorDocument) {
  const scenes = document.scenes.filter((scene) => scene.shots.length > 0);
  const windows = sceneWindows(
    scenes.map((scene) => ({
      seconds: scene.shots.reduce((sum, shot) => sum + shotPlaySeconds(shot), 0),
    })),
    DEVICE_SCENE_CROSSFADE_SECONDS
  );
  const shots: { start: number; end: number; url: string | null }[] = [];
  scenes.forEach((scene, index) => {
    let cursor = windows[index]?.start ?? 0;
    for (const shot of scene.shots) {
      const source = document.sources.find((s) => s.id === shot.sourceId);
      const seconds = shotPlaySeconds(shot);
      shots.push({
        start: cursor,
        end: cursor + seconds,
        url: source?.posterUrl ?? (source?.kind === "image" ? source.previewUrl : null),
      });
      cursor += seconds;
    }
  });
  return shots;
}

function TextGraphicsPreview({
  document,
  ratio,
  result,
}: {
  document: EditorDocument;
  ratio: string;
  result: TextGraphicsPreviewResult;
}) {
  const t = useStudioT();
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const frame = frameFor(ratio);
  const cssHeight = 360;
  const cssWidth = Math.round((cssHeight * frame.width) / frame.height);
  const shots = useMemo(() => shotTimeline(document), [document]);
  const [images, setImages] = useState<(HTMLImageElement | null)[]>([]);
  const [fontsReady, setFontsReady] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [position, setPosition] = useState(0);
  const offset = useRef(0);
  const layout = useRef<TgItemLayout[] | null>(null);
  const duration = Math.max(
    result.plan?.durationSeconds ?? 0,
    shots.length > 0 ? shots[shots.length - 1].end : 0,
    1
  );

  useEffect(() => {
    let live = true;
    void Promise.all(shots.map((shot) => loadImage(shot.url))).then((loaded) => live && setImages(loaded));
    return () => {
      live = false;
    };
  }, [shots]);

  useEffect(() => {
    let live = true;
    void loadTextGraphicFonts().then(() => live && setFontsReady(true));
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    layout.current = null;
  }, [result, ratio, fontsReady]);

  const paint = useCallback(
    (at: number) => {
      const element = canvas.current;
      if (!element) return;
      const ctx = prepareCanvas(element, cssWidth, cssHeight, frame);
      if (!ctx) return;
      const index = shots.findIndex((shot) => at >= shot.start && at < shot.end);
      const image = images[index >= 0 ? index : shots.length - 1] ?? null;
      drawCover(ctx, image, frame.width, frame.height);
      const tg = result.textGraphics;
      if (!tg) return;
      if (!layout.current) {
        layout.current = layoutItems(ctx, tg.items, tg.style, tg.accent, frame.width, frame.height);
      }
      drawTextGraphicsFrame(ctx, layout.current, tg.style, frame.width, frame.height, at);
    },
    [cssHeight, cssWidth, frame, images, result.textGraphics, shots]
  );

  const draw = useCallback(
    (seconds: number) => {
      const at = (offset.current + seconds) % duration;
      paint(at);
      setPosition(at);
    },
    [duration, paint]
  );
  useCanvasLoop(canvas, draw, fontsReady && playing);

  useEffect(() => {
    if (!playing && fontsReady) paint(position);
  }, [fontsReady, paint, playing, position]);

  return (
    <div className="studio-text-preview">
      <canvas
        ref={canvas}
        className="studio-look-frame"
        style={{ width: cssWidth, height: cssHeight }}
        role="img"
        aria-label={t("studio.text.previewTitle")}
      />
      <div className="studio-text-preview-controls">
        <button
          type="button"
          className="studio-button"
          onClick={() => {
            if (playing) setPlaying(false);
            else {
              offset.current = position;
              setPlaying(true);
            }
          }}
        >
          {playing ? t("studio.text.pause") : t("studio.text.play")}
        </button>
        <input
          type="range"
          min={0}
          max={duration}
          step={0.05}
          value={position}
          aria-label={t("studio.text.previewTitle")}
          onChange={(event) => {
            setPlaying(false);
            setPosition(Number(event.target.value));
          }}
        />
        <span className="studio-counter">
          {position.toFixed(1)} / {duration.toFixed(1)} s
        </span>
      </div>
    </div>
  );
}

export function TextStylePicker({
  document,
  ratio,
  pictureUrl,
  choice,
  onChoice,
  loadPreview,
  locked,
  disabled,
}: {
  document: EditorDocument;
  ratio: string;
  pictureUrl: string | null;
  choice: TextGraphicChoice;
  onChoice: (choice: TextGraphicChoice) => void;
  /** Ask the server for the real plan for this edit; null when not possible yet. */
  loadPreview: ((choice: TextGraphicChoice, fresh: boolean) => Promise<TextGraphicsPreviewResult>) | null;
  locked: boolean;
  disabled: boolean;
}) {
  const t = useStudioT();
  const brand = document.brief.placeName.trim();
  const [preview, setPreview] = useState<{ choice: TextGraphicChoice; result: TextGraphicsPreviewResult } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // A preview belongs to the style it was written for, and to the edit as it was.
  useEffect(() => {
    setPreview((current) => (current && current.choice === choice ? current : null));
    setError(null);
  }, [choice]);
  useEffect(() => {
    setPreview(null);
  }, [document.scenes, document.musicTrackId]);

  const run = useCallback(
    async (fresh: boolean) => {
      if (!loadPreview || choice === "none") return;
      setLoading(true);
      setError(null);
      try {
        const result = await loadPreview(choice, fresh);
        setPreview({ choice, result });
      } catch {
        setError(t("studio.text.previewFailed"));
      } finally {
        setLoading(false);
      }
    },
    [choice, loadPreview, t]
  );

  const picked = preview?.result.plan;
  return (
    <div className="studio-text-section">
      <h3 className="studio-panel-title">{t("studio.text.title")}</h3>
      <p className="studio-panel-hint">{t("studio.text.hint")}</p>

      <div className="studio-look-grid" role="radiogroup" aria-label={t("studio.text.title")}>
        {TEXT_GRAPHIC_CHOICES.map((option) => {
          const selected = choice === option;
          const name = t(`studio.text.${option}.name`);
          return (
            <button
              key={option}
              type="button"
              role="radio"
              aria-checked={selected}
              disabled={disabled || locked}
              onClick={() => onChoice(option)}
              className="studio-look"
            >
              <TextStyleExample
                choice={option}
                pictureUrl={pictureUrl}
                ratio={ratio}
                height={200}
                brand={brand}
                alt={t("studio.text.exampleAlt", { name })}
              />
              <span className="studio-look-name">
                {selected ? "✓ " : ""}
                {name}
              </span>
              <span className="studio-look-description">{t(`studio.text.${option}.description`)}</span>
            </button>
          );
        })}
      </div>

      {choice !== "none" && loadPreview && (
        <div className="studio-text-preview-box">
          <h3 className="studio-panel-title">{t("studio.text.previewTitle")}</h3>
          <p className="studio-panel-hint">{t("studio.text.previewHint")}</p>
          {preview ? (
            <>
              <TextGraphicsPreview document={document} ratio={ratio} result={preview.result} />
              {picked && choice === "auto" && (
                <p className="studio-counter" style={{ textAlign: "left" }}>
                  {t("studio.text.previewPicked", { name: t(`studio.text.${picked.styleId}.name`) })}
                </p>
              )}
              {picked?.source === "fallback" && (
                <p className="studio-counter" style={{ textAlign: "left" }}>
                  {t("studio.text.previewFallback")}
                </p>
              )}
              {!locked && (
                <button
                  type="button"
                  className="studio-button"
                  disabled={disabled || loading}
                  onClick={() => void run(true)}
                >
                  {loading ? t("studio.text.previewLoading") : t("studio.text.previewAgain")}
                </button>
              )}
            </>
          ) : (
            <button
              type="button"
              className="studio-button"
              disabled={disabled || loading}
              onClick={() => void run(false)}
            >
              {loading ? t("studio.text.previewLoading") : t("studio.text.previewMake")}
            </button>
          )}
          {error && (
            <p className="studio-note studio-note-danger" role="alert" style={{ marginTop: 8 }}>
              {error}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
