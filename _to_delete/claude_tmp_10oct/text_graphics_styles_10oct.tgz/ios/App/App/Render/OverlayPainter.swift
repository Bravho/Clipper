import UIKit
import CoreGraphics
import QuartzCore
import AVFoundation

/// Draws the caption stack and builds the template layer, matching the server's
/// styled render, `remotion/TemplatedVideo.tsx`.
///
/// The counterpart of Android's `CaptionPainter` and `TemplatePainter`; every
/// number is read off that composition (and restated in
/// `src/lib/mobile/deviceRenderCaptions.ts`). iOS differs in HOW, not in what:
/// the final export uses `AVVideoCompositionCoreAnimationTool`, so a caption cue
/// is drawn once into an image and timed by Core Animation, and the template is
/// a tree of `CAShapeLayer`s whose draw-on strokes, bracket ease-in and pulsing
/// ripples are ordinary Core Animation animations on the video's timeline.
///
/// Lengths use the composition's scale, `s = min(width, height) / 1080`.
enum OverlayPainter {

    // ── Captions, from `Subtitles` in TemplatedVideo.tsx ───────────────────
    private static let referenceShortSide: CGFloat = 1080
    static let stackBottom: CGFloat = 150
    private static let lineGap: CGFloat = 16
    private static let sidePadding: CGFloat = 48
    private static let lineHeight: CGFloat = 1.22
    private static let strokeWidth: CGFloat = 6
    /// The composition's text-shadow is plain CSS pixels (unscaled).
    private static let shadowOffset = CGSize(width: 3, height: 3)
    private static let shadowBlur: CGFloat = 6
    private static let plateRadius: CGFloat = 18
    private static let platePaddingY: CGFloat = 10
    private static let platePaddingX: CGFloat = 26
    private static let plateAlpha: CGFloat = 0.4
    static let appearSeconds: Double = 0.15
    static let appearScaleFrom: CGFloat = 0.96

    /// The composition's single scaling rule: the short side against 1080.
    static func scale(for canvas: CGSize) -> CGFloat {
        min(canvas.width, canvas.height) / referenceShortSide
    }

    private static func fontSize(for language: String) -> CGFloat {
        switch language {
        case "th": return 62
        case "en": return 52
        case "zh": return 50
        default: return 52
        }
    }

    /// Longer than this, a cue is split into two balanced lines.
    private static func maxChars(for language: String) -> Int {
        switch language {
        case "th": return 26
        case "en": return 30
        case "zh": return 16
        default: return 30
        }
    }

    private static func color(for language: String) -> UIColor {
        language == "zh"
            ? UIColor(red: 1, green: 0xE0 / 255, blue: 0x66 / 255, alpha: 1)
            : .white
    }

    /// Weight 800 maps to the heaviest system weight iOS offers for the default
    /// family; Thai and Simplified Chinese come through font fallback, as they
    /// do in the composition's font stacks.
    private static func font(size: CGFloat) -> UIFont {
        UIFont.systemFont(ofSize: size, weight: .heavy)
    }

    /// The drawn cue plus its size, so the caller can place the layer.
    struct DrawnCaption {
        let image: UIImage
        let size: CGSize
    }

    /// `wrapCaption`: one line at or under the language's budget, otherwise
    /// two lines balanced by length on word boundaries — spaces for English,
    /// the system's dictionary word breaks for Thai and Chinese (the same ICU
    /// data `Intl.Segmenter` uses in the browser).
    static func wrapCaption(_ text: String, maxChars: Int) -> [String] {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count > maxChars else { return [trimmed] }
        if trimmed.rangeOfCharacter(from: .whitespaces) != nil {
            let words = trimmed.split(whereSeparator: { $0.isWhitespace }).map(String.init)
            return balanceTwoLines(words, joiner: " ")
        }
        var units: [String] = []
        trimmed.enumerateSubstrings(
            in: trimmed.startIndex..<trimmed.endIndex, options: .byWords
        ) { _, _, enclosingRange, _ in
            // The ENCLOSING range carries the punctuation after a word too, so
            // joining the units gives back the whole caption.
            units.append(String(trimmed[enclosingRange]))
        }
        if units.isEmpty || units.joined() != trimmed {
            units = trimmed.map { String($0) }
        }
        return balanceTwoLines(units, joiner: "")
    }

    private static func balanceTwoLines(_ units: [String], joiner: String) -> [String] {
        guard units.count >= 2 else { return [units.joined(separator: joiner)] }
        let total = units.reduce(0) { $0 + $1.count } + joiner.count * (units.count - 1)
        let target = Int((Double(total) / 2).rounded(.up))
        var accumulated = 0
        var best = 1
        var bestDiff = Int.max
        for index in 0..<(units.count - 1) {
            accumulated += units[index].count + joiner.count
            let diff = abs(accumulated - target)
            if diff < bestDiff {
                bestDiff = diff
                best = index + 1
            }
        }
        return [
            units[0..<best].joined(separator: joiner),
            units[best...].joined(separator: joiner),
        ]
    }

    /// Render one cue's whole stack — every requested language, plates and all —
    /// into a single image sized to the canvas width.
    ///
    /// Returns nil when the cue has no text in any requested language, so the
    /// caller adds no layer for it rather than an invisible one.
    static func drawCaption(
        _ caption: RenderManifest.Caption,
        languages: [String],
        canvas: CGSize
    ) -> DrawnCaption? {
        let s = scale(for: canvas)
        let maxTextWidth = canvas.width - 2 * sidePadding * s - 2 * platePaddingX * s
        guard maxTextWidth > 0 else { return nil }

        struct Line {
            let attributed: NSAttributedString
            let textSize: CGSize
        }

        var lines: [Line] = []
        for language in languages {
            let text = caption.text(for: language)
            guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }

            let size = fontSize(for: language) * s
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            paragraph.lineHeightMultiple = lineHeight
            paragraph.lineBreakMode = .byWordWrapping

            let attributes: [NSAttributedString.Key: Any] = [
                .font: font(size: size),
                .foregroundColor: color(for: language),
                .paragraphStyle: paragraph,
            ]
            let wrapped = wrapCaption(text, maxChars: maxChars(for: language))
                .joined(separator: "\n")
            let attributed = NSAttributedString(string: wrapped, attributes: attributes)

            let bounding = attributed.boundingRect(
                with: CGSize(width: maxTextWidth, height: .greatestFiniteMagnitude),
                options: [.usesLineFragmentOrigin, .usesFontLeading],
                context: nil
            )
            lines.append(Line(
                attributed: attributed,
                textSize: CGSize(width: ceil(bounding.width), height: ceil(bounding.height))
            ))
        }
        guard !lines.isEmpty else { return nil }

        let gap = lineGap * s
        var stackHeight: CGFloat = 0
        for (index, line) in lines.enumerated() {
            stackHeight += line.textSize.height + 2 * platePaddingY * s
            if index > 0 { stackHeight += gap }
        }

        let canvasSize = CGSize(width: canvas.width, height: stackHeight)
        let renderer = UIGraphicsImageRenderer(size: canvasSize, format: transparentFormat())
        let image = renderer.image { context in
            var y: CGFloat = 0
            for line in lines {
                let plateHeight = line.textSize.height + 2 * platePaddingY * s
                let plateWidth = line.textSize.width + 2 * platePaddingX * s
                let plateRect = CGRect(
                    x: (canvas.width - plateWidth) / 2, y: y,
                    width: plateWidth, height: plateHeight
                )

                context.cgContext.setShadow(offset: .zero, blur: 0, color: nil)
                UIColor.black.withAlphaComponent(plateAlpha).setFill()
                UIBezierPath(roundedRect: plateRect, cornerRadius: plateRadius * s).fill()

                let textRect = CGRect(
                    x: (canvas.width - line.textSize.width) / 2,
                    y: y + platePaddingY * s,
                    width: line.textSize.width,
                    height: line.textSize.height
                )

                // `paint-order: stroke fill`, done as TWO passes. A negative
                // stroke width ("stroke and fill" in one pass) draws the fill
                // FIRST and the outline ON TOP, so half the outline ate into
                // the letters — fatal for Thai's thin loops and small heads —
                // and the per-glyph shadow fell across neighbouring glyphs.
                //
                // Pass 1: outline only (positive width), carrying the shadow.
                // CSS strokes 6px centred on the outline and the fill hides
                // the inner half, so the stroke is drawn at full width here.
                context.cgContext.saveGState()
                context.cgContext.setShadow(
                    offset: shadowOffset,
                    blur: shadowBlur,
                    color: UIColor.black.withAlphaComponent(0.9).cgColor
                )
                let outline = NSMutableAttributedString(attributedString: line.attributed)
                outline.addAttributes([
                    .strokeColor: UIColor.black,
                    .strokeWidth: (2 * strokeWidth * s) / (fontSizeOf(line.attributed) / 100),
                ], range: NSRange(location: 0, length: outline.length))
                outline.draw(with: textRect, options: [.usesLineFragmentOrigin], context: nil)
                context.cgContext.restoreGState()

                // Pass 2: the plain fill on top, no stroke and no shadow, so
                // every letterform keeps its full shape and colour.
                context.cgContext.setShadow(offset: .zero, blur: 0, color: nil)
                line.attributed.draw(with: textRect, options: [.usesLineFragmentOrigin], context: nil)

                y += plateHeight + gap
            }
        }
        return DrawnCaption(image: image, size: canvasSize)
    }

    /// `NSAttributedString.strokeWidth` is a PERCENTAGE of the font size, not a
    /// point value, which is the single easiest thing to get wrong here — a
    /// 6-point outline written as `6` is a 6% outline that all but disappears.
    private static func fontSizeOf(_ attributed: NSAttributedString) -> CGFloat {
        guard attributed.length > 0,
              let font = attributed.attribute(.font, at: 0, effectiveRange: nil) as? UIFont
        else { return 52 }
        return font.pointSize
    }

    // ── Template ────────────────────────────────────────────────────────────

    /// The composition's look for a template: chosen by id, as the composition
    /// chooses it, with the catalogue's frame as the fallback for an id this
    /// build does not know.
    static func look(_ template: RenderManifest.Template) -> String {
        switch template.id {
        case "clean_frame", "framed_cream", "editorial", "none":
            return template.id
        default:
            if template.frame == "rounded_inset" { return "framed_cream" }
            if template.frame == "corner_bracket" { return "clean_frame" }
            return "none"
        }
    }

    static func hasTemplate(_ template: RenderManifest.Template) -> Bool {
        look(template) != "none"
    }

    /// framed_cream shows the video inside a card rather than full-bleed.
    static func isInset(_ template: RenderManifest.Template) -> Bool {
        look(template) == "framed_cream"
    }

    /// The card: top 6.5 %, left/right 5.5 %, bottom 13 % (top-left origin).
    private static func cardRect(_ canvas: CGSize) -> CGRect {
        CGRect(x: canvas.width * 0.055, y: canvas.height * 0.065,
               width: canvas.width * (1 - 0.11), height: canvas.height * (1 - 0.065 - 0.13))
    }

    /// The video's window inside the card (22 px of padding), top-left origin.
    static func insetWindow(_ canvas: CGSize) -> CGRect {
        cardRect(canvas).insetBy(dx: 22, dy: 22)
    }

    /// Where the video layer goes for the inset look, in Core Animation's
    /// bottom-left coordinates: the full canvas scaled to COVER the window and
    /// centred on it (the composition's `objectFit: cover`). The overflow sits
    /// under the card and canvas the template layer draws on top.
    static func insetVideoFrame(_ canvas: CGSize) -> CGRect {
        let window = insetWindow(canvas)
        let scale = max(window.width / canvas.width, window.height / canvas.height)
        let size = CGSize(width: canvas.width * scale, height: canvas.height * scale)
        let centerX = window.midX
        let centerYFromBottom = canvas.height - window.midY
        return CGRect(x: centerX - size.width / 2, y: centerYFromBottom - size.height / 2,
                      width: size.width, height: size.height)
    }

    /// The animated template layer for `AVVideoCompositionCoreAnimationTool`,
    /// or nil for "none". Drawn in top-left coordinates inside a
    /// geometry-flipped container, timed from `AVCoreAnimationBeginTimeAtZero`.
    static func templateLayer(_ template: RenderManifest.Template, canvas: CGSize) -> CALayer? {
        let look = look(template)
        guard look != "none" else { return nil }
        let palette = Palette(template.palette)
        let s = scale(for: canvas)

        let container = CALayer()
        container.frame = CGRect(origin: .zero, size: canvas)
        container.isGeometryFlipped = true

        switch look {
        case "clean_frame":
            buildCleanFrame(in: container, canvas: canvas, s: s, palette: palette)
        case "framed_cream":
            buildFramedCream(in: container, canvas: canvas, s: s, palette: palette)
        case "editorial":
            buildEditorial(in: container, canvas: canvas, s: s, palette: palette)
        default:
            break
        }
        return container
    }

    // clean_frame: brackets ease in over 0.7 s, two ripples pulse from the
    // bottom-left every 3.6 s, an accent bar at the top centre.
    private static func buildCleanFrame(
        in container: CALayer, canvas: CGSize, s: CGFloat, palette: Palette
    ) {
        let size = 90 * s
        let inset = 44 * s
        let border = max(3, 7 * s)
        let radius = 22 * s
        let slide = 20 * s

        let corners: [(CGFloat, CGFloat, CGFloat, CGFloat)] = [
            (inset, inset, 1, 1),
            (canvas.width - inset, inset, -1, 1),
            (inset, canvas.height - inset, 1, -1),
            (canvas.width - inset, canvas.height - inset, -1, -1),
        ]
        for (x, y, dx, dy) in corners {
            let path = bracketPath(x: x, y: y, size: size, border: border, radius: radius, dx: dx, dy: dy)
            let layer = CAShapeLayer()
            layer.frame = container.bounds
            layer.path = path
            layer.fillColor = nil
            layer.strokeColor = UIColor.white.cgColor
            layer.lineWidth = border
            layer.shadowColor = UIColor.black.cgColor
            layer.shadowOpacity = 0.55
            layer.shadowRadius = 2
            layer.shadowOffset = CGSize(width: 0, height: 1)
            layer.opacity = 0.95
            container.addSublayer(layer)

            // Fade up and slide in from the corner over 0.7 s, then hold.
            let fade = CABasicAnimation(keyPath: "opacity")
            fade.fromValue = 0
            fade.toValue = 0.95
            let move = CABasicAnimation(keyPath: "transform.translation")
            move.fromValue = NSValue(cgSize: CGSize(width: -dx * slide, height: -dy * slide))
            move.toValue = NSValue(cgSize: .zero)
            for animation in [fade, move] {
                animation.beginTime = AVCoreAnimationBeginTimeAtZero
                animation.duration = 0.7
                animation.fillMode = .both
                animation.isRemovedOnCompletion = false
                layer.add(animation, forKey: nil)
            }
        }

        // Ripples: diameter 0.15 → 1 of 32 % of the short side, opacity
        // 0 → 0.5 → 0 over each 3.6 s period, the second offset by 1.8 s.
        let maxDiameter = min(canvas.width, canvas.height) * 0.32
        let center = CGPoint(x: canvas.width * 0.13, y: canvas.height * 0.84)
        let ringWidth = max(2, 2.5 * s)
        for delay in [0.0, 1.8] {
            let ring = CAShapeLayer()
            let r = maxDiameter / 2 - ringWidth / 2
            ring.frame = CGRect(x: center.x - maxDiameter / 2, y: center.y - maxDiameter / 2,
                                width: maxDiameter, height: maxDiameter)
            ring.path = UIBezierPath(
                ovalIn: CGRect(x: ringWidth / 2, y: ringWidth / 2, width: r * 2, height: r * 2)).cgPath
            ring.fillColor = nil
            ring.strokeColor = palette.accent.cgColor
            ring.lineWidth = ringWidth
            ring.opacity = 0
            container.addSublayer(ring)

            let grow = CABasicAnimation(keyPath: "transform.scale")
            grow.fromValue = 0.15
            grow.toValue = 1.0
            let pulse = CAKeyframeAnimation(keyPath: "opacity")
            pulse.values = [0, 0.5, 0]
            pulse.keyTimes = [0, 0.15, 1]
            let group = CAAnimationGroup()
            group.animations = [grow, pulse]
            group.duration = 3.6
            group.repeatCount = .greatestFiniteMagnitude
            // The time offset starts the second ring half a period in, as the
            // composition's `(t + delay) % period` does.
            group.beginTime = AVCoreAnimationBeginTimeAtZero
            group.timeOffset = delay
            group.fillMode = .both
            group.isRemovedOnCompletion = false
            ring.add(group, forKey: nil)
        }

        let bar = CAShapeLayer()
        bar.frame = container.bounds
        bar.path = UIBezierPath(
            roundedRect: CGRect(x: (canvas.width - 56 * s) / 2, y: 54 * s, width: 56 * s, height: 5 * s),
            cornerRadius: 5 * s).cgPath
        bar.fillColor = palette.accent.cgColor
        bar.opacity = 0.9
        container.addSublayer(bar)
        bar.add(fadeIn(to: 0.9, begin: 0, duration: 0.7), forKey: nil)
    }

    private static func bracketPath(
        x: CGFloat, y: CGFloat, size: CGFloat, border: CGFloat, radius: CGFloat, dx: CGFloat, dy: CGFloat
    ) -> CGPath {
        let half = border / 2
        let cx = x + dx * half
        let cy = y + dy * half
        let r = max(0, radius - half)
        let path = CGMutablePath()
        path.move(to: CGPoint(x: x + dx * size, y: cy))
        path.addLine(to: CGPoint(x: cx + dx * r, y: cy))
        path.addQuadCurve(to: CGPoint(x: cx, y: cy + dy * r), control: CGPoint(x: cx, y: cy))
        path.addLine(to: CGPoint(x: cx, y: y + dy * size))
        return path
    }

    // framed_cream: the video inset in a white card on the warm neutral canvas,
    // with a branch, a wave and three dots drawn on in the bottom margin and an
    // accent sparkle, all drawing on between 0.2 s and 1.6 s.
    private static func buildFramedCream(
        in container: CALayer, canvas: CGSize, s: CGFloat, palette: Palette
    ) {
        let card = cardRect(canvas)
        let window = insetWindow(canvas)

        // Canvas + card with the window punched out, as one even-odd shape.
        let surround = CAShapeLayer()
        surround.frame = container.bounds
        let surroundPath = CGMutablePath()
        surroundPath.addRect(CGRect(origin: .zero, size: canvas))
        surroundPath.addPath(UIBezierPath(roundedRect: window, cornerRadius: 22).cgPath)
        surround.path = surroundPath
        surround.fillRule = .evenOdd
        surround.fillColor = palette.neutral.cgColor
        container.addSublayer(surround)

        let cardLayer = CAShapeLayer()
        cardLayer.frame = container.bounds
        let cardPath = CGMutablePath()
        cardPath.addPath(UIBezierPath(roundedRect: card, cornerRadius: 34).cgPath)
        cardPath.addPath(UIBezierPath(roundedRect: window, cornerRadius: 22).cgPath)
        cardLayer.path = cardPath
        cardLayer.fillRule = .evenOdd
        cardLayer.fillColor = UIColor.white.cgColor
        // 0 16px 42px rgba(0,0,0,0.22)
        cardLayer.shadowColor = UIColor.black.cgColor
        cardLayer.shadowOpacity = 0.22
        cardLayer.shadowRadius = 21
        cardLayer.shadowOffset = CGSize(width: 0, height: 16)
        // The shadow is shaped like the card WITH its window, so it never falls
        // across the video. A shadow path fills non-zero, so the window is
        // added in the opposite winding to cut it out.
        let shadowPath = CGMutablePath()
        shadowPath.addPath(UIBezierPath(roundedRect: card, cornerRadius: 34).cgPath)
        shadowPath.addPath(UIBezierPath(roundedRect: window, cornerRadius: 22).reversing().cgPath)
        cardLayer.shadowPath = shadowPath
        container.addSublayer(cardLayer)

        let ink = palette.primary
        let strokeWidth = max(2.5, 3.2 * s)
        let dash = canvas.width * 2

        // The botanical branch in its own units, scaled by s (stroke too).
        let branchPaths: [CGPath] = {
            var paths: [CGPath] = []
            let main = CGMutablePath()
            main.move(to: CGPoint(x: 0, y: 60))
            main.addCurve(to: CGPoint(x: 190, y: 6), control1: CGPoint(x: 60, y: 44),
                          control2: CGPoint(x: 120, y: 40))
            paths.append(main)
            for (x, y, c1, c2, e1, e2) in [
                (46.0, 48.0, 6.0, -22.0, -14.0, -30.0),
                (84.0, 40.0, 8.0, -22.0, -12.0, -32.0),
                (124.0, 30.0, 10.0, -22.0, -10.0, -34.0),
                (162.0, 16.0, 10.0, -20.0, -8.0, -32.0),
            ] {
                let leaf = CGMutablePath()
                leaf.move(to: CGPoint(x: x, y: y))
                leaf.addQuadCurve(to: CGPoint(x: x + e1, y: y + e2), control: CGPoint(x: x + c1, y: y + c2))
                paths.append(leaf)
            }
            return paths
        }()
        // Each branch path is placed with the group's transform baked in:
        // translate(66 %, 90 %) scale(s).
        let place = CGAffineTransform(translationX: canvas.width * 0.66, y: canvas.height * 0.9)
            .scaledBy(x: s, y: s)
        for path in branchPaths {
            var transform = place
            guard let placed = path.copy(using: &transform) else { continue }
            let layer = strokeLayer(placed, color: ink.withAlphaComponent(0.6),
                                    width: strokeWidth * s, frame: container.bounds)
            // Visible length = min(length, draw * dash) in the group's units.
            layer.add(drawOn(pathLength: approximateLength(path), dash: dash,
                             begin: 0.2, duration: 1.4), forKey: nil)
            container.addSublayer(layer)
        }

        // The wave across the bottom margin.
        let wave = CGMutablePath()
        var point = CGPoint(x: canvas.width * 0.14, y: canvas.height * 0.945)
        wave.move(to: point)
        let segment = canvas.width * 0.11
        let amplitude = 14 * s
        for _ in 0..<3 {
            wave.addQuadCurve(to: CGPoint(x: point.x + segment, y: point.y),
                              control: CGPoint(x: point.x + segment / 2, y: point.y - amplitude))
            point.x += segment
            wave.addQuadCurve(to: CGPoint(x: point.x + segment, y: point.y),
                              control: CGPoint(x: point.x + segment / 2, y: point.y + amplitude))
            point.x += segment
        }
        let waveLayer = strokeLayer(wave, color: ink.withAlphaComponent(0.55),
                                    width: strokeWidth, frame: container.bounds)
        waveLayer.add(drawOn(pathLength: approximateLength(wave), dash: dash,
                             begin: 0.2, duration: 1.4), forKey: nil)
        container.addSublayer(waveLayer)

        // Three dots on the left, fading up with the draw.
        let dots = CAShapeLayer()
        dots.frame = container.bounds
        let dotsPath = CGMutablePath()
        for (x, y, r) in [(0.12, 0.9, 4.0), (0.16, 0.93, 3.0), (0.10, 0.955, 3.0)] {
            let radius = CGFloat(r) * s
            dotsPath.addEllipse(in: CGRect(x: canvas.width * CGFloat(x) - radius,
                                           y: canvas.height * CGFloat(y) - radius,
                                           width: radius * 2, height: radius * 2))
        }
        dots.path = dotsPath
        dots.fillColor = ink.cgColor
        dots.opacity = 0.5
        dots.add(fadeIn(to: 0.5, begin: 0.2, duration: 1.4), forKey: nil)
        container.addSublayer(dots)

        let sparkle = CAShapeLayer()
        sparkle.frame = container.bounds
        sparkle.path = star4(center: CGPoint(x: canvas.width * 0.1, y: canvas.height * 0.04), r: 16 * s)
        sparkle.fillColor = palette.accent.cgColor
        sparkle.opacity = 0.8
        sparkle.add(fadeIn(to: 0.8, begin: 0.2, duration: 1.4), forKey: nil)
        container.addSublayer(sparkle)
    }

    // editorial: top and bottom scrims, a hairline rounded frame drawn on, and
    // an accent kicker, all between 0.2 s and 1.5 s.
    private static func buildEditorial(
        in container: CALayer, canvas: CGSize, s: CGFloat, palette: Palette
    ) {
        let top = CAGradientLayer()
        top.frame = CGRect(x: 0, y: 0, width: canvas.width, height: canvas.height * 0.20)
        top.colors = [UIColor.black.withAlphaComponent(0.42).cgColor, UIColor.clear.cgColor]
        top.startPoint = CGPoint(x: 0.5, y: 0)
        top.endPoint = CGPoint(x: 0.5, y: 1)
        container.addSublayer(top)

        let bottom = CAGradientLayer()
        bottom.frame = CGRect(x: 0, y: canvas.height * 0.70, width: canvas.width, height: canvas.height * 0.30)
        bottom.colors = [UIColor.clear.cgColor, UIColor.black.withAlphaComponent(0.55).cgColor]
        bottom.startPoint = CGPoint(x: 0.5, y: 0)
        bottom.endPoint = CGPoint(x: 0.5, y: 1)
        container.addSublayer(bottom)

        let inset = (min(canvas.width, canvas.height) * 0.045).rounded()
        let border = max(2, 2.4 * s)
        let rect = CGRect(x: inset, y: inset, width: canvas.width - inset * 2, height: canvas.height - inset * 2)
        let perimeter = 2 * (rect.width + rect.height)
        let frame = strokeLayer(UIBezierPath(roundedRect: rect, cornerRadius: 18 * s).cgPath,
                                color: palette.neutral.withAlphaComponent(0.85),
                                width: border, frame: container.bounds)
        frame.lineCap = .butt
        let draw = drawOn(pathLength: perimeter, dash: perimeter, begin: 0.2, duration: 1.3)
        frame.add(draw, forKey: nil)
        frame.add(fadeIn(to: 1, begin: 0.2, duration: 1.3), forKey: "fade")
        container.addSublayer(frame)

        let kicker = CAShapeLayer()
        kicker.frame = container.bounds
        let kickerPath = CGMutablePath()
        kickerPath.addEllipse(in: CGRect(x: inset + 34 * s - 6 * s, y: inset + 42 * s - 6 * s,
                                         width: 12 * s, height: 12 * s))
        kickerPath.addPath(UIBezierPath(
            roundedRect: CGRect(x: inset + 50 * s, y: inset + 39 * s, width: 96 * s, height: 5 * s),
            cornerRadius: 2.5 * s).cgPath)
        kicker.path = kickerPath
        kicker.fillColor = palette.accent.cgColor
        kicker.add(fadeIn(to: 1, begin: 0.2, duration: 1.3), forKey: nil)
        container.addSublayer(kicker)
    }

    // ── template helpers ────────────────────────────────────────────────────

    private static func strokeLayer(_ path: CGPath, color: UIColor, width: CGFloat, frame: CGRect) -> CAShapeLayer {
        let layer = CAShapeLayer()
        layer.frame = frame
        layer.path = path
        layer.fillColor = nil
        layer.strokeColor = color.cgColor
        layer.lineWidth = width
        layer.lineCap = .round
        layer.lineJoin = .round
        layer.strokeEnd = 1
        return layer
    }

    /// `stroke-dasharray: dash; stroke-dashoffset: dash * (1 - draw)`, with
    /// `draw` rising linearly from `begin` over `duration`: the visible length
    /// is `draw * dash`, so the stroke completes when `draw` reaches
    /// `length / dash` — earlier than the end of the ramp for a short path.
    private static func drawOn(pathLength: CGFloat, dash: CGFloat, begin: Double, duration: Double) -> CAAnimation {
        let completeAt = duration * Double(min(1, max(0.0001, pathLength / dash)))
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = 0
        animation.toValue = 1
        animation.beginTime = AVCoreAnimationBeginTimeAtZero + begin
        animation.duration = completeAt
        animation.fillMode = .both
        animation.isRemovedOnCompletion = false
        return animation
    }

    private static func fadeIn(to value: Float, begin: Double, duration: Double) -> CAAnimation {
        let animation = CABasicAnimation(keyPath: "opacity")
        animation.fromValue = 0
        animation.toValue = value
        animation.beginTime = AVCoreAnimationBeginTimeAtZero + begin
        animation.duration = duration
        animation.fillMode = .both
        animation.isRemovedOnCompletion = false
        return animation
    }

    /// The composition's concave four-point sparkle.
    private static func star4(center c: CGPoint, r: CGFloat) -> CGPath {
        let i = r * 0.24
        let path = CGMutablePath()
        path.move(to: CGPoint(x: c.x, y: c.y - r))
        path.addCurve(to: CGPoint(x: c.x + r, y: c.y), control1: CGPoint(x: c.x + i, y: c.y - i),
                      control2: CGPoint(x: c.x + i, y: c.y - i))
        path.addCurve(to: CGPoint(x: c.x, y: c.y + r), control1: CGPoint(x: c.x + i, y: c.y + i),
                      control2: CGPoint(x: c.x + i, y: c.y + i))
        path.addCurve(to: CGPoint(x: c.x - r, y: c.y), control1: CGPoint(x: c.x - i, y: c.y + i),
                      control2: CGPoint(x: c.x - i, y: c.y + i))
        path.addCurve(to: CGPoint(x: c.x, y: c.y - r), control1: CGPoint(x: c.x - i, y: c.y - i),
                      control2: CGPoint(x: c.x - i, y: c.y - i))
        path.closeSubpath()
        return path
    }

    /// Path length by flattening curves into short segments — enough precision
    /// to time a draw-on stroke.
    static func approximateLength(_ path: CGPath) -> CGFloat {
        var length: CGFloat = 0
        var current = CGPoint.zero
        var start = CGPoint.zero
        path.applyWithBlock { element in
            let points = element.pointee.points
            switch element.pointee.type {
            case .moveToPoint:
                current = points[0]
                start = current
            case .addLineToPoint:
                length += hypot(points[0].x - current.x, points[0].y - current.y)
                current = points[0]
            case .addQuadCurveToPoint:
                var previous = current
                for step in 1...16 {
                    let t = CGFloat(step) / 16
                    let x = (1 - t) * (1 - t) * current.x + 2 * (1 - t) * t * points[0].x + t * t * points[1].x
                    let y = (1 - t) * (1 - t) * current.y + 2 * (1 - t) * t * points[0].y + t * t * points[1].y
                    length += hypot(x - previous.x, y - previous.y)
                    previous = CGPoint(x: x, y: y)
                }
                current = points[1]
            case .addCurveToPoint:
                var previous = current
                for step in 1...16 {
                    let t = CGFloat(step) / 16
                    let a = (1 - t) * (1 - t) * (1 - t)
                    let b = 3 * (1 - t) * (1 - t) * t
                    let c = 3 * (1 - t) * t * t
                    let d = t * t * t
                    let x = a * current.x + b * points[0].x + c * points[1].x + d * points[2].x
                    let y = a * current.y + b * points[0].y + c * points[1].y + d * points[2].y
                    length += hypot(x - previous.x, y - previous.y)
                    previous = CGPoint(x: x, y: y)
                }
                current = points[2]
            case .closeSubpath:
                length += hypot(start.x - current.x, start.y - current.y)
                current = start
            @unknown default:
                break
            }
        }
        return length
    }

    private struct Palette {
        let primary: UIColor
        let secondary: UIColor
        let accent: UIColor
        let neutral: UIColor

        init(_ source: RenderManifest.Palette) {
            primary = Palette.color(source.primary)
            secondary = Palette.color(source.secondary)
            accent = Palette.color(source.accent)
            neutral = Palette.color(source.neutral)
        }

        static func color(_ hex: String) -> UIColor {
            var value: UInt64 = 0
            Scanner(string: String(hex.dropFirst())).scanHexInt64(&value)
            return UIColor(
                red: CGFloat((value >> 16) & 0xFF) / 255,
                green: CGFloat((value >> 8) & 0xFF) / 255,
                blue: CGFloat(value & 0xFF) / 255,
                alpha: 1
            )
        }
    }

    static func transparentFormat() -> UIGraphicsImageRendererFormat {
        let format = UIGraphicsImageRendererFormat.default()
        format.opaque = false
        format.scale = 1
        // ROOT CAUSE of the unreadable captions: on wide-colour iPhones/iPads
        // `.default()` picks the EXTENDED range — a 16-bit half-float bitmap.
        // `AVVideoCompositionCoreAnimationTool`'s offscreen renderer does not
        // read that layer content correctly, so solid white glyphs came out
        // near-black and only the anti-aliased edges showed, as a grey fringe.
        // Force a plain 8-bit sRGB bitmap, which the export reads exactly.
        format.preferredRange = .standard
        return format
    }
}

// MARK: - Text graphics

/// Builds the scene-matched text graphics (hook, scene labels with badges,
/// closing card) as a Core Animation layer tree for
/// `AVVideoCompositionCoreAnimationTool`, in the pack's frame (card, none,
/// post-it, painting, ribbon, bubble), text effect (plain, shadow, outline,
/// glow) and position.
///
/// THE REFERENCE IS `src/lib/textGraphics/` — `layout.ts` for every box and
/// position, `motion.ts` for every curve, `canvasRenderer.ts` for every paint,
/// which is the preview the requester chose from. Layout is done in TOP-LEFT
/// frame pixels exactly as there; each box is then placed in Core Animation's
/// bottom-left space, where a vertical move and a rotation change sign. Every
/// curve is sampled into linear keyframes from the same formulas.
enum TextGraphicsLayers {

    final class Node {
        var x: CGFloat = 0, y: CGFloat = 0, w: CGFloat = 0, h: CGFloat = 0
        /// "l" left-centre, "c" centre, "t" top-centre.
        var anchor = "l"
        var anim: Anim?
        var idle: Idle?
        var rotate: CGFloat = 0
        var paint: Paint = .none
        var children: [Node] = []
    }

    struct Anim {
        let kind: String
        let delay: Double
        let dur: Double
    }

    struct Idle {
        let kind: String
        let amp: Double
        let period: Double
    }

    struct Panel {
        let frame: String
        let color: UIColor
        let radius: CGFloat
        let shadowDx: CGFloat
        let shadowDy: CGFloat
        let shadow: UIColor
        let frameColor: UIColor
        let frameInner: UIColor
        let frameAccent: UIColor
        let tape: UIColor
        let frameWidth: CGFloat
        let s: CGFloat
    }

    struct TextEffect {
        let kind: String
        let color: UIColor
        let blur: CGFloat
        let dy: CGFloat
        let width: CGFloat

        static let plain = TextEffect(kind: "plain", color: .clear, blur: 0, dy: 0, width: 0)
    }

    enum Paint {
        case none
        case box(color: UIColor, radius: CGFloat, shadowDx: CGFloat, shadowDy: CGFloat, shadow: UIColor)
        case panel(Panel)
        case text(text: String, font: UIFont, color: UIColor, ascent: CGFloat, effect: TextEffect)
        case dot(color: UIColor)
        case pin(color: UIColor)
        case badge(shape: String, bg: UIColor, ring: UIColor, text: String, font: UIFont,
                   color: UIColor, ascent: CGFloat, descent: CGFloat)
    }

    struct ItemLayout {
        let item: TextGraphicsSpec.Item
        let pivotX: CGFloat
        let pivotY: CGFloat
        let nodes: [Node]
    }

    // MARK: Spec access

    private struct Context {
        let spec: TextGraphicsSpec
        let canvas: CGSize
        let s: CGFloat
        let accent: UIColor
        let descriptors: [String: CTFontDescriptor]

        var shape: TextGraphicsSpec.Shape { spec.style.shape }
        var frame: String { shape.frame ?? "card" }

        func size(_ name: String, _ fallback: Double) -> CGFloat {
            CGFloat(spec.style.sizes[name] ?? fallback)
        }

        func color(_ name: String) -> UIColor {
            resolve(spec.style.colors[name] ?? "#00000000")
        }

        func resolve(_ raw: String) -> UIColor {
            raw == "accent" ? accent : TextGraphicsLayers.parseColor(raw) ?? .clear
        }

        func anim(_ name: String) -> Anim? {
            guard let entry = spec.style.motion[name], let kind = entry.kind else { return nil }
            return Anim(kind: kind, delay: entry.delay ?? 0, dur: entry.dur ?? 0.3)
        }

        func idle(_ name: String) -> Idle? {
            guard let entry = spec.style.motion[name], let kind = entry.kind, kind != "none" else { return nil }
            return Idle(kind: kind, amp: entry.amp ?? 0, period: entry.period ?? 0)
        }

        func fontKey(_ role: String) -> String { spec.style.fonts[role] ?? "" }

        func font(_ key: String, _ size: CGFloat) -> UIFont {
            if let descriptor = descriptors[key] {
                return CTFontCreateWithFontDescriptor(descriptor, size, nil) as UIFont
            }
            return UIFont.systemFont(ofSize: size, weight: .heavy)
        }

        func ascent(_ key: String) -> CGFloat {
            CGFloat(spec.fonts.first(where: { $0.key == key })?.ascent ?? 1.0)
        }

        func descent(_ key: String) -> CGFloat {
            CGFloat(spec.fonts.first(where: { $0.key == key })?.descent ?? 0.3)
        }

        func lineHeight(_ key: String, _ size: CGFloat) -> CGFloat {
            size * (ascent(key) + descent(key))
        }

        func measure(_ text: String, _ key: String, _ size: CGFloat) -> CGFloat {
            (text as NSString).size(withAttributes: [.font: font(key, size)]).width
        }

        func fitSize(_ text: String, _ key: String, _ size: CGFloat, _ maxWidth: CGFloat,
                     _ minFactor: CGFloat = 0.6) -> CGFloat {
            let w = measure(text, key, size)
            if w <= maxWidth || w <= 0 { return size }
            return max(size * minFactor, size * maxWidth / w)
        }

        var safeTop: CGFloat {
            canvas.height / canvas.width >= 1.5
                ? 0.11 * canvas.height
                : max(56 * s, 0.06 * canvas.height)
        }

        /// `textEffectFor` in layout.ts.
        func textEffect(_ size: CGFloat) -> TextEffect {
            let effectColor = color("textEffect")
            switch shape.textEffect ?? "plain" {
            case "shadow": return TextEffect(kind: "shadow", color: effectColor, blur: 12 * s, dy: 3 * s, width: 0)
            case "outline": return TextEffect(kind: "outline", color: effectColor, blur: 0, dy: 0, width: max(3 * s, size * 0.12))
            case "glow": return TextEffect(kind: "glow", color: effectColor, blur: size * 0.45, dy: 0, width: 0)
            default: return .plain
            }
        }

        /// `basePadding` in layout.ts: (left, right, top, bottom).
        func padding(_ l: CGFloat, _ r: CGFloat, _ t: CGFloat, _ b: CGFloat)
            -> (CGFloat, CGFloat, CGFloat, CGFloat) {
            if frame == "none" { return (0, 0, 0, 0) }
            let fw = CGFloat(shape.frameWidth ?? 0) * s
            var extra: (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
            switch frame {
            case "painting": extra = (fw, fw, fw, fw)
            case "ribbon": extra = (fw, fw, 0, 0)
            case "postit": extra = (6 * s, 6 * s, 18 * s, 6 * s)
            default: break
            }
            return (l * s + extra.0, r * s + extra.1, t * s + extra.2, b * s + extra.3)
        }

        /// `panelPaint` in layout.ts.
        func panel(_ colorName: String) -> Panel {
            Panel(
                frame: frame,
                color: color(colorName),
                radius: CGFloat(shape.cardRadius ?? 16) * s,
                shadowDx: CGFloat(shape.shadowDx ?? 0) * s,
                shadowDy: CGFloat(shape.shadowDy ?? 0) * s,
                shadow: color("shadow"),
                frameColor: color("frame"),
                frameInner: color("frameInner"),
                frameAccent: color("frameAccent"),
                tape: color("tape"),
                frameWidth: CGFloat(shape.frameWidth ?? 0) * s,
                s: s)
        }
    }

    static func parseColor(_ hex: String) -> UIColor? {
        guard hex.hasPrefix("#") else { return nil }
        let body = String(hex.dropFirst())
        guard body.count == 6 || body.count == 8, let value = UInt64(body, radix: 16) else { return nil }
        let rgb = body.count == 8 ? value >> 8 : value
        let alpha = body.count == 8 ? CGFloat(value & 0xFF) / 255 : 1
        return UIColor(
            red: CGFloat((rgb >> 16) & 0xFF) / 255,
            green: CGFloat((rgb >> 8) & 0xFF) / 255,
            blue: CGFloat(rgb & 0xFF) / 255,
            alpha: alpha)
    }

    private static func alphaOf(_ color: UIColor) -> CGFloat {
        var alpha: CGFloat = 0
        _ = color.getRed(nil, green: nil, blue: nil, alpha: &alpha)
        return alpha
    }

    private static func loadDescriptors(_ files: [String: URL]) -> [String: CTFontDescriptor] {
        var out: [String: CTFontDescriptor] = [:]
        for (key, url) in files {
            if let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
               let first = descriptors.first {
                out[key] = first
            }
        }
        return out
    }

    // MARK: Layout (layout.ts)

    private static func textNode(_ c: Context, _ text: String, _ key: String, _ size: CGFloat,
                                 _ color: UIColor, _ x: CGFloat, _ y: CGFloat, _ anim: Anim?,
                                 effect: Bool = false) -> Node {
        let n = Node()
        n.x = x
        n.y = y
        n.w = c.measure(text, key, size)
        n.h = c.lineHeight(key, size)
        n.anim = anim
        n.paint = .text(text: text, font: c.font(key, size), color: color, ascent: c.ascent(key) * size,
                        effect: effect ? c.textEffect(size) : .plain)
        return n
    }

    private static func boxNode(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat, _ color: UIColor,
                                _ radius: CGFloat, _ anim: Anim?, shadowDx: CGFloat = 0, shadowDy: CGFloat = 0,
                                shadow: UIColor = .clear) -> Node {
        let n = Node()
        n.x = x
        n.y = y
        n.w = w
        n.h = h
        n.anim = anim
        n.paint = .box(color: color, radius: radius, shadowDx: shadowDx, shadowDy: shadowDy, shadow: shadow)
        return n
    }

    private static let positions: Set<String> = ["top-left", "top-center", "top-right", "middle-left", "middle-right"]

    private static func shift(_ n: Node, _ dx: CGFloat, _ dy: CGFloat) {
        n.x += dx
        n.y += dy
        for child in n.children { shift(child, dx, dy) }
    }

    /// `place` in layout.ts.
    private static func place(_ c: Context, _ item: TextGraphicsSpec.Item, _ nodes: [Node]) -> ItemLayout {
        let wanted = item.position ?? ""
        var position = positions.contains(wanted) ? wanted : (c.spec.style.positions?[item.kind] ?? "top-left")
        if !positions.contains(position) { position = "top-left" }

        var x0 = CGFloat.greatestFiniteMagnitude, y0 = CGFloat.greatestFiniteMagnitude
        var x1 = -CGFloat.greatestFiniteMagnitude, y1 = -CGFloat.greatestFiniteMagnitude
        for n in nodes {
            x0 = min(x0, n.x)
            y0 = min(y0, n.y)
            x1 = max(x1, n.x + n.w)
            y1 = max(y1, n.y + n.h)
        }
        let bw = x1 - x0
        let bh = y1 - y0
        let M = 64 * c.s
        let isTop = position.hasPrefix("top")
        let col = position.hasSuffix("left") ? "left" : position.hasSuffix("right") ? "right" : "center"
        let x = col == "left" ? M : col == "right" ? c.canvas.width - M - bw : (c.canvas.width - bw) / 2
        let y = isTop ? c.safeTop : max(c.safeTop, 0.42 * c.canvas.height - bh / 2)
        for n in nodes { shift(n, x - x0, y - y0) }
        let centred = col == "center" || item.kind == "cta"
        return ItemLayout(
            item: item,
            pivotX: centred ? x + bw / 2 : col == "right" ? x + bw : x,
            pivotY: centred ? y + bh / 2 : y,
            nodes: nodes)
    }

    private static func layoutLabel(_ c: Context, _ item: TextGraphicsSpec.Item) -> [Node] {
        let s = c.s
        let shape = c.shape
        let M = 64 * s
        let top = c.safeTop
        let hasBadge = !item.badge.isEmpty
        let D = c.size("badgeDiameter", 150) * s
        let barW = CGFloat(shape.barWidth ?? 0) * s
        let barGap: CGFloat = barW > 0 ? 14 * s : 0
        let (padL, padR, padT, padB) = c.padding(26, 30, 16, 20)

        let maxText = c.canvas.width - 2 * M - barW - barGap - padL - padR - (hasBadge ? 0.9 * D : 0)
        let titleFont = c.fontKey("title")
        let bodyFont = c.fontKey("body")
        let titleSize = c.fitSize(item.title, titleFont, c.size("title", 60) * s, maxText)
        let sub = (shape.uppercaseSub ?? false) ? item.sub.uppercased() : item.sub
        let subSize = c.fitSize(sub, bodyFont, c.size("sub", 28) * s, maxText)
        let numSize = c.size("num", 28) * s

        let cardX = M + barW + barGap
        let innerX = cardX + padL
        var y = top + padT
        var children: [Node] = []

        if !item.num.isEmpty {
            let n = textNode(c, item.num, titleFont, numSize, c.color("num"), innerX, y, c.anim("num"), effect: true)
            children.append(n)
            y += n.h + 2 * s
        }
        let title = textNode(c, item.title, titleFont, titleSize, c.color("title"), innerX, y, c.anim("title"), effect: true)
        children.append(title)
        y += title.h
        if shape.underline ?? false {
            y += 4 * s
            children.append(boxNode(innerX, y, title.w, 6 * s, c.color("underline"), 3 * s, c.anim("underline")))
            y += 6 * s + 8 * s
        } else {
            y += 4 * s
        }
        if !sub.isEmpty {
            let subNode = textNode(c, sub, bodyFont, subSize, c.color("sub"), innerX, y, c.anim("sub"), effect: true)
            children.append(subNode)
            y += subNode.h
        }
        let contentW = children.map { $0.w }.max() ?? 0
        let cardW = padL + contentW + padR
        let cardH = y + padB - top

        var nodes: [Node] = []
        if barW > 0 {
            let bar = boxNode(M, top, barW, cardH, c.color("bar"), barW / 2, c.anim("bar"))
            bar.anchor = "t"
            nodes.append(bar)
        }
        let card = Node()
        card.x = cardX
        card.y = top
        card.w = cardW
        card.h = cardH
        card.anim = c.anim("card")
        card.paint = .panel(c.panel("cardBg"))
        card.children = children
        nodes.append(card)

        if hasBadge {
            let badgeFont = c.fontKey("badge")
            let kind = shape.badge ?? "circle"
            let tag = kind == "tag"
            let bw = tag ? 1.4 * D : D
            let bh = tag ? 0.6 * D : D
            let overlap = c.frame == "none" ? -16 * s : 0.1 * bh
            let cx = cardX + cardW + bw / 2 - overlap
            let cy = top + 0.22 * D
            let textMax = (tag ? 1.15 : 0.66) * D
            let size = c.fitSize(item.badge, badgeFont, c.size("badgeText", 32) * s, textMax, 0.5)
            let badge = Node()
            badge.x = cx - bw / 2
            badge.y = cy - bh / 2
            badge.w = bw
            badge.h = bh
            badge.anchor = "c"
            badge.anim = c.anim("badge")
            badge.idle = c.idle("badgeIdle")
            badge.rotate = CGFloat(shape.badgeRotate ?? 0)
            badge.paint = .badge(shape: kind, bg: c.color("badgeBg"), ring: c.color("badgeRing"),
                                 text: item.badge, font: c.font(badgeFont, size), color: c.color("badgeText"),
                                 ascent: c.ascent(badgeFont) * size, descent: c.descent(badgeFont) * size)
            nodes.append(badge)
        }
        return nodes
    }

    private static func layoutHook(_ c: Context, _ item: TextGraphicsSpec.Item) -> [Node] {
        let s = c.s
        let shape = c.shape
        let M = 64 * s
        let top = c.safeTop
        let (padL, padR, padT, padB) = c.padding(22, 30, 16, 20)
        let hookDot = shape.hookDot ?? false
        let dotD: CGFloat = hookDot ? 44 * s : 0
        let dotGap: CGFloat = hookDot ? 18 * s : 0
        let font = c.fontKey("hook")
        let bodyFont = c.fontKey("body")
        let maxText = c.canvas.width - 2 * M - padL - padR

        let innerX = M + padL
        var y = top + padT
        var children: [Node] = []

        if !item.kicker.isEmpty {
            let kickerText = item.kicker.uppercased()
            let size = c.fitSize(kickerText, bodyFont, c.size("kicker", 24) * s, maxText - 28 * s)
            let label = textNode(c, kickerText, bodyFont, size, c.color("kickerText"), innerX + 14 * s, y + 6 * s, nil)
            let chip = boxNode(innerX, y, label.w + 28 * s, label.h + 12 * s, c.color("kickerBg"), 6 * s, c.anim("kicker"))
            chip.children = [label]
            children.append(chip)
            y += chip.h + 10 * s
        }

        let titleSize = c.fitSize(item.title, font, c.size("hookTitle", 70) * s, maxText - dotD - dotGap)
        let titleH = c.lineHeight(font, titleSize)
        let rowH = max(dotD, titleH)
        if dotD > 0 {
            let dot = Node()
            dot.x = innerX
            dot.y = y + (rowH - dotD) / 2
            dot.w = dotD
            dot.h = dotD
            dot.anchor = "c"
            dot.anim = c.anim("dot")
            dot.paint = .dot(color: c.color("dot"))
            children.append(dot)
        }
        children.append(textNode(c, item.title, font, titleSize, c.color("hookTitle"),
                                 innerX + dotD + dotGap, y + (rowH - titleH) / 2, c.anim("hookTitle"), effect: true))
        y += rowH + 4 * s

        if !item.sub.isEmpty {
            let size = c.fitSize(item.sub, bodyFont, c.size("hookSub", 34) * s, maxText)
            let sub = textNode(c, item.sub, bodyFont, size, c.color("hookSub"), innerX, y, c.anim("hookSub"), effect: true)
            children.append(sub)
            y += sub.h
        }

        let contentRight = children.map { $0.x + $0.w }.max() ?? innerX
        let box = Node()
        box.x = M
        box.y = top
        box.w = contentRight - M + padR
        box.h = y + padB - top
        box.anim = c.anim("hookBox")
        box.paint = .panel(c.panel("hookBg"))
        box.children = children
        return [box]
    }

    private static func layoutCta(_ c: Context, _ item: TextGraphicsSpec.Item) -> [Node] {
        let first = layoutCta(c, item, factor: 1)
        let maxW = c.canvas.width - 2 * 64 * c.s
        let w = first.first?.w ?? 0
        if w <= maxW { return first }
        return layoutCta(c, item, factor: max(0.55, maxW / w))
    }

    private static func layoutCta(_ c: Context, _ item: TextGraphicsSpec.Item, factor f: CGFloat) -> [Node] {
        let k = c.s * f
        let shape = c.shape
        let top = c.safeTop
        let padX = 22 * k, padY = 18 * k, pinSize = 72 * k, gap1 = 20 * k, gap2 = 26 * k
        let titleFont = c.fontKey("title")
        let bodyFont = c.fontKey("body")

        let brandSize = c.size("ctaBrand", 46) * k
        let placeSize = c.size("ctaPlace", 30) * k
        let buttonSize = c.size("ctaButton", 42) * k
        let hasBrand = !item.brand.isEmpty
        let hasPlace = !item.place.isEmpty
        let hasButton = !item.title.isEmpty
        let brandW = hasBrand ? c.measure(item.brand, titleFont, brandSize) : 0
        let placeW = hasPlace ? c.measure(item.place, bodyFont, placeSize) : 0
        let brandH = hasBrand ? c.lineHeight(titleFont, brandSize) : 0
        let placeH = hasPlace ? c.lineHeight(bodyFont, placeSize) : 0
        let colW = max(brandW, placeW)
        let colH = brandH + placeH
        let buttonTextW = hasButton ? c.measure(item.title, titleFont, buttonSize) : 0
        let buttonH = hasButton ? c.lineHeight(titleFont, buttonSize) + 24 * k : 0
        let buttonW = hasButton ? buttonTextW + 60 * k : 0

        let innerH = max(pinSize, max(colH, buttonH))
        let contentW = pinSize + (colW > 0 ? gap1 + colW : 0) + (buttonW > 0 ? gap2 + buttonW : 0)
        let cardW = padX * 2 + contentW
        let cardH = padY * 2 + innerH
        let cardX = 64 * c.s
        let cardY = top
        let midY = cardY + padY + innerH / 2

        var children: [Node] = []
        var x = cardX + padX
        let pin = Node()
        pin.x = x
        pin.y = midY - pinSize / 2
        pin.w = pinSize
        pin.h = pinSize
        pin.anchor = "c"
        pin.anim = c.anim("pin")
        pin.paint = .pin(color: c.color("pin"))
        children.append(pin)
        x += pinSize
        if colW > 0 {
            x += gap1
            var y = midY - colH / 2
            if hasBrand {
                children.append(textNode(c, item.brand, titleFont, brandSize, c.color("ctaBrand"), x, y, c.anim("ctaText")))
                y += brandH
            }
            if hasPlace {
                children.append(textNode(c, item.place, bodyFont, placeSize, c.color("ctaPlace"), x, y, c.anim("ctaText")))
            }
            x += colW
        }
        if buttonW > 0 {
            x += gap2
            let label = textNode(c, item.title, titleFont, buttonSize, c.color("buttonText"),
                                 x + 30 * k, midY - buttonH / 2 + 12 * k, nil)
            let button = boxNode(x, midY - buttonH / 2, buttonW, buttonH, c.color("buttonBg"), buttonH / 2, c.anim("button"))
            button.anchor = "c"
            button.idle = c.idle("buttonIdle")
            button.children = [label]
            children.append(button)
        }

        let card = boxNode(cardX, cardY, cardW, cardH, c.color("ctaBg"), CGFloat(shape.ctaRadius ?? 24) * k,
                           c.anim("ctaCard"), shadowDx: CGFloat(shape.shadowDx ?? 0) * k,
                           shadowDy: CGFloat(shape.shadowDy ?? 0) * k, shadow: c.color("shadow"))
        card.anchor = "c"
        card.children = children
        return [card]
    }

    // MARK: Motion (motion.ts)

    static func clamp01(_ x: Double) -> Double { min(1, max(0, x)) }
    static func easeOutCubic(_ x: Double) -> Double { 1 - pow(1 - x, 3) }
    static func easeInCubic(_ x: Double) -> Double { x * x * x }
    static func easeBack(_ x: Double) -> Double {
        let c1 = 1.9
        let c3 = c1 + 1
        return 1 + c3 * pow(x - 1, 3) + c1 * pow(x - 1, 2)
    }

    private static func ease(_ anim: Anim, _ p: Double) -> Double {
        anim.kind == "pop" || anim.kind == "drop" ? easeBack(p) : easeOutCubic(p)
    }

    // MARK: Layers

    /// The text-graphics layer tree for `canvas`, or nil when there is nothing to draw.
    static func build(_ spec: TextGraphicsSpec?, fonts: [String: URL], canvas: CGSize) -> CALayer? {
        guard let spec, !spec.items.isEmpty else { return nil }
        let context = Context(
            spec: spec,
            canvas: canvas,
            s: min(canvas.width, canvas.height) / 1080,
            accent: parseColor(spec.accent) ?? UIColor(red: 0xD7 / 255, green: 0x26 / 255, blue: 0x2E / 255, alpha: 1),
            descriptors: loadDescriptors(fonts))

        let root = CALayer()
        root.frame = CGRect(origin: .zero, size: canvas)
        var any = false
        for item in spec.items where item.end > item.start {
            let nodes: [Node]
            switch item.kind {
            case "hook": nodes = layoutHook(context, item)
            case "cta": nodes = layoutCta(context, item)
            case "label": nodes = layoutLabel(context, item)
            default: continue
            }
            root.addSublayer(itemLayer(context, place(context, item, nodes)))
            any = true
        }
        return any ? root : nil
    }

    private static func begin(_ seconds: Double) -> CFTimeInterval {
        AVCoreAnimationBeginTimeAtZero + seconds
    }

    /// A linear keyframe animation sampling `value` at `samples + 1` evenly
    /// spaced points of [begin, begin + duration].
    private static func sampled(_ keyPath: String, begin start: Double, duration: Double, samples: Int,
                                fill: CAMediaTimingFillMode = .both,
                                _ value: (Double) -> Any) -> CAKeyframeAnimation {
        let animation = CAKeyframeAnimation(keyPath: keyPath)
        var values: [Any] = []
        var times: [NSNumber] = []
        for k in 0...samples {
            let f = Double(k) / Double(samples)
            values.append(value(f))
            times.append(NSNumber(value: f))
        }
        animation.values = values
        animation.keyTimes = times
        animation.calculationMode = .linear
        animation.beginTime = begin(start)
        animation.duration = max(0.001, duration)
        animation.fillMode = fill
        animation.isRemovedOnCompletion = false
        return animation
    }

    private static func itemLayer(_ c: Context, _ layout: ItemLayout) -> CALayer {
        let W = c.canvas.width
        let H = c.canvas.height
        let s = c.s
        let item = layout.item
        let style = c.spec.style
        let exitEntry = style.motion["exit"]
        let exitKind = exitEntry?.kind ?? "fade"
        let exitDur = max(0, exitEntry?.dur ?? 0.3)
        let total = item.end - item.start

        let px = layout.pivotX
        let py = layout.pivotY

        let layer = CALayer()
        layer.bounds = CGRect(origin: .zero, size: c.canvas)
        layer.anchorPoint = CGPoint(x: px / W, y: 1 - py / H)
        layer.position = CGPoint(x: px, y: H - py)
        layer.opacity = 0

        // Visible from start to end, with the exit over the last `exitDur`.
        let exitFrom = total > 0 ? max(0, (total - exitDur) / total) : 0
        func exitProgress(_ f: Double) -> Double {
            guard f > exitFrom, exitDur > 0 else { return f >= 1 && exitDur <= 0 ? 1 : 0 }
            return clamp01((f * total - (total - exitDur)) / exitDur)
        }
        let samples = 48
        layer.add(sampled("opacity", begin: item.start, duration: total, samples: samples, fill: .forwards) { f in
            let o = exitProgress(f)
            let eo = easeInCubic(o)
            switch exitKind {
            case "slideLeft", "shrink": return NSNumber(value: Float(1 - eo))
            default: return NSNumber(value: Float(1 - o))
            }
        }, forKey: "tgVisible")
        if exitKind == "slideLeft" || exitKind == "shrink" {
            layer.add(sampled("transform", begin: item.start, duration: total, samples: samples, fill: .forwards) { f in
                let eo = CGFloat(easeInCubic(exitProgress(f)))
                let tx: CGFloat = exitKind == "slideLeft" ? -40 * eo * s : 0
                let sc: CGFloat = exitKind == "shrink" ? 1 - 0.15 * eo : 1
                return NSValue(caTransform3D: CATransform3DScale(CATransform3DMakeTranslation(tx, 0, 0), sc, sc, 1))
            }, forKey: "tgExit")
        }

        let tilt = CALayer()
        tilt.bounds = layer.bounds
        tilt.anchorPoint = layer.anchorPoint
        tilt.position = layer.position
        let tiltDeg = CGFloat(style.shape.tiltDeg ?? 0)
        if tiltDeg != 0 {
            tilt.transform = CATransform3DMakeRotation(-tiltDeg * .pi / 180, 0, 0, 1)
        }
        layer.addSublayer(tilt)

        for node in layout.nodes {
            tilt.addSublayer(nodeLayer(c, node, parentX: 0, parentY: 0, parentHeight: H, start: item.start))
        }
        return layer
    }

    private static func nodeLayer(_ c: Context, _ n: Node, parentX: CGFloat, parentY: CGFloat,
                                  parentHeight: CGFloat, start: Double) -> CALayer {
        let s = c.s
        let localX = n.x - parentX
        let localTop = n.y - parentY
        let originY = parentHeight - localTop - n.h

        let anchor: CGPoint
        switch n.anchor {
        case "c": anchor = CGPoint(x: 0.5, y: 0.5)
        case "t": anchor = CGPoint(x: 0.5, y: 1)
        default: anchor = CGPoint(x: 0, y: 0.5)
        }

        let enter = CALayer()
        enter.bounds = CGRect(x: 0, y: 0, width: n.w, height: n.h)
        enter.anchorPoint = anchor
        enter.position = CGPoint(x: localX + anchor.x * n.w, y: originY + anchor.y * n.h)

        let shift = CALayer()
        shift.frame = enter.bounds
        enter.addSublayer(shift)

        let idleLayer = CALayer()
        idleLayer.frame = enter.bounds
        shift.addSublayer(idleLayer)

        let content = CALayer()
        content.frame = enter.bounds
        if n.rotate != 0 {
            content.transform = CATransform3DMakeRotation(-n.rotate * .pi / 180, 0, 0, 1)
        }
        idleLayer.addSublayer(content)

        if let paintLayer = paintLayer(n, s: s) {
            content.addSublayer(paintLayer)
        }
        for child in n.children {
            content.addSublayer(nodeLayer(c, child, parentX: n.x, parentY: n.y, parentHeight: n.h, start: start))
        }

        if let anim = n.anim {
            addEnter(anim, to: enter, shift: shift, node: n, s: s, start: start)
        }
        if let idle = n.idle, idle.kind != "none", idle.period > 0 {
            addIdle(idle, to: idleLayer, after: start + max(1.0, (n.anim?.delay ?? 0) + (n.anim?.dur ?? 0)), s: s)
        }
        return enter
    }

    private static func addEnter(_ anim: Anim, to enter: CALayer, shift: CALayer, node n: Node,
                                 s: CGFloat, start: Double) {
        let from = start + anim.delay
        let dur = max(0.01, anim.dur)
        let samples = 16

        enter.add(sampled("opacity", begin: from, duration: dur, samples: samples) { p in
            if p <= 0 { return NSNumber(value: Float(0)) }
            switch anim.kind {
            case "pop", "drop": return NSNumber(value: Float(min(1, p * 4)))
            case "fade": return NSNumber(value: Float(ease(anim, p)))
            default: return NSNumber(value: Float(1))
            }
        }, forKey: "tgEnterOpacity")

        switch anim.kind {
        case "pop", "growX", "growY", "fade", "drop":
            enter.add(sampled("transform", begin: from, duration: dur, samples: samples) { p in
                let e = CGFloat(ease(anim, p))
                var ty: CGFloat = 0
                var sx: CGFloat = 1
                var sy: CGFloat = 1
                switch anim.kind {
                case "pop": sx = e; sy = e
                case "growX": sx = e
                case "growY": sy = e
                case "fade": ty = (1 - e) * 16 * s
                case "drop": ty = -(1 - e) * 40 * s
                default: break
                }
                // Canvas y points down; Core Animation's here points up.
                return NSValue(caTransform3D: CATransform3DScale(
                    CATransform3DMakeTranslation(0, -ty, 0), max(0.0001, sx), max(0.0001, sy), 1))
            }, forKey: "tgEnterTransform")
        case "rise":
            let mask = CALayer()
            mask.backgroundColor = UIColor.white.cgColor
            mask.frame = CGRect(x: -6 * s, y: -2 * s, width: n.w + 12 * s, height: n.h + 4 * s)
            enter.mask = mask
            shift.add(sampled("transform", begin: from, duration: dur, samples: samples) { p in
                let rise = (1 - CGFloat(ease(anim, p))) * 1.15 * n.h
                return NSValue(caTransform3D: CATransform3DMakeTranslation(0, -rise, 0))
            }, forKey: "tgRise")
        case "wipe":
            let fullWidth = 60 * s + n.w + 20 * s
            let mask = CALayer()
            mask.backgroundColor = UIColor.white.cgColor
            mask.anchorPoint = CGPoint(x: 0, y: 0.5)
            mask.bounds = CGRect(x: 0, y: 0, width: fullWidth, height: n.h + 1200 * s)
            mask.position = CGPoint(x: -60 * s, y: n.h / 2)
            enter.mask = mask
            mask.add(sampled("transform", begin: from, duration: dur, samples: samples) { p in
                let e = CGFloat(ease(anim, p))
                let k = (60 * s + (n.w + 20 * s) * e) / fullWidth
                return NSValue(caTransform3D: CATransform3DMakeScale(max(0.0001, k), 1, 1))
            }, forKey: "tgWipe")
        default:
            break
        }
    }

    private static func addIdle(_ idle: Idle, to layer: CALayer, after start: Double, s: CGFloat) {
        let keyPath: String
        switch idle.kind {
        case "wobble": keyPath = "transform.rotation.z"
        case "float": keyPath = "transform.translation.y"
        case "pulse": keyPath = "transform.scale"
        default: return
        }
        let animation = sampled(keyPath, begin: start, duration: idle.period, samples: 24, fill: .removed) { f in
            let wave = sin(2 * Double.pi * f)
            switch idle.kind {
            case "wobble": return NSNumber(value: -idle.amp * wave * Double.pi / 180)
            case "float": return NSNumber(value: -idle.amp * wave * Double(s))
            default: return NSNumber(value: 1 + idle.amp * wave)
            }
        }
        animation.repeatCount = .greatestFiniteMagnitude
        layer.add(animation, forKey: "tgIdle")
    }

    // MARK: Paint (canvasRenderer.ts)

    private static func paintLayer(_ n: Node, s: CGFloat) -> CALayer? {
        var margin: CGFloat = 4
        switch n.paint {
        case .none:
            return nil
        case let .box(_, _, dx, dy, _):
            margin = max(margin, abs(dx) + 2, abs(dy) + 2)
        case let .panel(panel):
            // Shadow offset, the bubble's tail and the post-it's tape reach outside the box.
            margin = max(margin, abs(panel.shadowDx) + 2, abs(panel.shadowDy) + 2, 40 * panel.s)
        case let .text(_, font, _, _, effect):
            margin = max(margin, font.pointSize * 0.4, effect.blur * 1.5 + abs(effect.dy), effect.width)
        case let .badge(_, _, _, _, font, _, _, _):
            margin = max(margin, font.pointSize * 0.4)
        default:
            break
        }
        let size = CGSize(width: max(1, n.w + 2 * margin), height: max(1, n.h + 2 * margin))
        let renderer = UIGraphicsImageRenderer(size: size, format: OverlayPainter.transparentFormat())
        let image = renderer.image { _ in
            let r = CGRect(x: margin, y: margin, width: n.w, height: n.h)
            draw(n.paint, in: r)
        }
        let layer = CALayer()
        layer.frame = CGRect(x: -margin, y: -margin, width: size.width, height: size.height)
        layer.contents = image.cgImage
        return layer
    }

    private static func roundRect(_ rect: CGRect, _ radius: CGFloat) -> UIBezierPath {
        let r = max(0, min(radius, rect.width / 2, rect.height / 2))
        return UIBezierPath(roundedRect: rect, cornerRadius: r)
    }

    /// `panelPath` in canvasRenderer.ts.
    private static func panelPath(_ p: Panel, _ r: CGRect) -> UIBezierPath {
        if p.frame == "ribbon" {
            let notch = p.frameWidth
            let path = UIBezierPath()
            path.move(to: CGPoint(x: r.minX, y: r.minY))
            path.addLine(to: CGPoint(x: r.maxX, y: r.minY))
            path.addLine(to: CGPoint(x: r.maxX - notch, y: r.midY))
            path.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
            path.addLine(to: CGPoint(x: r.minX, y: r.maxY))
            path.addLine(to: CGPoint(x: r.minX + notch, y: r.midY))
            path.close()
            return path
        }
        let path = roundRect(r, p.radius)
        if p.frame == "bubble" {
            let tail = UIBezierPath()
            tail.move(to: CGPoint(x: r.minX + 0.16 * r.width, y: r.maxY - 1))
            tail.addLine(to: CGPoint(x: r.minX + 0.16 * r.width + 40 * p.s, y: r.maxY - 1))
            tail.addLine(to: CGPoint(x: r.minX + 0.1 * r.width, y: r.maxY + 30 * p.s))
            tail.close()
            path.append(tail)
        }
        return path
    }

    /// `paintPanel` in canvasRenderer.ts.
    private static func drawPanel(_ p: Panel, in r: CGRect) {
        if p.frame == "none" { return }
        let s = p.s
        if (p.shadowDx != 0 || p.shadowDy != 0) && alphaOf(p.shadow) > 0 {
            p.shadow.setFill()
            panelPath(p, r.offsetBy(dx: p.shadowDx, dy: p.shadowDy)).fill()
        }
        if p.frame == "painting" {
            let fw = p.frameWidth
            p.frameColor.setFill()
            roundRect(r, p.radius).fill()
            p.frameInner.setStroke()
            let outer = UIBezierPath(rect: r.insetBy(dx: 1.5 * s, dy: 1.5 * s))
            outer.lineWidth = 3 * s
            outer.stroke()
            let bevel = UIBezierPath(rect: r.insetBy(dx: fw * 0.55, dy: fw * 0.55))
            bevel.lineWidth = 3 * s
            bevel.stroke()
            let canvasRect = r.insetBy(dx: fw, dy: fw)
            p.color.setFill()
            UIBezierPath(rect: canvasRect).fill()
            let edge = UIBezierPath(rect: canvasRect)
            edge.lineWidth = 2 * s
            edge.stroke()
            p.frameAccent.setFill()
            for (cx, cy) in [(r.minX + fw / 2, r.minY + fw / 2), (r.maxX - fw / 2, r.minY + fw / 2),
                             (r.minX + fw / 2, r.maxY - fw / 2), (r.maxX - fw / 2, r.maxY - fw / 2)] {
                UIBezierPath(arcCenter: CGPoint(x: cx, y: cy), radius: fw * 0.3, startAngle: 0,
                             endAngle: 2 * .pi, clockwise: true).fill()
            }
            return
        }
        p.color.setFill()
        panelPath(p, r).fill()
        if p.frame == "postit" {
            UIColor(white: 0, alpha: 0x12 / 255).setFill()
            UIBezierPath(rect: CGRect(x: r.minX, y: r.maxY - 10 * s, width: r.width, height: 10 * s)).fill()
            let tw = min(0.42 * r.width, 150 * s)
            let th = 34 * s
            let tape = UIBezierPath(rect: CGRect(x: -tw / 2, y: -th / 2, width: tw, height: th))
            tape.apply(CGAffineTransform(rotationAngle: -5 * .pi / 180))
            tape.apply(CGAffineTransform(translationX: r.midX, y: r.minY + 2 * s))
            p.tape.setFill()
            tape.fill()
        }
    }

    /// `paintText` in canvasRenderer.ts.
    private static func drawText(_ text: String, font: UIFont, color: UIColor, ascent: CGFloat,
                                 effect: TextEffect, in r: CGRect) {
        let origin = CGPoint(x: r.minX, y: r.minY + ascent - font.ascender)
        if effect.kind == "outline" {
            let outline: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.clear,
                .strokeColor: effect.color,
                // A percentage of the point size; positive = stroke only.
                .strokeWidth: effect.width / font.pointSize * 100,
            ]
            (text as NSString).draw(at: origin, withAttributes: outline)
        }
        if effect.kind == "shadow" || effect.kind == "glow" {
            let shadow = NSShadow()
            shadow.shadowColor = effect.color
            shadow.shadowBlurRadius = effect.blur
            shadow.shadowOffset = CGSize(width: 0, height: effect.dy)
            let shadowed: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .shadow: shadow]
            (text as NSString).draw(at: origin, withAttributes: shadowed)
            if effect.kind == "glow" { (text as NSString).draw(at: origin, withAttributes: shadowed) }
        }
        (text as NSString).draw(at: origin, withAttributes: [.font: font, .foregroundColor: color])
    }

    private static func draw(_ paint: Paint, in r: CGRect) {
        switch paint {
        case .none:
            return
        case let .box(color, radius, dx, dy, shadow):
            if (dx != 0 || dy != 0) && alphaOf(shadow) > 0 {
                shadow.setFill()
                roundRect(r.offsetBy(dx: dx, dy: dy), radius).fill()
            }
            color.setFill()
            roundRect(r, radius).fill()
        case let .panel(panel):
            drawPanel(panel, in: r)
        case let .text(text, font, color, ascent, effect):
            drawText(text, font: font, color: color, ascent: ascent, effect: effect, in: r)
        case let .dot(color):
            let c = CGPoint(x: r.midX, y: r.midY)
            let radius = r.width / 2
            UIColor.white.setFill()
            UIBezierPath(arcCenter: c, radius: radius, startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
            color.setFill()
            UIBezierPath(arcCenter: c, radius: radius * 0.72, startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
            UIColor.white.setFill()
            UIBezierPath(arcCenter: c, radius: radius * 0.3, startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
        case let .pin(color):
            let k = r.width / 24
            color.setFill()
            UIBezierPath(arcCenter: CGPoint(x: r.minX + 12 * k, y: r.minY + 9 * k), radius: 7 * k,
                         startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
            let tip = UIBezierPath()
            tip.move(to: CGPoint(x: r.minX + 5.6 * k, y: r.minY + 11.8 * k))
            tip.addLine(to: CGPoint(x: r.minX + 18.4 * k, y: r.minY + 11.8 * k))
            tip.addLine(to: CGPoint(x: r.minX + 12 * k, y: r.minY + 22 * k))
            tip.close()
            tip.fill()
            UIColor.white.setFill()
            UIBezierPath(arcCenter: CGPoint(x: r.minX + 12 * k, y: r.minY + 9 * k), radius: 2.8 * k,
                         startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
        case let .badge(shape, bg, ring, text, font, color, ascent, descent):
            let c = CGPoint(x: r.midX, y: r.midY)
            let ringVisible = alphaOf(ring) > 0
            if shape == "circle" {
                let radius = min(r.width, r.height) / 2
                bg.setFill()
                UIBezierPath(arcCenter: c, radius: radius, startAngle: 0, endAngle: 2 * .pi, clockwise: true).fill()
                if ringVisible {
                    let path = UIBezierPath(arcCenter: c, radius: radius * 0.84, startAngle: 0,
                                            endAngle: 2 * .pi, clockwise: true)
                    path.lineWidth = radius * 0.05
                    path.setLineDash([radius * 0.12, radius * 0.08], count: 2, phase: 0)
                    ring.setStroke()
                    path.stroke()
                }
            } else if shape == "burst" {
                let radius = min(r.width, r.height) / 2
                let spikes = 14
                let path = UIBezierPath()
                for i in 0..<(spikes * 2) {
                    let rr = i % 2 == 0 ? radius : radius * 0.8
                    let angle = -CGFloat.pi / 2 + CGFloat(i) * .pi / CGFloat(spikes)
                    let point = CGPoint(x: c.x + rr * cos(angle), y: c.y + rr * sin(angle))
                    if i == 0 { path.move(to: point) } else { path.addLine(to: point) }
                }
                path.close()
                bg.setFill()
                path.fill()
            } else {
                bg.setFill()
                roundRect(r, r.height * 0.3).fill()
                if ringVisible {
                    let inset = r.height * 0.12
                    let path = roundRect(r.insetBy(dx: inset, dy: inset), r.height * 0.2)
                    path.lineWidth = r.height * 0.05
                    path.setLineDash([r.height * 0.1, r.height * 0.07], count: 2, phase: 0)
                    ring.setStroke()
                    path.stroke()
                }
            }
            let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color]
            let width = (text as NSString).size(withAttributes: attributes).width
            let top = c.y - (ascent + descent) / 2
            (text as NSString).draw(at: CGPoint(x: c.x - width / 2, y: top + ascent - font.ascender),
                                    withAttributes: attributes)
        }
    }
}
