"use client";

import { useState } from "react";

import { downloadStudioVideo } from "./downloadVideo";

/** A finished video's download button, with its own busy and error state. */
export function DownloadVideoButton({
  requestId,
  assetId,
  channel,
  label = "Download video",
}: {
  requestId: string;
  assetId: string;
  channel?: string;
  label?: string;
}) {
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const download = async () => {
    setDownloading(true);
    setError(null);
    try {
      await downloadStudioVideo({ requestId, assetId, channel });
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="studio-download">
      <button
        type="button"
        className="studio-button studio-button-ghost"
        disabled={downloading}
        onClick={() => void download()}
      >
        {downloading ? "Preparing the file…" : label}
      </button>
      {error && (
        <p className="studio-note studio-note-danger" style={{ marginTop: 8 }}>
          {error}
        </p>
      )}
    </div>
  );
}

/** What the Render and Channels steps need to offer "Resume rendering". */
export interface ResumeControls {
  /** Seconds until the interrupted render can be taken back, or null if it can be now. */
  waitSeconds: number | null;
  disabled: boolean;
  onResume: () => void;
}

/**
 * The render stopped — the app was closed, Stop was pressed, or a part failed —
 * and the finished parts are safe on the server. Resume carries on from the
 * part that was in progress.
 */
export function ResumeCallout({ resume, what }: { resume: ResumeControls; what: string }) {
  return (
    <div className="studio-note studio-note-warning studio-resume" role="status">
      <p style={{ margin: 0 }}>
        <strong>Rendering is paused.</strong> {what} stopped before it finished — usually because
        the app was closed. Everything already made is kept; Resume carries on from the part that
        was in progress.
        {resume.waitSeconds != null && resume.waitSeconds > 0
          ? ` It can pick up in about ${resume.waitSeconds}s.`
          : ""}
      </p>
      <button
        type="button"
        className="studio-button studio-button-primary"
        style={{ marginTop: 10 }}
        disabled={resume.disabled}
        onClick={resume.onResume}
      >
        Resume rendering
      </button>
    </div>
  );
}
