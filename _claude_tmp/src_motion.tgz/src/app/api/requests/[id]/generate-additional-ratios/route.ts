import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/authOptions";
import { Role } from "@/domain/enums/Role";
import { clipRequestRepository, videoGenerationJobRepository } from "@/repositories/index";
import { videoGenerationService } from "@/services/VideoGenerationService";

/**
 * Requester triggers generation of the remaining distribution channels' aspect
 * ratios (Phase 7) after approving the primary captioned video. Runs before the
 * automatic Travy render.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorised." }, { status: 401 });
  }
  if (session.user.role !== Role.Requester) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  const clipRequest = await clipRequestRepository.findById(id);
  if (!clipRequest || clipRequest.userId !== session.user.id) {
    return NextResponse.json({ error: "Request not found." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const jobId = body?.jobId;
  if (!jobId) {
    return NextResponse.json({ error: "Missing jobId." }, { status: 400 });
  }

  const job = await videoGenerationJobRepository.findById(jobId);
  if (!job || job.requestId !== id) {
    return NextResponse.json({ error: "Job not found." }, { status: 404 });
  }

  // Optional, and honoured only for a phone-rendered request: the channel
  // shapes the requester chose to render (the studio's Channels step). Absent
  // means every remaining shape — the server path's only behaviour.
  const RATIOS = ["9:16", "16:9", "1:1", "4:5"] as const;
  const ratios = Array.isArray(body?.ratios)
    ? (body.ratios as unknown[]).filter((value): value is (typeof RATIOS)[number] =>
        (RATIOS as readonly unknown[]).includes(value)
      )
    : undefined;

  try {
    const updated = await videoGenerationService.generateAdditionalRatiosByRequester(
      jobId,
      session.user.id,
      ratios
    );
    return NextResponse.json({ currentStep: updated.currentStep });
  } catch (err) {
    // The originals' keep window has passed (config/localMedia.ts).
    if (err instanceof Error && (err as { code?: unknown }).code === "originals_expired") {
      return NextResponse.json({ error: err.message, code: "originals_expired" }, { status: 409 });
    }
    const message = err instanceof Error ? err.message : "Failed to generate additional ratios.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
