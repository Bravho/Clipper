import { NextRequest, NextResponse } from "next/server";
import { signupSchema } from "@/features/auth/validation/signupSchema";
import {
  accountService,
  AccountService,
  ExistingAccountError,
  RefreshedUnverifiedAccountError,
} from "@/services/AccountService";
import { emailVerificationService } from "@/services/EmailVerificationService";
import { AuthProvider } from "@/domain/enums/AuthProvider";
import { ConsentInput } from "@/services/ConsentService";
import { PolicyType } from "@/domain/enums/PolicyType";
import type { ApiResponse } from "@/types";

/**
 * POST /api/register
 *
 * Registers a new requester account via email/password.
 * Called by the SignupForm client component.
 *
 * Consent model: by submitting this form the user has agreed to the
 * Terms of Service and Privacy Policy (implicit consent, shown in UI).
 * We record TermsOfService and PrivacyPolicy acceptances automatically.
 * The PrivacyPolicy covers ownership rights and storage retention.
 *
 * NOTE: Google sign-up is handled entirely by NextAuth (signIn callback).
 *       This route is only for email/password registration.
 */
interface RegistrationResult {
  requiresVerification?: boolean;
  verificationEmailSent?: boolean;
  existingAccountVerified?: boolean;
}

export async function POST(
  req: NextRequest
): Promise<NextResponse<ApiResponse<RegistrationResult>>> {
  try {
    const body = await req.json();
    const parseResult = signupSchema.safeParse(body);

    if (!parseResult.success) {
      const fieldErrors: Record<string, string[]> = {};
      parseResult.error.errors.forEach((err) => {
        const field = err.path[0]?.toString() ?? "unknown";
        if (!fieldErrors[field]) fieldErrors[field] = [];
        fieldErrors[field].push(err.message);
      });

      return NextResponse.json(
        { success: false, error: "Validation failed.", fieldErrors },
        { status: 400 }
      );
    }

    const data = parseResult.data;

    // Implicit consent: submitting the form = agreement to Terms + Privacy Policy.
    // Privacy Policy covers ownership rights and storage retention.
    const consents: ConsentInput[] = [
      { policyType: PolicyType.TermsOfService, accepted: true },
      { policyType: PolicyType.PrivacyPolicy, accepted: true },
    ];

    const passwordHash = await AccountService.hashPassword(data.password);

    const { user } = await accountService.createRequesterAccount({
      name: data.name,
      email: data.email,
      provider: AuthProvider.Credentials,
      passwordHash,
      providerAccountId: null,
      consents,
      meta: {
        ipAddress: req.headers.get("x-forwarded-for") ?? undefined,
        userAgent: req.headers.get("user-agent") ?? undefined,
      },
    });

    let verificationEmailSent = true;
    try {
      await emailVerificationService.generateAndSend(
        user.id,
        user.email,
        user.name
      );
    } catch (error) {
      verificationEmailSent = false;
      // Account creation has already succeeded. Do not tell the user that
      // registration failed and encourage a duplicate retry; direct them to
      // the verification page where delivery can be retried.
      console.error("[Clipper] verification email delivery failed:", error);
    }

    return NextResponse.json(
      {
        success: true,
        data: { requiresVerification: true, verificationEmailSent },
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof RefreshedUnverifiedAccountError) {
      let verificationEmailSent = true;
      try {
        await emailVerificationService.generateAndSend(
          error.user.id,
          error.user.email,
          error.user.name
        );
      } catch (deliveryError) {
        verificationEmailSent = false;
        console.error(
          "[Clipper] refreshed-account verification email delivery failed:",
          deliveryError
        );
      }

      return NextResponse.json(
        {
          success: true,
          data: { requiresVerification: true, verificationEmailSent },
        },
        { status: 200 }
      );
    }

    if (error instanceof ExistingAccountError) {
      return NextResponse.json(
        {
          success: false,
          error: "An account with this email address already exists.",
          data: { existingAccountVerified: error.emailVerified },
        },
        { status: 409 }
      );
    }

    console.error("[Clipper] /api/register error:", error);
    return NextResponse.json(
      { success: false, error: "Registration failed. Please try again." },
      { status: 500 }
    );
  }
}
