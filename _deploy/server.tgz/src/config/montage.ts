/**
 * Real-media montage configuration (Phase 1).
 *
 * The montage engine animates the client's actual uploaded photos/clips with
 * Ken Burns motion, cuts, and transitions — replacing the Veo generative-video
 * core for the default pipeline. This module is the single app-side source of
 * truth for the montage asset shape and motion vocabulary.
 *
 * NOTE: the Remotion bundle (built separately via @remotion/bundler) cannot
 * import from the Next.js path-aliased module graph, so `remotion/montageTypes.ts`
 * intentionally mirrors these shapes. `src/lib/ai/montageService.ts` maps the
 * app-side specs onto the Remotion input props. This mirrors the existing
 * pattern between `src/lib/ai/*` and `remotion/types.ts`.
 *
 * Upload limits (per-clip duration, total request size) live with the other
 * upload constraints in `src/domain/enums/AssetType.ts` (shipped in Phase 0):
 * MAX_CLIP_DURATION_SECONDS and MAX_UPLOAD_SIZE_BYTES.
 */

import { MAX_CLIP_DURATION_SECONDS } from "@/domain/enums/AssetType";

/** Per-asset camera motion. Non-static presets are applied to still images only. */
export type MotionPreset =
  | "ken_burns_in"
  | "ken_burns_out"
  | "pan_left"
  | "pan_right"
  | "static";

/** Transition applied between assets within a scene. */
export type MontageTransition = "cut" | "fade" | "slide" | "zoom";

export const MOTION_PRESETS: MotionPreset[] = [
  "ken_burns_in",
  "ken_burns_out",
  "pan_left",
  "pan_right",
  "static",
];

export const MONTAGE_TRANSITIONS: MontageTransition[] = [
  "cut",
  "fade",
  "slide",
  "zoom",
];

export const DEFAULT_MOTION_PRESET: MotionPreset = "ken_burns_in";
export const DEFAULT_MONTAGE_TRANSITION: MontageTransition = "fade";

/**
 * Frame rate for montage renders. Must match the Remotion overlay FPS
 * (`remotion/types.ts` FPS) and the FFmpeg composition step's expectations so
 * segments concat cleanly.
 */
export const MONTAGE_FPS = 30;

/** Transition duration in seconds (very short cross-dissolve between shots). */
export const TRANSITION_DURATION_SECONDS = 0.2;

/**
 * One real-media asset within a montage scene. `url` is a publicly readable
 * DO Spaces URL of the uploaded photo/clip. For clips, `trimStartSeconds` /
 * `trimEndSeconds` select the portion to play; `focusX`/`focusY` (0..1) steer
 * Ken Burns / crop focus toward the subject (e.g. the dish or signage).
 */
export interface MontageAssetSpec {
  url: string;
  kind: "image" | "clip";
  motion: MotionPreset;
  durationSeconds: number;
  trimStartSeconds?: number;
  trimEndSeconds?: number;
  focusX?: number;
  focusY?: number;
}

/**
 * Short music-only intro before the voiceover starts. Mirrors
 * `ffmpegService.MUSIC_LEAD_IN_SECONDS` (0.6s) — kept here as a client-safe
 * constant so the scene-design panel can compute the minimum montage length
 * without importing the server-only ffmpeg module.
 */
export const MONTAGE_INTRO_SECONDS = 0.6;

/**
 * Short tail after the narration ends so the last spoken word isn't cut at the
 * very edge of the video. The compose step freezes the final frame a little
 * longer than this, but the montage itself should still cover it.
 */
export const MONTAGE_ENDING_SECONDS = 1.0;

/** Slowest automatic clip playback rate permitted by the duration planner. */
export const MIN_AUTOMATIC_CLIP_PLAYBACK_RATE = 0.8;

/**
 * Minimum acceptable total montage length: the approved voice length plus the
 * short music intro and ending tail. The requester's scenes (stills included)
 * must sum to at least this so narration is always fully covered by picture.
 */
export function minMontageTotalSeconds(voiceDurationSeconds: number | null | undefined): number {
  const voice =
    Number.isFinite(voiceDurationSeconds) && (voiceDurationSeconds as number) > 0
      ? (voiceDurationSeconds as number)
      : 0;
  return voice + MONTAGE_INTRO_SECONDS + MONTAGE_ENDING_SECONDS;
}

export interface MontageCoverage {
  voiceSeconds: number;
  visualSeconds: number;
  requiredVisualSeconds: number;
  deficitSeconds: number;
  surplusSeconds: number;
  isCovered: boolean;
}

/** One authoritative coverage decision for every montage approval gate. */
export function evaluateMontageCoverage(params: {
  voiceDurationSeconds: number | null | undefined;
  totalSceneSeconds: number;
}): MontageCoverage {
  const voiceSeconds =
    Number.isFinite(params.voiceDurationSeconds) && (params.voiceDurationSeconds as number) > 0
      ? (params.voiceDurationSeconds as number)
      : 0;
  const visualSeconds =
    Number.isFinite(params.totalSceneSeconds) && params.totalSceneSeconds > 0
      ? params.totalSceneSeconds
      : 0;
  const requiredVisualSeconds = minMontageTotalSeconds(voiceSeconds);
  const deficitSeconds = Math.max(0, requiredVisualSeconds - visualSeconds);
  return {
    voiceSeconds,
    visualSeconds,
    requiredVisualSeconds,
    deficitSeconds,
    surplusSeconds: Math.max(0, visualSeconds - requiredVisualSeconds),
    // One frame of tolerance absorbs floating-point/frame rounding only.
    isCovered: deficitSeconds <= 1 / MONTAGE_FPS,
  };
}

/**
 * How much LONGER the voiceover may run than the total montage picture before
 * the merge is hard-blocked. Up to this much shortage is tolerated: the leftover
 * (picture-less) period is filled with a black scene while the voice + music keep
 * playing. Beyond it, the frozen/black tail would dominate the clip, so the
 * requester is required to lengthen the scenes or regenerate a shorter voiceover.
 */
export const MAX_VOICE_OVER_SHORTAGE_SECONDS = 10;

/**
 * Seconds each uploaded still is assumed to hold on screen when estimating a
 * suggested voiceover length before any scene plan exists (the first voice
 * step). Clips are counted at their real footage length instead.
 */
export const SUGGESTED_SECONDS_PER_IMAGE = 5;

/**
 * Grace beyond the suggested voiceover length before the first voice step blocks
 * approval. A voice up to this much longer than {@link estimateSuggestedVoiceSeconds}
 * is allowed (the extra is absorbed by slower clips / a short black tail); longer
 * than this and the requester must shorten the script and regenerate.
 */
export const VOICE_OVER_SUGGESTION_TOLERANCE_SECONDS = 0;

/**
 * Estimate a suggested MAXIMUM voiceover length from the uploaded source media,
 * before any scene plan exists. Clips contribute their real footage length; each
 * still contributes {@link SUGGESTED_SECONDS_PER_IMAGE}. This is the length the
 * pictures can comfortably cover, so a voiceover near or below it needs little to
 * no filler. Returns 0 when there is no usable media.
 */
export function estimateSuggestedVoiceSeconds(params: {
  imageCount: number;
  clipSecondsTotal: number;
}): number {
  const images =
    Number.isFinite(params.imageCount) && params.imageCount > 0 ? Math.floor(params.imageCount) : 0;
  const clips =
    Number.isFinite(params.clipSecondsTotal) && params.clipSecondsTotal > 0
      ? params.clipSecondsTotal
      : 0;
  return clips + images * SUGGESTED_SECONDS_PER_IMAGE;
}

/**
 * Pre-voice on-screen estimate for a single storyboard asset (still or clip),
 * shown as a RANGE while the rough storyboard is being reviewed — before any real
 * per-asset timing exists. The upper bound aligns with
 * {@link SUGGESTED_SECONDS_PER_IMAGE} (the comfortable hold for a still).
 */
export const ESTIMATED_SCENE_SECONDS_PER_ASSET_MIN = 3;
export const ESTIMATED_SCENE_SECONDS_PER_ASSET_MAX = SUGGESTED_SECONDS_PER_IMAGE; // 5

/** A rough duration estimate expressed as an inclusive [min, max] second range. */
export interface DurationRange {
  minSeconds: number;
  maxSeconds: number;
}

/**
 * Minimal asset shape needed to estimate on-screen time: its kind and, for a
 * clip, its real probed length. Both {@link OrderedSourceAsset} and the
 * storyboard thumbnail shape are assignable to this.
 */
export interface EstimateAsset {
  kind: "image" | "clip";
  /** Real clip length (seconds); ignored for images, may be null/absent. */
  durationSeconds?: number | null;
}

/**
 * Estimated on-screen duration range for a SINGLE asset:
 *  - Image → a flat {@link ESTIMATED_SCENE_SECONDS_PER_ASSET_MIN}–
 *    {@link ESTIMATED_SCENE_SECONDS_PER_ASSET_MAX}s hold.
 *  - Clip with a known length → its real (max) length as a fixed point range,
 *    capped at {@link MAX_CLIP_DURATION_SECONDS}.
 *  - Clip with an unknown length → falls back to the flat image estimate.
 * A missing/invalid asset contributes nothing (a zeroed range).
 */
export function estimateAssetDurationRange(
  asset: EstimateAsset | null | undefined
): DurationRange {
  if (!asset) return { minSeconds: 0, maxSeconds: 0 };
  if (asset.kind === "clip") {
    const d = Number(asset.durationSeconds);
    if (Number.isFinite(d) && d > 0) {
      const secs = Math.max(1, Math.round(Math.min(d, MAX_CLIP_DURATION_SECONDS)));
      return { minSeconds: secs, maxSeconds: secs };
    }
  }
  return {
    minSeconds: ESTIMATED_SCENE_SECONDS_PER_ASSET_MIN,
    maxSeconds: ESTIMATED_SCENE_SECONDS_PER_ASSET_MAX,
  };
}

/**
 * Estimated on-screen duration range for one storyboard scene, summing
 * {@link estimateAssetDurationRange} over the photos/clips it draws from.
 * Returns a zeroed range for an empty scene.
 */
export function estimateSceneDurationRange(
  assets: Array<EstimateAsset | null | undefined>
): DurationRange {
  return (Array.isArray(assets) ? assets : []).reduce<DurationRange>(
    (acc, a) => {
      const r = estimateAssetDurationRange(a);
      return {
        minSeconds: acc.minSeconds + r.minSeconds,
        maxSeconds: acc.maxSeconds + r.maxSeconds,
      };
    },
    { minSeconds: 0, maxSeconds: 0 }
  );
}

/**
 * Estimated total video length range, summing {@link estimateSceneDurationRange}
 * over every storyboard scene (pass each scene's resolved asset list). Returns a
 * zeroed range when there are no scenes/assets.
 */
export function estimateStoryboardTotalRange(
  scenes: Array<Array<EstimateAsset | null | undefined>>
): DurationRange {
  return (Array.isArray(scenes) ? scenes : []).reduce<DurationRange>(
    (acc, sceneAssets) => {
      const r = estimateSceneDurationRange(sceneAssets);
      return {
        minSeconds: acc.minSeconds + r.minSeconds,
        maxSeconds: acc.maxSeconds + r.maxSeconds,
      };
    },
    { minSeconds: 0, maxSeconds: 0 }
  );
}

/**
 * Suggested speaking-voice length range for the voice step, derived from the
 * estimated total video length. The voiceover must fit inside the picture with a
 * short music intro and ending tail, so the suggestion is always SHORTER than the
 * total: its maximum sits {@link MONTAGE_INTRO_SECONDS} + {@link MONTAGE_ENDING_SECONDS}
 * below the total's LOWER bound (guaranteeing the voice fits even the shortest
 * estimate). Returns a zeroed range when there is no usable estimate.
 */
export function suggestVoiceDurationRange(total: DurationRange): DurationRange {
  const totalMin =
    total && Number.isFinite(total.minSeconds) && total.minSeconds > 0 ? total.minSeconds : 0;
  if (totalMin <= 0) return { minSeconds: 0, maxSeconds: 0 };
  const headroom = MONTAGE_INTRO_SECONDS + MONTAGE_ENDING_SECONDS; // 1.6s
  let maxSeconds = Math.max(1, Math.round(totalMin - headroom));
  // Guarantee the suggestion is STRICTLY shorter than the total (the floor above
  // can otherwise tie a tiny total). Too small to suggest anything → no range.
  if (maxSeconds >= totalMin) maxSeconds = totalMin - 1;
  if (maxSeconds < 1) return { minSeconds: 0, maxSeconds: 0 };
  const minSeconds = Math.max(1, Math.round(maxSeconds * 0.7));
  return { minSeconds: Math.min(minSeconds, maxSeconds), maxSeconds };
}

/**
 * How much the voiceover exceeds the total montage picture length (0 when the
 * picture already covers the voice). Used by the scene-design merge gate.
 */
export function voiceOverShortageSeconds(
  totalSceneSeconds: number,
  voiceDurationSeconds: number | null | undefined
): number {
  const voice =
    Number.isFinite(voiceDurationSeconds) && (voiceDurationSeconds as number) > 0
      ? (voiceDurationSeconds as number)
      : 0;
  const picture = Number.isFinite(totalSceneSeconds) && totalSceneSeconds > 0 ? totalSceneSeconds : 0;
  return Math.max(0, voice - picture);
}

/**
 * Seconds of footage a clip's in/out window selects (0 when it has no window).
 */
export function clipWindowSeconds(asset: {
  kind: "image" | "clip";
  trimStartSeconds?: number;
  trimEndSeconds?: number;
}): number {
  if (
    asset.kind === "clip" &&
    Number.isFinite(asset.trimStartSeconds) &&
    Number.isFinite(asset.trimEndSeconds) &&
    (asset.trimEndSeconds as number) > (asset.trimStartSeconds as number)
  ) {
    return (asset.trimEndSeconds as number) - (asset.trimStartSeconds as number);
  }
  return 0;
}

/**
 * On-screen seconds a single montage asset occupies.
 *
 * For a clip this is NEVER shorter than its selected window: the requester
 * approved that window at full length, and the renderer hard-cuts a clip at the
 * end of its allotted slice, so a slot below the window silently deletes
 * approved footage. A slot LONGER than the window is legitimate — the planner
 * may stretch a clip (playbackRate < 1) to fill leftover time — so the on-screen
 * time is the larger of the two. Stills simply use `durationSeconds`.
 *
 * Every length the requester is shown, every approval gate, and the renderer all
 * measure through this one function, so they cannot disagree.
 */
export function assetPlaySeconds(asset: {
  kind: "image" | "clip";
  durationSeconds?: number;
  trimStartSeconds?: number;
  trimEndSeconds?: number;
}): number {
  const slot =
    Number.isFinite(asset.durationSeconds) && (asset.durationSeconds as number) > 0
      ? (asset.durationSeconds as number)
      : 0;
  return Math.max(slot, clipWindowSeconds(asset));
}

/** Sum a scene's on-screen length: Σ per-asset play seconds, else scene.durationSeconds. */
export function sceneMontageSeconds(scene: {
  durationSeconds?: number;
  assets?: Array<Parameters<typeof assetPlaySeconds>[0]>;
}): number {
  if (scene.assets && scene.assets.length > 0) {
    return scene.assets.reduce((sum, a) => sum + assetPlaySeconds(a), 0);
  }
  return Number.isFinite(scene.durationSeconds) && (scene.durationSeconds as number) > 0
    ? (scene.durationSeconds as number)
    : 0;
}

/**
 * Split `totalSeconds` evenly across `count` slots, frame-accurately on the
 * montage's 30 fps grid. Works in whole frames so durations align to real cut
 * points, then spreads any rounding remainder one frame at a time across the
 * earliest slots (largest-remainder) instead of dumping it on the last slot —
 * which previously left an off-beat, lingering final shot.
 *
 * Every slot gets ≥1 frame. Falls back to 1s/slot when the total is non-positive.
 *
 * Lives here (rather than in `lib/ai/montagePlan`) so the client-side approval
 * panels can share ONE allocation rule with the server-side planner.
 */
export function allocateAssetDurations(count: number, totalSeconds: number): number[] {
  if (count <= 0) return [];

  const fps = MONTAGE_FPS;
  const total = Number.isFinite(totalSeconds) && totalSeconds > 0 ? totalSeconds : count;
  const totalFrames = Math.max(count, Math.round(total * fps)); // ≥1 frame per slot

  const base = Math.floor(totalFrames / count);
  let remainder = totalFrames - base * count;
  const frames = new Array<number>(count).fill(base);
  for (let i = 0; i < count && remainder > 0; i++, remainder--) frames[i] += 1;

  // Frame-aligned seconds; sum equals totalFrames / fps exactly.
  return frames.map((f) => f / fps);
}

/** Minimal asset shape the duration rules need (structural, so this module
 *  stays free of a `domain/models` import — that module imports THIS one). */
export interface MontageDurationAsset {
  kind: "image" | "clip";
  durationSeconds?: number;
  trimStartSeconds?: number;
  trimEndSeconds?: number;
}

/**
 * A CLIP's on-screen slot is ALWAYS its own footage window — never a share of
 * the scene's time budget.
 *
 * This is the invariant that keeps "what the requester approved" and "what the
 * renderer emits" identical. The Remotion composition allocates each asset a
 * slice proportional to `durationSeconds` and hard-cuts the clip at the end of
 * that slice, so a slot SHORTER than the approved in/out window silently
 * truncates footage the requester already signed off on. Pinning the slot to
 * {@link assetPlaySeconds} makes that impossible.
 *
 * Returns null when the clip has no usable length yet (so the caller can fall
 * back to sharing the budget rather than rendering a zero-length shot).
 */
export function pinnedAssetSeconds(asset: MontageDurationAsset): number | null {
  if (asset.kind !== "clip") return null;
  const seconds = assetPlaySeconds(asset);
  return seconds > 0 ? seconds : null;
}

/**
 * Distribute a scene's target duration across its assets while PRESERVING every
 * clip at its full selected window ({@link pinnedAssetSeconds}); only stills
 * share the remaining budget. When the pinned clips already exceed the target
 * the scene AUTO-GROWS — clips are never compressed to fit, because doing so
 * would cut approved footage.
 *
 * Shared by the scene-design panel, the video-approval revision panel, and the
 * server planner so the three can never drift apart.
 */
export function reallocateSceneAssetDurations<
  A extends MontageDurationAsset,
  S extends { durationSeconds?: number; assets?: A[] },
>(scene: S): S {
  if (!scene.assets || scene.assets.length === 0) return scene;

  const pinned = scene.assets.map(pinnedAssetSeconds);
  const pinnedTotal = pinned.reduce((sum: number, d) => sum + (d ?? 0), 0);
  const flexCount = pinned.filter((d) => d == null).length;
  const target = Number.isFinite(scene.durationSeconds) ? Number(scene.durationSeconds) : 0;
  // Fractional (frame-aligned) split — an integer floor here used to shave
  // whole seconds off stills on every re-render.
  const flexBudget = Math.max(flexCount, target - pinnedTotal);
  const flexDurations = allocateAssetDurations(flexCount, flexBudget);

  let cursor = 0;
  const assets = scene.assets.map((asset, i) => ({
    ...asset,
    durationSeconds: pinned[i] ?? flexDurations[cursor++] ?? 1,
  }));
  const durationSeconds = assets.reduce((sum, a) => sum + (Number(a.durationSeconds) || 0), 0);
  return { ...scene, assets, durationSeconds };
}

export function isMotionPreset(value: unknown): value is MotionPreset {
  return typeof value === "string" && (MOTION_PRESETS as string[]).includes(value);
}

export function isMontageTransition(value: unknown): value is MontageTransition {
  return typeof value === "string" && (MONTAGE_TRANSITIONS as string[]).includes(value);
}

/**
 * Between-scene dissolve length, seconds. Mirrors the phones'
 * `DEVICE_SCENE_CROSSFADE_SECONDS` and the server concat's default.
 */
export const SCENE_DISSOLVE_SECONDS = 0.2;

/** Minimal scene shape the scene-join rule needs. */
export interface SceneJoinScene {
  transitionIn?: string | null;
  durationSeconds?: number;
  assets?: Array<{ durationSeconds?: number }>;
}

/**
 * The dissolve INTO each scene after the first (index k − 1 = into scene k),
 * as BOTH phone renderers lay it out (`ManifestRenderer.buildPicture`,
 * `ManifestRenderer.swift`): 0 when the scene's transition is "cut", otherwise
 * {@link SCENE_DISSOLVE_SECONDS}, never longer than half of either neighbouring
 * shot (the outgoing scene's last shot, the incoming scene's first).
 *
 * THE DISSOLVE BORROWS, IT NEVER ADDS OR REMOVES TIME. The incoming scene is
 * mounted that much early over the outgoing scene's tail, so scene k still
 * reaches full picture at the plain running total of the slots before it, the
 * cut (the moment the picture changes) lands mid-dissolve, and the video's
 * picture is exactly the sum of the slots. The server concat, the Look's cut
 * accents, the text-graphics windows and the studio's Sound preview all use
 * this one rule so none of them can drift from what the phone renders.
 */
export function sceneJoinDissolves(
  scenes: SceneJoinScene[],
  sceneDissolveSeconds: number = SCENE_DISSOLVE_SECONDS
): number[] {
  const slot = (value: unknown) => (Number.isFinite(value) && (value as number) > 0 ? (value as number) : 0);
  const firstShot = (scene: SceneJoinScene) =>
    scene.assets && scene.assets.length > 0 ? slot(scene.assets[0].durationSeconds) : slot(scene.durationSeconds);
  const lastShot = (scene: SceneJoinScene) =>
    scene.assets && scene.assets.length > 0
      ? slot(scene.assets[scene.assets.length - 1].durationSeconds)
      : slot(scene.durationSeconds);
  const joins: number[] = [];
  for (let k = 1; k < scenes.length; k++) {
    if (scenes[k].transitionIn === "cut") {
      joins.push(0);
      continue;
    }
    const half = Math.min(lastShot(scenes[k - 1]), firstShot(scenes[k])) / 2;
    joins.push(Math.max(0, Math.min(sceneDissolveSeconds, half)));
  }
  return joins;
}
