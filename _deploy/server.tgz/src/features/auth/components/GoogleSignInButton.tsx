"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { describeSignInFailure, startOAuth } from "@/lib/mobile/oauth";
import {
  isSignInOffered,
  useSignInAvailability,
} from "@/lib/mobile/useSignInAvailability";

interface GoogleSignInButtonProps {
  callbackUrl?: string;
  label?: string;
}

export function GoogleSignInButton({
  callbackUrl = "/dashboard",
  label = "ดำเนินการต่อด้วย Google",
}: GoogleSignInButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const availability = useSignInAvailability("google");

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      await startOAuth("google", callbackUrl);
    } catch (cause) {
      // Never swallow: a silent rejection makes the button look dead, which is
      // exactly how a misconfigured Credential Manager client presents itself.
      // The console line is what shows up in `adb logcat` under `chromium:`.
      console.error("[auth] Google sign-in failed", cause);
      setError(describeSignInFailure(cause));
      setLoading(false);
    }
  };

  // Inside the native apps a provider with no in-app path must not be
  // offered at all. The old code fell back to opening a browser here, which
  // is what App Store review rejected under Guideline 4.
  if (!isSignInOffered(availability)) return null;

  return (
    <div className="flex flex-col gap-2">
      {error && (
        <div
          className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 break-words"
          role="alert"
        >
          {error}
        </div>
      )}
      <Button
        variant="outline"
        fullWidth
        loading={loading}
        onClick={handleGoogleSignIn}
        className="gap-3 py-2.5"
      >
        {!loading && (
          <svg className="h-4 w-4 flex-shrink-0" viewBox="0 0 24 24">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>
        )}
        {label}
      </Button>
    </div>
  );
}
