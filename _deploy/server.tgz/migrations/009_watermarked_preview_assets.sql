-- Migration 009: Watermarked-preview asset linkage on uploaded_assets
--
-- Pre-render watermark model:
--   * Every delivered FinalClip now has a pre-rendered "RClipper" tiled
--     watermarked sibling (asset_type = 'watermarked_preview'), produced on the
--     Mac render worker during the overlay/finalize step.
--   * The watermarked sibling is the ONLY variant surfaced to a requester whose
--     download is still locked (download_unlocked = false). Paying to unlock
--     switches serving to the clean FinalClip — no re-render needed.
--   * source_asset_id links each watermarked_preview back to its clean FinalClip
--     so the presentation layer can swap them 1:1.
--
-- asset_type is stored as free TEXT (no CHECK constraint), so the new
-- 'watermarked_preview' value needs no enum/type change — only the linkage
-- column is added here.
--
-- Idempotent. Apply with:
--   node scripts/apply-migration.js migrations/009_watermarked_preview_assets.sql

ALTER TABLE uploaded_assets
  ADD COLUMN IF NOT EXISTS source_asset_id UUID NULL;

-- Fast lookup of a clean master's watermarked sibling.
CREATE INDEX IF NOT EXISTS idx_uploaded_assets_source_asset_id
  ON uploaded_assets (source_asset_id)
  WHERE source_asset_id IS NOT NULL;
