-- Migration 004: Add iAppTTS and animation pipeline columns to video_generation_jobs
--
-- The TTS voice generation and the animation/subtitle steps write these
-- fields via PostgresVideoGenerationJobRepository, but they were never added
-- to the schema (002/003). Without them, every voice regeneration fails with:
--   column "tts_task_id" of relation "video_generation_jobs" does not exist
--
-- tts_task_id is engine-neutral: it stores the async job id of whichever
-- local TTS server is configured (currently iAppTTS).
--
-- Apply with:
--   node scripts/apply-migration.js migrations/004_add_iapptts_and_animation_columns.sql

ALTER TABLE video_generation_jobs
  ADD COLUMN IF NOT EXISTS tts_task_id             TEXT,
  ADD COLUMN IF NOT EXISTS subtitle_timeline       TEXT,
  ADD COLUMN IF NOT EXISTS animation_spec          TEXT,
  ADD COLUMN IF NOT EXISTS animated_video_asset_id TEXT;
