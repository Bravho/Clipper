-- Migration 006: Add id defaults to Phase 2B tables (persist clip requests)
--
-- The Phase 2B repositories' create() methods never supply an id, so inserting
-- against these tables fails with:
--   null value in column "id" violates not-null constraint
--
-- This migration backfills a server-side default so the repositories can be
-- swapped from the in-memory Mock to PostgreSQL. The live database's id columns
-- may be either `uuid` or `text` depending on how each table was created, so it
-- inspects each column's type and applies the matching default:
-- gen_random_uuid() for uuid columns, gen_random_uuid()::text for text columns.
-- gen_random_uuid() is built in to PostgreSQL 13+ (pgcrypto on older).
--
-- Safe to run multiple times.
--
-- Apply with:
--   node scripts/apply-migration.js migrations/006_phase2b_id_defaults.sql

-- Ensure gen_random_uuid() is available on older servers (no-op on PG13+).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- id defaults (type-aware)
DO $$
DECLARE
  t   text;
  dt  text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'clip_requests',
    'request_status_history',
    'uploaded_assets',
    'publishing_links',
    'video_generation_jobs'
  ]
  LOOP
    SELECT data_type INTO dt
    FROM information_schema.columns
    WHERE table_name = t AND column_name = 'id';

    IF dt IS NULL THEN
      RAISE NOTICE 'Skipping % (no id column found)', t;
    ELSIF dt = 'uuid' THEN
      EXECUTE format('ALTER TABLE %I ALTER COLUMN id SET DEFAULT gen_random_uuid()', t);
      RAISE NOTICE 'Set uuid default on %.id', t;
    ELSE
      EXECUTE format('ALTER TABLE %I ALTER COLUMN id SET DEFAULT gen_random_uuid()::text', t);
      RAISE NOTICE 'Set text default on %.id', t;
    END IF;
  END LOOP;
END $$;

-- pipeline column safety net
-- PostgresVideoGenerationJobRepository.create() inserts columns introduced by
-- migrations 003-005. Re-assert them here with IF NOT EXISTS so swapping the
-- job repository to Postgres is safe even if 003-005 were not all applied.
ALTER TABLE video_generation_jobs
  ADD COLUMN IF NOT EXISTS selected_music_track        TEXT,
  ADD COLUMN IF NOT EXISTS tts_task_id                 TEXT,
  ADD COLUMN IF NOT EXISTS subtitle_timeline           TEXT,
  ADD COLUMN IF NOT EXISTS animation_spec              TEXT,
  ADD COLUMN IF NOT EXISTS animated_video_asset_id     TEXT,
  ADD COLUMN IF NOT EXISTS script_chinese              TEXT,
  ADD COLUMN IF NOT EXISTS approved_script_chinese     TEXT,
  ADD COLUMN IF NOT EXISTS subtitle_languages          TEXT[] NOT NULL DEFAULT '{en,zh}',
  ADD COLUMN IF NOT EXISTS final_export_travy_asset_id TEXT;
