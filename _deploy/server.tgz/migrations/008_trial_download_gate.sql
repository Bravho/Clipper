-- Migration 008: Pay-to-download trial gate columns on clip_requests
--
-- Trial model:
--   * A user's FIRST request generates for free but is download-locked
--     (download_unlocked = false, is_trial_request = true).
--   * Subsequent requests are charged at submission and created
--     download_unlocked = true.
--
-- Both columns default false, so existing rows are treated as locked/non-trial.
-- Existing delivered requests predate the trial model; if any need to be
-- retroactively downloadable, flip download_unlocked = true for them manually.
--
-- Idempotent. Apply with:
--   node scripts/apply-migration.js migrations/008_trial_download_gate.sql

ALTER TABLE clip_requests
  ADD COLUMN IF NOT EXISTS download_unlocked BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_trial_request  BOOLEAN NOT NULL DEFAULT false;
