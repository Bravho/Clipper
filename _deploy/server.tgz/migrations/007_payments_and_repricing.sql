-- Migration 007: PromptPay top-ups (GB Prime Pay) + credit re-pricing
--
-- Two independent changes, safe to run together and idempotent where possible:
--
--   1. payment_intents table — tracks PromptPay QR top-ups end to end.
--   2. Credit re-pricing backfill — the credit unit changes from 1 credit = ฿10
--      to 1 credit = ฿1. To preserve every user's REAL baht value, existing wallet
--      balances and ledger amounts are multiplied by 10.
--
-- Apply with:
--   node scripts/apply-migration.js migrations/007_payments_and_repricing.sql
--
-- ⚠️  The ×10 backfill (section 2) is NOT idempotent — running it twice multiplies
--     balances by 100. It is guarded by a marker row in schema_migrations_meta so a
--     second run is a no-op. Do NOT remove the guard.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── 1. payment_intents ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payment_intents (
  id             UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID          NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  gateway        TEXT          NOT NULL DEFAULT 'gbprimepay',
  method         TEXT          NOT NULL DEFAULT 'promptpay_qr',
  amount_baht    NUMERIC(10,2) NOT NULL,
  credits_to_add INTEGER       NOT NULL,
  status         TEXT          NOT NULL DEFAULT 'pending',
  reference_no   TEXT          NOT NULL UNIQUE,
  gateway_ref    TEXT,
  qr_payload     TEXT,
  expires_at     TIMESTAMPTZ   NOT NULL,
  created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payment_intents_user ON payment_intents (user_id);
CREATE INDEX IF NOT EXISTS idx_payment_intents_ref  ON payment_intents (reference_no);
CREATE INDEX IF NOT EXISTS idx_payment_intents_status ON payment_intents (status);

-- ── 2. Credit re-pricing (×10 value-preserving backfill), run once ───────────
CREATE TABLE IF NOT EXISTS schema_migrations_meta (
  key        TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM schema_migrations_meta WHERE key = '007_credit_reprice_x10') THEN
    RAISE NOTICE '007 re-pricing already applied — skipping ×10 backfill.';
  ELSE
    -- Preserve real baht value now that 1 credit = ฿1 (was ฿10).
    UPDATE credit_wallets      SET balance = balance * 10;
    UPDATE credit_transactions SET amount  = amount  * 10;

    INSERT INTO schema_migrations_meta (key) VALUES ('007_credit_reprice_x10');
    RAISE NOTICE '007 re-pricing applied: wallet balances and ledger ×10.';
  END IF;
END $$;
