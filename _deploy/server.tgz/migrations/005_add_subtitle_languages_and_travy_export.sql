-- Migration 005: Subtitle language selection + dedicated Travy export
--
-- Requesters can now choose which subtitle languages (any combination of
-- Thai/English/Chinese) are burned into their general distribution exports.
-- The Travy App upload always carries English + Chinese subtitles regardless
-- of that choice (Travy platform requirement), so it gets its own export
-- asset separate from the shared 9:16 file used by TikTok etc.
--
-- Also backfills script_chinese / approved_script_chinese columns, which were
-- added to the domain model but never migrated (introduced alongside the
-- English+Chinese subtitle change).
--
-- Apply with:
--   node scripts/apply-migration.js migrations/005_add_subtitle_languages_and_travy_export.sql

ALTER TABLE video_generation_jobs
  ADD COLUMN IF NOT EXISTS script_chinese          TEXT,
  ADD COLUMN IF NOT EXISTS approved_script_chinese TEXT,
  ADD COLUMN IF NOT EXISTS subtitle_languages      TEXT[] NOT NULL DEFAULT '{en,zh}',
  ADD COLUMN IF NOT EXISTS final_export_travy_asset_id TEXT;
